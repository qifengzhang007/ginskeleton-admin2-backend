/*
SQLyog  v12.2.6 (64 bit)
MySQL - 10.3.18-MariaDB : Database - db_ginskeleton2
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_ginskeleton2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `db_ginskeleton2`;

/*Table structure for table `tb_auth_access_tokens` */

DROP TABLE IF EXISTS `tb_auth_access_tokens`;

CREATE TABLE `tb_auth_access_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_user_id` int(11) DEFAULT 0 COMMENT '外键:tb_users表id',
  `client_id` int(10) unsigned DEFAULT 1 COMMENT '普通用户的授权，默认为1',
  `token` varchar(600) DEFAULT NULL,
  `action_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'login|update|reset表示token生成动作',
  `scopes` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '[*]' COMMENT '暂时预留,未启用',
  `revoked` tinyint(1) DEFAULT 0 COMMENT '是否撤销',
  `client_ip` varchar(128) DEFAULT NULL COMMENT 'ipv6最长为128位',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`fr_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth_access_tokens` */

insert  into `tb_auth_access_tokens`(`id`,`fr_user_id`,`client_id`,`token`,`action_name`,`scopes`,`revoked`,`client_ip`,`created_at`,`updated_at`,`expires_at`) values 
(1,1,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJ1c2VyX25hbWUiOiJhZG1pbiIsInBob25lIjoiMTU4MDQwMzc5MjkiLCJleHAiOjE2NTQ0NjM4ODgsIm5iZiI6MTY1NDQzNTA3OH0.WGE0hkF94bxYd7N380Aeh4LrAKJtJhJ2JQ42HpzNde0','login','[*]',0,'127.0.0.1','2022-06-05 21:18:08','2022-06-05 21:18:08','2022-06-06 05:18:08'),
(2,1,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJ1c2VyX25hbWUiOiJhZG1pbiIsInBob25lIjoiMTU4MDQwMzc5MjkiLCJleHAiOjE2NTQ0NjM4OTUsIm5iZiI6MTY1NDQzNTA4NX0.NlaszBZFU0oFGVS-88XL3I00DrdCqtdKgCr48AZfkNk','login','[*]',0,'127.0.0.1','2022-06-05 21:18:15','2022-06-05 21:18:15','2022-06-06 05:18:15'),
(3,1,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJ1c2VyX25hbWUiOiJhZG1pbiIsInBob25lIjoiMTU4MDQwMzc5MjkiLCJleHAiOjE2NTQ0NjQwMjEsIm5iZiI6MTY1NDQzNTIxMX0.n_VrxWXLcMD8aAsix3OYnyxNlIw5CzLcAt7sMtJxZQk','login','[*]',0,'127.0.0.1','2022-06-05 21:20:21','2022-06-05 21:20:21','2022-06-06 05:20:21'),
(4,1,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJ1c2VyX25hbWUiOiJhZG1pbiIsInBob25lIjoiMTU4MDQwMzc5MjkiLCJleHAiOjE2NTQ0NzMwODQsIm5iZiI6MTY1NDQ0NDI3NH0.vV-LOUPMVLXG9OI7GxF205Pjcp0MPcv-kitEAAgnooQ','login','[*]',0,'127.0.0.1','2022-06-05 23:51:24','2022-06-05 23:51:24','2022-06-06 07:51:24');

/*Table structure for table `tb_auth_button_cn_en` */

DROP TABLE IF EXISTS `tb_auth_button_cn_en`;

CREATE TABLE `tb_auth_button_cn_en` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `en_name` char(60) DEFAULT '' COMMENT '英文字母',
  `cn_name` char(60) DEFAULT '' COMMENT '中文名',
  `color` varchar(100) DEFAULT 'default' COMMENT '菜单显示待分配的权限使用',
  `allow_method` varchar(30) DEFAULT '*' COMMENT '允许的请求方式',
  `status` tinyint(4) DEFAULT 1,
  `remark` varchar(128) DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='按钮代码统一管理';

/*Data for the table `tb_auth_button_cn_en` */

insert  into `tb_auth_button_cn_en`(`id`,`en_name`,`cn_name`,`color`,`allow_method`,`status`,`remark`,`created_at`,`updated_at`) values 
(1,'insert','新增','#67c23a','POST',1,'','2021-01-28 09:45:50','2022-06-03 17:58:21'),
(2,'delete','删除','#f56c6c','POST',1,'删除等红色标识','2021-01-28 09:45:50','2022-06-03 17:58:34'),
(3,'update','修改','#409eff','POST',1,'蓝色背景','2021-01-28 09:45:50','2022-06-03 17:58:48'),
(4,'select','查询','#409eff','GET',1,'primary','2021-01-28 09:45:50','2022-06-03 17:58:54'),
(21,'sub_insert','子新增','#7ac257','POST',1,'如果一个页面分为主、从部分，都拥有增、删、改、查按钮，那么就需要设置不一样的英文名称。','2021-01-28 09:45:49','2022-06-03 17:59:14'),
(22,'sub_delete','子删除','#f48f8f','POST',1,'','2021-01-28 09:45:50','2022-06-03 17:59:28'),
(23,'sub_update','子修改','#60aaf7','POST',1,'','2021-01-28 09:45:51','2022-06-03 17:59:43'),
(24,'sub_select','子查询','#60aaf7','GET',1,'','2021-01-28 09:45:52','2022-06-03 17:59:57'),
(25,'common_user_info','用户token+动态菜单信息','#60aaf7','GET',1,'用户token信息+动态菜单','2021-03-05 14:24:25','2022-06-03 18:00:23'),
(26,'common_user_has_view_button_list','用户>页面>按钮','#60aaf7','GET',1,'根据当前用户token查询他所拥有的的按钮列表','2021-03-10 18:06:33','2022-06-03 18:00:41'),
(27,'common_org_list_byFid','组织机构','#60aaf7','GET',1,'组织机构左侧菜单接口','2021-03-10 18:07:29','2022-06-03 18:00:58'),
(28,'menu_mount_auth_button','系统菜单>按钮列表','#60aaf7','GET',1,'系统菜挂接的全部按钮(待分配的全部按钮)','2021-03-10 18:08:27','2022-06-03 18:01:05'),
(29,'common_system_list_byFid','系统菜单左侧树','#60aaf7','GET',1,'系统菜单左侧树接口','2021-03-10 18:08:49','2022-06-03 18:01:12'),
(30,'all_menu_list','待分配权限','#60aaf7','GET',1,'系统全部待分配菜单','2021-03-11 17:25:42','2022-06-03 18:01:21'),
(31,'org_has_menu_list','已分配权限','#60aaf7','GET',1,'组织机构已分配权限列表','2021-03-11 17:40:25','2022-06-03 18:01:29'),
(32,'user_has_menu_list','用户已分配权限','#60aaf7','GET',1,'菜单+按钮列表','2021-03-11 17:49:07','2022-06-03 18:01:48'),
(33,'common_button_list','公共按钮列表','#60aaf7','GET',1,'公共按钮选择界面的接口','2021-03-11 17:51:52','2022-06-03 18:01:36'),
(37,'upload_files','文件上传','#7ac356','POST',1,'挂载文件上传接口','2021-03-15 16:16:05','2022-06-03 18:02:02');

/*Table structure for table `tb_auth_casbin_rule` */

DROP TABLE IF EXISTS `tb_auth_casbin_rule`;

CREATE TABLE `tb_auth_casbin_rule` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `ptype` varchar(100) DEFAULT NULL,
  `v0` varchar(100) NOT NULL DEFAULT '',
  `v1` varchar(100) NOT NULL DEFAULT '',
  `v2` varchar(100) DEFAULT NULL,
  `v3` varchar(100) DEFAULT '',
  `v4` varchar(100) DEFAULT '',
  `v5` varchar(100) DEFAULT '',
  `fr_auth_post_mount_has_menu_button_id` int(10) unsigned DEFAULT 0 COMMENT 'ptype=p 相关值有效',
  `v6` varchar(25) DEFAULT '',
  `v7` varchar(25) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tb_auth_casbin_rule` (`ptype`,`v0`,`v1`,`v2`,`v3`,`v4`,`v5`),
  UNIQUE KEY `index_vp01` (`ptype`,`v0`,`v1`,`v2`)
) ENGINE=InnoDB AUTO_INCREMENT=392 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth_casbin_rule` */

insert  into `tb_auth_casbin_rule`(`id`,`ptype`,`v0`,`v1`,`v2`,`v3`,`v4`,`v5`,`fr_auth_post_mount_has_menu_button_id`,`v6`,`v7`) values 
(118,'p','36','/admin/organization/list*','GET','','','',817,NULL,NULL),
(122,'g','36','35','','','','',0,NULL,NULL),
(123,'g','35','1','','','','',0,NULL,NULL),
(124,'p','36','/admin/post_members/create','POST','','','',819,NULL,NULL),
(126,'p','36','/admin/post_members/list*','GET','','','',822,NULL,NULL),
(132,'p','36','/admin/system_menu/assgin_to_org','POST','','','',828,NULL,NULL),
(136,'p','36','/admin/organization/create','POST','','','',831,NULL,NULL),
(138,'p','36','/admin/system_menu/del_auth_from_org','POST','','','',833,NULL,NULL),
(141,'p','36','/admin/system_menu/create','POST','','','',836,NULL,NULL),
(142,'p','36','/admin/system_menu/list*','GET','','','',837,NULL,NULL),
(144,'p','1','/admin/system_menu/get_by_fid*','GET','','','',839,NULL,NULL),
(145,'p','1','/admin/organization/get_by_fid*','GET','','','',840,NULL,NULL),
(147,'p','1','/admin/users/has_view_button_list*','GET','','','',842,NULL,NULL),
(148,'p','36','/admin/system_menu/all_list*','GET','','','',846,NULL,NULL),
(149,'p','36','/admin/system_menu/assgined_list*','GET','','','',845,NULL,NULL),
(150,'p','1','/admin/button_cn_en/list*','GET','','','',847,NULL,NULL),
(151,'p','1','/admin/users/info*','GET','','','',839,NULL,NULL),
(152,'p','36','/admin/auth_analysis/user_list_with_post*','GET','','','',834,NULL,NULL),
(153,'p','36','/admin/auth_analysis/has_auth_list*','GET','','','',848,NULL,NULL),
(154,'p','36','/admin/button/create','POST','','','',849,NULL,NULL),
(155,'p','36','/admin/button/list*','GET','','','',844,NULL,NULL),
(158,'p','36','/admin/system_menu/mount_auth_button*','GET','','','',852,NULL,NULL),
(164,'p','1','/admin/upload/files','POST','','','',858,NULL,NULL),
(286,'p','36','/admin/system_menu/destroy','POST','','','',835,NULL,NULL),
(287,'p','36','/admin/system_menu/edit','POST','','','',838,NULL,NULL),
(290,'p','36','/admin/province_city/list*','GET','','','',878,NULL,NULL),
(291,'p','36','/admin/province_city/create','POST','','','',879,NULL,NULL),
(292,'p','36','/admin/province_city/edit','POST','','','',881,NULL,NULL),
(293,'p','36','/admin/province_city/get_sublist*','GET','','','',882,NULL,NULL),
(295,'p','36','/admin/button/edit','POST','','','',851,NULL,NULL),
(296,'p','36','/admin/province_city/destroy','POST','','','',883,NULL,NULL),
(299,'p','36','/admin/organization/edit','POST','','','',830,NULL,NULL),
(300,'p','36','/admin/organization/destroy','POST','','','',816,NULL,NULL),
(301,'p','36','/admin/post_members/edit','POST','','','',821,NULL,NULL),
(302,'p','36','/admin/post_members/destroy','POST','','','',832,NULL,NULL),
(303,'p','36','/admin/button/destroy','POST','','','',850,NULL,NULL),
(304,'p','36','/admin/users/edit','POST','','','',884,NULL,NULL),
(305,'p','36','/admin/users/destroy','POST','','','',885,NULL,NULL),
(307,'p','10','/admin/users/list*','GET','','','',66,NULL,NULL),
(308,'g','10','8','','','','',0,NULL,NULL),
(309,'g','8','1','','','','',0,NULL,NULL),
(310,'p','1','/admin/users/personal_info*','GET','','','',884,NULL,NULL),
(311,'p','1','/admin/users/personal_edit','POST','','','',885,NULL,NULL),
(316,'g','7','1','','','','',0,NULL,NULL),
(380,'p','36','/admin/users/list*','GET','','','',953,NULL,NULL),
(382,'p','36','/admin/users/create','POST','','','',957,NULL,NULL);

/*Table structure for table `tb_auth_organization_post` */

DROP TABLE IF EXISTS `tb_auth_organization_post`;

CREATE TABLE `tb_auth_organization_post` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned DEFAULT 0,
  `title` varchar(120) DEFAULT '' COMMENT '组织机构名称',
  `status` tinyint(4) DEFAULT 1 COMMENT '数据状态',
  `path_info` varchar(1024) DEFAULT '' COMMENT '路径导航',
  `node_level` int(10) DEFAULT 0 COMMENT '节点深度',
  `remark` varchar(120) DEFAULT '' COMMENT '备注信息',
  `created_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='组织机构、岗位(角色)管理';

/*Data for the table `tb_auth_organization_post` */

insert  into `tb_auth_organization_post`(`id`,`fid`,`title`,`status`,`path_info`,`node_level`,`remark`,`created_at`,`updated_at`) values 
(1,0,'上海仪电数字技术股份有限公司',1,'0,1',1,'','2021-02-23 15:18:31','2020-12-01 14:03:59'),
(2,1,'经营班子',1,'0,1,2',2,'','2021-02-23 15:18:35','2020-12-01 14:04:14'),
(3,1,'财务部',1,'0,1,3',2,'','2021-02-23 15:18:36','2020-12-01 14:04:17'),
(4,1,'采购部',1,'0,1,4',2,'','2021-02-23 15:18:36','2020-12-01 14:04:27'),
(5,1,'市场部',1,'0,1,5',2,'','2021-02-23 15:18:37','2020-12-01 14:04:34'),
(6,1,'质量部',1,'0,1,6',2,'','2021-02-23 15:18:38','2020-12-01 14:04:40'),
(7,1,'综合部',1,'0,1,7',2,'','2021-02-23 15:18:39','2020-12-01 14:04:50'),
(8,1,'研发部',1,'0,1,8',2,'','2022-05-27 22:11:58','2022-05-27 22:11:58'),
(9,8,'技术总监',1,'0,1,8,9',3,'','2021-02-23 15:18:44','2020-12-01 14:16:14'),
(10,8,'研发总监',1,'0,1,8,10',3,'','2021-02-23 15:18:46','2020-12-01 14:16:20'),
(11,2,'总经理',1,'0,1,2,11',3,'','2021-02-23 15:18:53','2020-12-11 14:22:42'),
(12,2,'副总经理',1,'0,1,2,12',3,'','2021-02-23 15:18:54','2020-12-01 15:50:01'),
(13,3,'财务部部长',1,'0,1,3,13',3,'','2021-02-23 15:19:09','2020-12-01 15:50:07'),
(14,3,'科员',1,'0,1,3,14',3,'','2021-02-23 15:19:11','2020-12-01 15:50:12'),
(15,4,'采购部部长',1,'0,1,4,15',4,'','2021-02-23 15:19:16','2020-12-01 15:50:27'),
(16,4,'采购员',1,'0,1,4,16',4,'','2021-02-23 15:19:17','2020-12-01 15:50:36'),
(32,8,'软件开发',1,'0,1,8,32',3,'','2021-03-09 17:04:01','2021-02-25 16:57:23'),
(35,1,'信息化中心',1,'0,1,35',2,'主要将系统运维的人员设置在此部门，负责本系统的所有操作','2021-03-08 00:03:40','2021-03-08 00:03:28'),
(36,35,'超级管理员',1,'0,1,35,36',3,'admin 可以设置在此岗位','2021-03-08 00:04:32','2021-03-08 00:04:32'),
(38,5,'营销主管',1,'0,1,5,38',3,'','2021-03-22 22:28:46','2021-03-21 00:28:59');

/*Table structure for table `tb_auth_post_members` */

DROP TABLE IF EXISTS `tb_auth_post_members`;

CREATE TABLE `tb_auth_post_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_auth_organization_post_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '外键:隶属组织机构、岗位ID',
  `fr_user_id` int(10) DEFAULT NULL COMMENT '外键:岗位挂接的人员id',
  `status` tinyint(4) DEFAULT 1 COMMENT '数据状态',
  `remark` varchar(120) DEFAULT '' COMMENT '备注信息',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='岗位成员表';

/*Data for the table `tb_auth_post_members` */

insert  into `tb_auth_post_members`(`id`,`fr_auth_organization_post_id`,`fr_user_id`,`status`,`remark`,`created_at`,`updated_at`) values 
(3,36,1,1,'','2021-02-23 15:54:36','2021-02-23 15:54:36'),
(17,10,3,1,'','2021-03-21 18:56:25','2021-03-21 18:56:25');

/*Table structure for table `tb_auth_post_mount_has_menu` */

DROP TABLE IF EXISTS `tb_auth_post_mount_has_menu`;

CREATE TABLE `tb_auth_post_mount_has_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_auth_orgnization_post_id` int(11) DEFAULT 0 COMMENT '外键:组织机构岗位id',
  `fr_auth_system_menu_id` int(11) unsigned DEFAULT 0 COMMENT '外键:系统菜单的id',
  `status` tinyint(4) DEFAULT 1,
  `remark` varchar(120) DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth_post_mount_has_menu` */

insert  into `tb_auth_post_mount_has_menu`(`id`,`fr_auth_orgnization_post_id`,`fr_auth_system_menu_id`,`status`,`remark`,`created_at`,`updated_at`) values 
(21,2,2,1,'','2021-02-23 15:56:43','2021-02-23 15:56:43'),
(22,2,3,1,'','2021-02-23 15:56:47','2021-02-23 15:56:47'),
(25,2,6,1,'','2021-02-23 15:56:55','2021-02-23 15:56:55'),
(38,10,2,1,'','2021-03-03 22:16:38','2021-03-03 22:16:38'),
(39,10,9,1,'','2021-03-03 22:16:38','2021-03-03 22:16:38'),
(40,10,6,1,'','2021-03-03 22:19:22','2021-03-03 22:19:22'),
(324,32,2,1,'','2021-03-07 23:28:06','2021-03-07 23:28:06'),
(325,32,6,1,'','2021-03-07 23:28:06','2021-03-07 23:28:06'),
(328,36,2,1,'','2021-03-09 13:07:32','2021-03-09 13:07:32'),
(330,36,4,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(331,36,3,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(332,36,5,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(334,36,8,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(335,36,9,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(336,36,10,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(337,36,7,1,'','2021-03-09 17:30:42','2021-03-09 17:30:42'),
(343,1,2,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(344,1,39,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(347,36,41,1,'','2021-03-20 16:42:54','2021-03-20 16:42:54'),
(348,36,42,1,'','2021-03-20 16:42:54','2021-03-20 16:42:54'),
(370,36,6,1,'','2022-05-30 21:16:38','2022-05-30 21:16:38');

/*Table structure for table `tb_auth_post_mount_has_menu_button` */

DROP TABLE IF EXISTS `tb_auth_post_mount_has_menu_button`;

CREATE TABLE `tb_auth_post_mount_has_menu_button` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_auth_post_mount_has_menu_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '外键:部门、岗位挂接的菜单表id',
  `fr_auth_button_cn_en_id` int(10) DEFAULT NULL COMMENT '外键:按钮表id',
  `status` tinyint(4) DEFAULT 1,
  `remark` varchar(100) DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_post_menu` (`fr_auth_orgnization_post_id`,`fr_auth_system_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=967 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth_post_mount_has_menu_button` */

insert  into `tb_auth_post_mount_has_menu_button`(`id`,`fr_auth_post_mount_has_menu_id`,`fr_auth_button_cn_en_id`,`status`,`remark`,`created_at`,`updated_at`) values 
(62,3,1,1,'','2021-03-03 16:04:16','2021-03-03 16:04:16'),
(63,3,2,1,'','2021-03-03 16:04:19','2021-03-03 16:04:19'),
(64,3,3,1,'','2021-03-03 16:04:21','2021-03-03 16:04:21'),
(65,3,4,1,'','2021-03-03 16:04:23','2021-03-03 16:04:23'),
(66,40,4,1,'','2021-03-03 22:19:22','2021-03-03 22:19:22'),
(807,325,4,1,'','2021-03-07 23:28:06','2021-03-07 23:28:06'),
(808,325,3,1,'','2021-03-07 23:28:06','2021-03-07 23:28:06'),
(809,325,1,1,'','2021-03-07 23:28:06','2021-03-07 23:28:06'),
(816,330,2,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(817,330,4,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(819,332,1,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(821,332,3,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(822,332,4,1,'','2021-03-09 13:08:51','2021-03-09 13:08:51'),
(828,337,1,1,'','2021-03-09 17:30:42','2021-03-09 17:30:42'),
(830,330,3,1,'','2021-03-10 11:11:37','2021-03-10 11:11:37'),
(831,330,1,1,'','2021-03-10 11:11:37','2021-03-10 11:11:37'),
(832,332,2,1,'','2021-03-10 11:16:28','2021-03-10 11:16:28'),
(833,337,2,1,'','2021-03-10 11:22:07','2021-03-10 11:22:07'),
(834,334,4,1,'','2021-03-10 11:28:53','2021-03-10 11:28:53'),
(835,331,2,1,'','2021-03-10 17:24:38','2021-03-10 17:24:38'),
(836,331,1,1,'','2021-03-10 17:24:38','2021-03-10 17:24:38'),
(837,331,4,1,'','2021-03-10 17:24:38','2021-03-10 17:24:38'),
(838,331,3,1,'','2021-03-10 17:24:38','2021-03-10 17:24:38'),
(844,336,4,1,'','2021-03-11 15:20:23','2021-03-11 15:20:23'),
(845,337,31,1,'','2021-03-11 17:43:09','2021-03-11 17:43:09'),
(846,337,30,1,'','2021-03-11 17:43:09','2021-03-11 17:43:09'),
(848,334,32,1,'','2021-03-11 18:08:24','2021-03-11 18:08:24'),
(849,336,1,1,'','2021-03-11 18:20:41','2021-03-11 18:20:41'),
(850,336,2,1,'','2021-03-11 18:20:41','2021-03-11 18:20:41'),
(851,336,3,1,'','2021-03-11 18:20:41','2021-03-11 18:20:41'),
(852,331,28,1,'','2021-03-11 23:42:57','2021-03-11 23:42:57'),
(867,344,25,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(868,344,26,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(871,344,33,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(872,344,27,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(873,344,37,1,'','2021-03-20 13:27:48','2021-03-20 13:27:48'),
(878,348,4,1,'','2021-03-20 16:42:54','2021-03-20 16:42:54'),
(879,348,1,1,'','2021-03-20 19:07:30','2021-03-20 19:07:30'),
(881,348,3,1,'','2021-03-20 19:07:30','2021-03-20 19:07:30'),
(882,348,24,1,'','2021-03-20 19:07:30','2021-03-20 19:07:30'),
(883,348,2,1,'','2021-03-20 23:31:37','2021-03-20 23:31:37'),
(884,344,24,1,'','2022-01-19 14:23:57','2022-01-19 14:23:57'),
(885,344,23,1,'','2022-01-19 14:23:57','2022-01-19 14:23:57'),
(953,370,4,1,'','2022-05-30 21:16:38','2022-05-30 21:16:38'),
(954,370,2,1,'','2022-05-30 21:16:38','2022-05-30 21:16:38'),
(955,370,3,1,'','2022-05-30 21:16:38','2022-05-30 21:16:38'),
(957,370,1,1,'','2022-05-30 21:27:48','2022-05-30 21:27:48');

/*Table structure for table `tb_auth_system_menu` */

DROP TABLE IF EXISTS `tb_auth_system_menu`;

CREATE TABLE `tb_auth_system_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '父ID',
  `icon` varchar(30) DEFAULT '' COMMENT '菜单图标代码',
  `title` varchar(120) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `url` varchar(120) NOT NULL DEFAULT '' COMMENT 'url',
  `name` varchar(100) DEFAULT '' COMMENT '路由名称',
  `path` varchar(120) DEFAULT '' COMMENT '路由路径',
  `component` varchar(128) DEFAULT '' COMMENT '菜单对应的视图地址(view路径)',
  `sort` int(10) DEFAULT 0 COMMENT '排序字段',
  `node_level` smallint(6) DEFAULT 1 COMMENT '菜单的深度:1|2|3',
  `path_info` varchar(1024) DEFAULT '' COMMENT '菜单路径导航',
  `status` tinyint(4) DEFAULT 1,
  `remark` varchar(128) NOT NULL DEFAULT '' COMMENT '备注',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth_system_menu` */

insert  into `tb_auth_system_menu`(`id`,`fid`,`icon`,`title`,`url`,`name`,`path`,`component`,`sort`,`node_level`,`path_info`,`status`,`remark`,`created_at`,`updated_at`) values 
(2,0,'Setting','系统配置','','system-setting','/system_setting','',900,1,'0,2',1,'父级菜单的sort值必须 > 子级菜单值','2020-12-01 16:02:05','2020-12-01 16:02:05'),
(3,2,'','系统菜单','','system_menu','system_menu','views/system-setting/sys_menu.vue',899,2,'0,2,3',1,'子级菜单值只要保证 < 父级菜单的sort值即可,子级菜单互相之间没有限制','2020-12-01 16:07:03','2021-03-20 13:24:34'),
(4,2,'','组织机构','','organization','organization','views/system-setting/organization.vue',898,2,'0,2,4',1,'','2020-12-01 16:29:21','2021-03-23 14:27:36'),
(5,2,'','岗位成员','','post_members','post_members','views/system-setting/org_members.vue',897,2,'0,2,5',1,'','2020-12-01 16:36:43','2021-03-23 14:30:51'),
(6,2,'','用户管理','','user','user','views/system-setting/user.vue',896,2,'0,2,6',1,'','2020-12-01 16:37:03','2021-03-23 14:31:15'),
(7,2,'','权限分配','','org_post_auth_assignment','org_post_auth_assignment','views/system-setting/auth_assignment.vue',894,2,'0,2,7',1,'','2020-12-01 16:42:08','2020-12-01 16:42:08'),
(8,2,'','权限分析','','org_post_auth_analysis','org_post_auth_analysis','views/system-setting/auth_analysis.vue',893,2,'0,2,8',1,'','2020-12-01 16:44:39','2020-12-01 16:44:39'),
(10,2,'','按钮设置','','button_cn_en','button_cn_en','views/system-setting/button_cn_en.vue',895,2,'0,2,10',1,'','2021-01-27 16:12:19','2021-03-23 14:26:48'),
(39,2,'','公共权限','','common_auth','common_auth','disabled',892,2,'0,2,39',0,'本条菜单用于绑定公共权限，分配给顶级组织机构节点，供其他节点继承，前台不可见','2021-03-10 17:43:01','2022-01-19 14:23:06'),
(41,0,'Grid','基础数据','','data-dictionary','/data_dictionary','',850,1,'0,41',1,'父级菜单的sort值必须 > 子级菜单值','2021-03-20 15:00:52','2021-03-23 14:28:59'),
(42,41,'','省份城市','','province_city','province_city','views/data-dictionary/province_city.vue',849,2,'0,41,42',1,'','2021-03-20 15:01:52','2021-03-23 14:31:53'),
(49,41,'Menu','测试菜单','','test_menu','','views/data-dictionary/test_menu.vue',1,2,'0,41,49',1,'','2022-06-03 19:34:54','2022-06-03 19:34:54');

/*Table structure for table `tb_auth_system_menu_button` */

DROP TABLE IF EXISTS `tb_auth_system_menu_button`;

CREATE TABLE `tb_auth_system_menu_button` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_auth_system_menu_id` int(10) unsigned NOT NULL COMMENT '系统菜单ID',
  `fr_auth_button_cn_en_id` int(10) unsigned NOT NULL COMMENT '菜单挂接的按钮id',
  `request_url` varchar(100) DEFAULT '',
  `request_method` varchar(20) DEFAULT '*',
  `status` tinyint(4) DEFAULT 1,
  `remark` varchar(100) DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

/*Data for the table `tb_auth_system_menu_button` */

insert  into `tb_auth_system_menu_button`(`id`,`fr_auth_system_menu_id`,`fr_auth_button_cn_en_id`,`request_url`,`request_method`,`status`,`remark`,`created_at`,`updated_at`) values 
(1,6,1,'/admin/users/create','POST',1,'6=用户管理菜单|增','2021-01-27 16:27:09','2021-01-27 16:27:09'),
(2,6,2,'/admin/users/destroy','POST',1,'删','2021-01-27 16:27:17','2021-01-27 16:27:17'),
(3,6,3,'/admin/users/edit','POST',1,'改','2021-01-27 16:27:20','2021-01-27 16:27:20'),
(4,6,4,'/admin/users/list*','GET',1,'查','2021-01-27 16:27:24','2021-01-27 16:27:24'),
(5,5,1,'/admin/post_members/create','POST',1,'5=岗位成员菜单','2021-01-27 17:55:15','2021-01-27 17:55:15'),
(6,5,2,'/admin/post_members/destroy','POST',1,'','2021-01-27 17:55:18','2021-01-27 17:55:18'),
(7,5,3,'/admin/post_members/edit','POST',1,'','2021-01-27 17:55:21','2021-01-27 17:55:21'),
(8,5,4,'/admin/post_members/list*','GET',1,'','2021-01-27 17:55:25','2021-01-27 17:55:25'),
(9,4,1,'/admin/organization/create','POST',1,'4=组织机构菜单','2021-01-27 17:55:28','2021-01-27 17:55:28'),
(10,4,2,'/admin/organization/destroy','POST',1,'','2021-01-27 17:55:30','2021-01-27 17:55:30'),
(11,4,3,'/admin/organization/edit','POST',1,'','2021-01-27 17:55:33','2021-01-27 17:55:33'),
(12,4,4,'/admin/organization/list*','GET',1,'','2021-01-27 17:55:37','2021-01-27 17:55:37'),
(13,7,1,'/admin/system_menu/assgin_to_org','POST',1,'分配权限=新增(按钮)','2021-03-09 17:25:49','2021-03-09 17:25:49'),
(14,7,2,'/admin/system_menu/del_auth_from_org','POST',1,'删除权限=删除(按钮)','2021-03-09 17:27:58','2021-03-09 17:27:58'),
(31,3,1,'/admin/system_menu/create','POST',1,'','2021-03-10 17:22:42','2021-03-10 17:22:42'),
(32,3,2,'/admin/system_menu/destroy','POST',1,'','2021-03-10 17:22:45','2021-03-10 17:22:45'),
(33,3,3,'/admin/system_menu/edit','POST',1,'','2021-03-10 17:23:13','2021-03-10 17:23:13'),
(34,3,4,'/admin/system_menu/list*','GET',1,'','2021-03-10 17:23:38','2021-03-10 17:23:38'),
(35,39,25,'/admin/users/info*','GET',1,'','2021-03-10 17:43:01','2022-01-19 14:23:06'),
(36,39,26,'/admin/users/has_view_button_list*','GET',1,'','2021-03-10 18:12:22','2022-01-19 14:23:06'),
(37,39,27,'/admin/organization/get_by_fid*','GET',1,'','2021-03-10 18:12:22','2022-01-19 14:23:06'),
(38,39,29,'/admin/system_menu/get_by_fid*','GET',1,'','2021-03-10 18:12:22','2022-01-19 14:23:06'),
(39,39,28,'/admin/button_cn_en/get_button_info*','GET',1,'','2021-03-10 18:12:22','2022-01-19 14:23:06'),
(41,7,31,'/admin/system_menu/assgined_list*','GET',1,'','2021-03-11 17:27:02','2021-03-11 17:27:02'),
(43,7,30,'/admin/system_menu/all_list*','GET',1,'','2021-03-11 17:42:24','2021-03-11 17:42:24'),
(44,39,33,'/admin/button_cn_en/list*','GET',1,'','2021-03-11 17:55:23','2022-01-19 14:23:06'),
(45,8,4,'/admin/auth_analysis/user_list_with_post*','GET',1,'','2021-03-11 18:08:02','2021-03-11 18:08:02'),
(46,8,32,'/admin/auth_analysis/has_auth_list*','GET',1,'','2021-03-11 18:08:02','2021-03-11 18:08:02'),
(47,10,1,'/admin/button/create','POST',1,'','2021-03-11 18:15:23','2021-03-11 18:15:23'),
(48,10,2,'/admin/button/destroy','POST',1,'','2021-03-11 18:15:44','2021-03-11 18:15:44'),
(49,10,3,'/admin/button/edit','POST',1,'','2021-03-11 18:15:49','2021-03-11 18:15:49'),
(50,10,4,'/admin/button/list*','GET',1,'','2021-03-11 18:15:55','2021-03-11 18:15:55'),
(51,3,28,'/admin/system_menu/mount_auth_button*','GET',1,'','2021-03-11 23:40:29','2021-03-11 23:40:29'),
(57,39,37,'/admin/upload/files','POST',1,'','2021-03-15 16:16:29','2022-01-19 14:23:06'),
(59,3,29,'/admin/system_menu/get_by_fid*','GET',1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(68,42,1,'/admin/province_city/create','POST',1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(69,42,2,'/admin/province_city/destroy','POST',1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(70,42,3,'/admin/province_city/edit','POST',1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(71,42,4,'/admin/province_city/list*','GET',1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(72,42,24,'/admin/province_city/get_sublist*','GET',1,'查询子级','0000-00-00 00:00:00','0000-00-00 00:00:00'),
(77,39,24,'/admin/users/personal_info*','GET',1,'个人基本信息-右上角编辑使用','2022-01-19 14:23:06','2022-01-19 14:23:06'),
(78,39,23,'/admin/users/personal_edit','POST',1,'个人信息编辑-右上角编辑使用','2022-01-19 14:23:06','2022-01-19 14:23:06'),
(83,49,1,'/test_menu/insert','POST',1,'','2022-06-03 19:34:54','2022-06-03 19:34:54'),
(84,49,2,'/test_menu/delete','POST',1,'','2022-06-03 19:34:54','2022-06-03 19:34:54'),
(85,49,3,'/test_menu/update','POST',1,'','2022-06-03 19:34:54','2022-06-03 19:34:54'),
(86,49,4,'/test_menu/select*','GET',1,'','2022-06-03 19:34:54','2022-06-03 19:34:54'),
(87,49,24,'/test_menu/select2*','GET',1,'','2022-06-03 19:34:54','2022-06-03 19:34:54');

/*Table structure for table `tb_oauth_access_tokens` */

DROP TABLE IF EXISTS `tb_oauth_access_tokens`;

CREATE TABLE `tb_oauth_access_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_user_id` int(11) DEFAULT 0 COMMENT '外键:tb_users表id',
  `client_id` int(10) unsigned DEFAULT 1 COMMENT '普通用户的授权，默认为1',
  `token` varchar(600) DEFAULT NULL,
  `action_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'login|update|reset表示token生成动作',
  `scopes` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '[*]' COMMENT '暂时预留,未启用',
  `revoked` tinyint(1) DEFAULT 0 COMMENT '是否撤销',
  `client_ip` varchar(128) DEFAULT NULL COMMENT 'ipv6最长为128位',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`fr_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `tb_oauth_access_tokens` */

/*Table structure for table `tb_oauth_access_tokens_del` */

DROP TABLE IF EXISTS `tb_oauth_access_tokens_del`;

CREATE TABLE `tb_oauth_access_tokens_del` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fr_user_id` int(11) DEFAULT 0 COMMENT '外键:tb_users表id',
  `client_id` int(10) unsigned DEFAULT 1 COMMENT '普通用户的授权，默认为1',
  `token` varchar(600) DEFAULT NULL,
  `action_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'login|update|reset表示token生成动作',
  `scopes` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '[*]' COMMENT '暂时预留,未启用',
  `revoked` tinyint(1) DEFAULT 0 COMMENT '是否撤销',
  `client_ip` varchar(128) DEFAULT NULL COMMENT 'ipv6最长为128位',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`fr_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `tb_oauth_access_tokens_del` */

insert  into `tb_oauth_access_tokens_del`(`id`,`fr_user_id`,`client_id`,`token`,`action_name`,`scopes`,`revoked`,`client_ip`,`created_at`,`updated_at`,`expires_at`) values 
(2,1,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJ1c2VyX25hbWUiOiJhZG1pbiIsInBob25lIjoiMTU4MDQwMzc5MjkiLCJleHAiOjE2NTQ0NTA5NTAsIm5iZiI6MTY1NDQyMjE0MH0.s-aQcCjFX37zvwjMSqZnjzWLH9PYs4Vc0dy-knH82Jo','login','[*]',0,'127.0.0.1','2022-06-05 17:42:30','2022-06-05 17:42:30','2022-06-06 01:42:30');

/*Table structure for table `tb_province_city` */

DROP TABLE IF EXISTS `tb_province_city`;

CREATE TABLE `tb_province_city` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL DEFAULT 0 COMMENT '父级ID',
  `name` varchar(120) NOT NULL DEFAULT '' COMMENT '省份、城市名',
  `node_level` tinyint(4) NOT NULL DEFAULT 0 COMMENT '节点级别',
  `zone_code` varchar(30) DEFAULT '' COMMENT '区号',
  `zip_code` varchar(30) DEFAULT '' COMMENT '邮编',
  `path_info` varchar(120) DEFAULT '' COMMENT '路径信息',
  `status` tinyint(4) DEFAULT 1 COMMENT '状态：创建|审核|发布',
  `sort` int(6) NOT NULL DEFAULT 0 COMMENT '排序',
  `remark` varchar(120) DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3672 DEFAULT CHARSET=utf8;

/*Data for the table `tb_province_city` */

insert  into `tb_province_city`(`id`,`fid`,`name`,`node_level`,`zone_code`,`zip_code`,`path_info`,`status`,`sort`,`remark`,`created_at`,`updated_at`) values 
(1,0,'中国',0,'0086','0','0,1',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2,1,'北京',1,'0','110000','0,1,2',1,0,'','2021-03-20 17:34:36','2022-05-28 14:07:44'),
(3,1,'安徽',1,'0','340000','0,1,3',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(4,1,'福建',1,'0','350000','0,1,4',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(5,1,'甘肃',1,'0','620000','0,1,5',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(6,1,'广东',1,'0','440000','0,1,6',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(7,1,'广西',1,'0','450000','0,1,7',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(8,1,'贵州',1,'0','520000','0,1,8',1,0,'','2021-03-20 17:34:36','2022-05-28 14:09:25'),
(9,1,'海南',1,'0','460000','0,1,9',1,0,'','2021-03-20 17:34:36','2022-05-28 14:09:49'),
(10,1,'河北',1,'0','130000','0,1,10',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(11,1,'河南',1,'0','410000','0,1,11',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(12,1,'黑龙江',1,'0','230000','0,1,12',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(13,1,'湖北',1,'0','420000','0,1,13',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(14,1,'湖南',1,'0','430000','0,1,14',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(15,1,'吉林',1,'0','220000','0,1,15',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(16,1,'江苏',1,'0','320000','0,1,16',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(17,1,'江西',1,'0','360000','0,1,17',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(18,1,'辽宁',1,'0','210000','0,1,18',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(19,1,'内蒙古',1,'0','150000','0,1,19',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(20,1,'宁夏',1,'0','640000','0,1,20',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(21,1,'青海',1,'0','630000','0,1,21',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(22,1,'山东',1,'0','370000','0,1,22',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(23,1,'山西',1,'0','140000','0,1,23',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(24,1,'陕西',1,'0','610000','0,1,24',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(25,1,'上海',1,'0','310000','0,1,25',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(26,1,'四川',1,'0','510000','0,1,26',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(27,1,'天津',1,'0','120000','0,1,27',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(28,1,'西藏',1,'0','540000','0,1,28',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(29,1,'新疆',1,'0','650000','0,1,29',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(30,1,'云南',1,'0','530000','0,1,30',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(31,1,'浙江',1,'0','330000','0,1,31',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(32,1,'重庆',1,'0','500000','0,1,32',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(33,1,'香港',1,'0852','810000','0,1,33',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(34,1,'澳门',1,'0853','820000','0,1,34',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(35,1,'台湾',1,'0886','710000','0,1,35',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(36,3,'安庆',2,'0556','340800','0,1,3,36',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(37,3,'蚌埠',2,'0552','340300','0,1,3,37',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(38,3,'巢湖',2,'0565','341400','0,1,3,38',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(39,3,'池州',2,'0566','341700','0,1,3,39',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(40,3,'滁州',2,'0550','341100','0,1,3,40',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(41,3,'阜阳',2,'0558','341200','0,1,3,41',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(42,3,'淮北',2,'0561','340600','0,1,3,42',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(43,3,'淮南',2,'0554','340400','0,1,3,43',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(44,3,'黄山',2,'0559','341000','0,1,3,44',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(45,3,'六安',2,'0564','341500','0,1,3,45',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(46,3,'马鞍山',2,'0555','340500','0,1,3,46',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(47,3,'宿州',2,'0557','341300','0,1,3,47',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(48,3,'铜陵',2,'0562','340700','0,1,3,48',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(49,3,'芜湖',2,'0553','340200','0,1,3,49',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(50,3,'宣城',2,'0563','341800','0,1,3,50',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(51,3,'亳州',2,'0558','341600','0,1,3,51',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(52,2,'北京',2,'0010','110100','0,1,2,52',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(53,4,'福州',2,'0591','350100','0,1,4,53',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(54,4,'龙岩',2,'0597','350800','0,1,4,54',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(55,4,'南平',2,'0599','350700','0,1,4,55',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(56,4,'宁德',2,'0593','350900','0,1,4,56',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(57,4,'莆田',2,'0594','350300','0,1,4,57',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(58,4,'泉州',2,'0595','350500','0,1,4,58',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(59,4,'三明',2,'0598','350400','0,1,4,59',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(60,4,'厦门',2,'0592','350200','0,1,4,60',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(61,4,'漳州',2,'0596','350600','0,1,4,61',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(62,5,'兰州',2,'0931','620100','0,1,5,62',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(63,5,'白银',2,'0943','620400','0,1,5,63',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(64,5,'定西',2,'0932','621100','0,1,5,64',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(65,5,'甘南',2,'0941','623000','0,1,5,65',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(66,5,'嘉峪关',2,'0937','620200','0,1,5,66',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(67,5,'金昌',2,'0935','620300','0,1,5,67',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(68,5,'酒泉',2,'0937','620900','0,1,5,68',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(69,5,'临夏',2,'0930','622900','0,1,5,69',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(70,5,'陇南',2,'0939','621200','0,1,5,70',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(71,5,'平凉',2,'0933','620800','0,1,5,71',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(72,5,'庆阳',2,'0934','621000','0,1,5,72',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(73,5,'天水',2,'0938','620500','0,1,5,73',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(74,5,'武威',2,'0935','620600','0,1,5,74',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(75,5,'张掖',2,'0936','620700','0,1,5,75',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(76,6,'广州',2,'0020','440100','0,1,6,76',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(77,6,'深圳',2,'0755','440300','0,1,6,77',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(78,6,'潮州',2,'0768','445100','0,1,6,78',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(79,6,'东莞',2,'0769','441900','0,1,6,79',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(80,6,'佛山',2,'0757','440600','0,1,6,80',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(81,6,'河源',2,'0762','441600','0,1,6,81',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(82,6,'惠州',2,'0752','441300','0,1,6,82',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(83,6,'江门',2,'0750','440700','0,1,6,83',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(84,6,'揭阳',2,'0663','445200','0,1,6,84',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(85,6,'茂名',2,'0668','440900','0,1,6,85',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(86,6,'梅州',2,'0753','441400','0,1,6,86',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(87,6,'清远',2,'0763','441800','0,1,6,87',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(88,6,'汕头',2,'0754','440500','0,1,6,88',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(89,6,'汕尾',2,'0660','441500','0,1,6,89',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(90,6,'韶关',2,'0751','440200','0,1,6,90',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(91,6,'阳江',2,'0662','441700','0,1,6,91',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(92,6,'云浮',2,'0766','445300','0,1,6,92',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(93,6,'湛江',2,'0759','440800','0,1,6,93',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(94,6,'肇庆',2,'0758','441200','0,1,6,94',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(95,6,'中山',2,'0760','442000','0,1,6,95',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(96,6,'珠海',2,'0756','440400','0,1,6,96',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(97,7,'南宁',2,'0771','450100','0,1,7,97',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(98,7,'桂林',2,'0773','450300','0,1,7,98',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(99,7,'百色',2,'0776','451000','0,1,7,99',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(100,7,'北海',2,'0779','450500','0,1,7,100',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(101,7,'崇左',2,'0771','451400','0,1,7,101',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(102,7,'防城港',2,'0770','450600','0,1,7,102',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(103,7,'贵港',2,'0775','450800','0,1,7,103',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(104,7,'河池',2,'0778','451200','0,1,7,104',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(105,7,'贺州',2,'0774','451100','0,1,7,105',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(106,7,'来宾',2,'0772','451300','0,1,7,106',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(107,7,'柳州',2,'0772','450200','0,1,7,107',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(108,7,'钦州',2,'0777','450700','0,1,7,108',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(109,7,'梧州',2,'0774','450400','0,1,7,109',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(110,7,'玉林',2,'0775','450900','0,1,7,110',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(111,8,'贵阳',2,'0851','520100','0,1,8,111',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(112,8,'安顺',2,'0853','520400','0,1,8,112',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(113,8,'毕节',2,'0857','522400','0,1,8,113',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(114,8,'六盘水',2,'0858','520200','0,1,8,114',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(115,8,'黔东南',2,'0855','522600','0,1,8,115',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(116,8,'黔南',2,'0854','522700','0,1,8,116',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(117,8,'黔西南',2,'0859','522300','0,1,8,117',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(118,8,'铜仁',2,'0856','522200','0,1,8,118',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(119,8,'遵义',2,'0852','520300','0,1,8,119',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(120,9,'海口',2,'0898','460100','0,1,9,120',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(121,9,'三亚',2,'0898','460200','0,1,9,121',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(122,9,'白沙',2,'0898','469030','0,1,9,122',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(123,9,'保亭',2,'0898','469035','0,1,9,123',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(124,9,'昌江',2,'0898','469031','0,1,9,124',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(125,9,'澄迈县',2,'0898','469027','0,1,9,125',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(126,9,'定安县',2,'0898','469025','0,1,9,126',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(127,9,'东方',2,'0898','469007','0,1,9,127',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(128,9,'乐东',2,'0898','469033','0,1,9,128',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(129,9,'临高县',2,'0898','469028','0,1,9,129',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(130,9,'陵水',2,'0898','469034','0,1,9,130',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(131,9,'琼海',2,'0898','469002','0,1,9,131',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(132,9,'琼中',2,'0898','469036','0,1,9,132',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(133,9,'屯昌县',2,'0898','469026','0,1,9,133',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(134,9,'万宁',2,'0898','469006','0,1,9,134',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(135,9,'文昌',2,'0898','469005','0,1,9,135',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(136,9,'五指山',2,'0898','469001','0,1,9,136',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(137,9,'儋州',2,'0898','469003','0,1,9,137',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(138,10,'石家庄',2,'0311','130100','0,1,10,138',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(139,10,'保定',2,'0312','130600','0,1,10,139',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(140,10,'沧州',2,'0317','130900','0,1,10,140',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(141,10,'承德',2,'0314','130800','0,1,10,141',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(142,10,'邯郸',2,'0310','130400','0,1,10,142',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(143,10,'衡水',2,'0318','131100','0,1,10,143',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(144,10,'廊坊',2,'0316','131000','0,1,10,144',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(145,10,'秦皇岛',2,'0335','130300','0,1,10,145',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(146,10,'唐山',2,'0315','130200','0,1,10,146',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(147,10,'邢台',2,'0319','130500','0,1,10,147',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(148,10,'张家口',2,'0313','130700','0,1,10,148',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(149,11,'郑州',2,'0371','410100','0,1,11,149',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(150,11,'洛阳',2,'0379','410300','0,1,11,150',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(151,11,'开封',2,'0378','410200','0,1,11,151',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(152,11,'安阳',2,'0372','410500','0,1,11,152',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(153,11,'鹤壁',2,'0392','410600','0,1,11,153',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(155,11,'焦作',2,'0391','410800','0,1,11,155',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(156,11,'南阳',2,'0377','411300','0,1,11,156',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(157,11,'平顶山',2,'0375','410400','0,1,11,157',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(158,11,'三门峡',2,'0398','411200','0,1,11,158',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(159,11,'商丘',2,'0370','411400','0,1,11,159',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(160,11,'新乡',2,'0373','410700','0,1,11,160',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(161,11,'信阳',2,'0376','411500','0,1,11,161',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(162,11,'许昌',2,'0374','411000','0,1,11,162',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(163,11,'周口',2,'0394','411600','0,1,11,163',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(164,11,'驻马店',2,'0396','411700','0,1,11,164',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(165,11,'漯河',2,'0395','411100','0,1,11,165',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(166,11,'濮阳',2,'0393','410900','0,1,11,166',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(167,12,'哈尔滨',2,'0451','230100','0,1,12,167',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(168,12,'大庆',2,'0459','230600','0,1,12,168',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(169,12,'大兴安岭',2,'0457','232700','0,1,12,169',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(170,12,'鹤岗',2,'0468','230400','0,1,12,170',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(171,12,'黑河',2,'0456','231100','0,1,12,171',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(172,12,'鸡西',2,'0467','230300','0,1,12,172',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(173,12,'佳木斯',2,'0454','230800','0,1,12,173',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(174,12,'牡丹江',2,'0453','231000','0,1,12,174',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(175,12,'七台河',2,'0464','230900','0,1,12,175',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(176,12,'齐齐哈尔',2,'0452','230200','0,1,12,176',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(177,12,'双鸭山',2,'0469','230500','0,1,12,177',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(178,12,'绥化',2,'0455','231200','0,1,12,178',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(179,12,'伊春',2,'0458','230700','0,1,12,179',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(180,13,'武汉',2,'0027','420100','0,1,13,180',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(181,13,'仙桃',2,'0728','429004','0,1,13,181',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(182,13,'鄂州',2,'0711','420700','0,1,13,182',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(183,13,'黄冈',2,'0713','421100','0,1,13,183',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(184,13,'黄石',2,'0714','420200','0,1,13,184',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(185,13,'荆门',2,'0724','420800','0,1,13,185',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(186,13,'荆州',2,'0716','421000','0,1,13,186',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(187,13,'潜江',2,'0728','429005','0,1,13,187',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(188,13,'神农架林区',2,'0719','429021','0,1,13,188',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(189,13,'十堰',2,'0719','420300','0,1,13,189',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(190,13,'随州',2,'0722','421300','0,1,13,190',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(191,13,'天门',2,'0728','429006','0,1,13,191',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(192,13,'咸宁',2,'0715','421200','0,1,13,192',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(193,13,'襄樊',2,'0710','420600','0,1,13,193',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(194,13,'孝感',2,'0712','420900','0,1,13,194',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(195,13,'宜昌',2,'0717','420500','0,1,13,195',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(196,13,'恩施',2,'0718','422800','0,1,13,196',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(197,14,'长沙',2,'0731','430100','0,1,14,197',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(198,14,'张家界',2,'0744','430800','0,1,14,198',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(199,14,'常德',2,'0736','430700','0,1,14,199',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(200,14,'郴州',2,'0735','431000','0,1,14,200',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(201,14,'衡阳',2,'0734','430400','0,1,14,201',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(202,14,'怀化',2,'0745','431200','0,1,14,202',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(203,14,'娄底',2,'0738','431300','0,1,14,203',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(204,14,'邵阳',2,'0739','430500','0,1,14,204',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(205,14,'湘潭',2,'0732','430300','0,1,14,205',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(206,14,'湘西',2,'0743','433100','0,1,14,206',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(207,14,'益阳',2,'0737','430900','0,1,14,207',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(208,14,'永州',2,'0746','431100','0,1,14,208',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(209,14,'岳阳',2,'0730','430600','0,1,14,209',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(210,14,'株洲',2,'0733','430200','0,1,14,210',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(211,15,'长春',2,'0431','220100','0,1,15,211',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(212,15,'吉林',2,'0432','220200','0,1,15,212',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(213,15,'白城',2,'0436','220800','0,1,15,213',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(214,15,'白山',2,'0439','220600','0,1,15,214',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(215,15,'辽源',2,'0437','220400','0,1,15,215',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(216,15,'四平',2,'0434','220300','0,1,15,216',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(217,15,'松原',2,'0438','220700','0,1,15,217',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(218,15,'通化',2,'0435','220500','0,1,15,218',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(219,15,'延边',2,'0433','222400','0,1,15,219',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(220,16,'南京',2,'0025','320100','0,1,16,220',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(221,16,'苏州',2,'0512','320500','0,1,16,221',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(222,16,'无锡',2,'0510','320200','0,1,16,222',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(223,16,'常州',2,'0519','320400','0,1,16,223',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(224,16,'淮安',2,'0517','320800','0,1,16,224',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(225,16,'连云港',2,'0518','320700','0,1,16,225',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(226,16,'南通',2,'0513','320600','0,1,16,226',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(227,16,'宿迁',2,'0527','321300','0,1,16,227',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(228,16,'泰州',2,'0523','321200','0,1,16,228',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(229,16,'徐州',2,'0516','320300','0,1,16,229',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(230,16,'盐城',2,'0515','320900','0,1,16,230',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(231,16,'扬州',2,'0514','321000','0,1,16,231',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(232,16,'镇江',2,'0511','321100','0,1,16,232',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(233,17,'南昌',2,'0791','360100','0,1,17,233',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(234,17,'抚州',2,'0794','361000','0,1,17,234',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(235,17,'赣州',2,'0797','360700','0,1,17,235',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(236,17,'吉安',2,'0796','360800','0,1,17,236',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(237,17,'景德镇',2,'0798','360200','0,1,17,237',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(238,17,'九江',2,'0792','360400','0,1,17,238',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(239,17,'萍乡',2,'0799','360300','0,1,17,239',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(240,17,'上饶',2,'0793','361100','0,1,17,240',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(241,17,'新余',2,'0790','360500','0,1,17,241',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(242,17,'宜春',2,'0795','360900','0,1,17,242',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(243,17,'鹰潭',2,'0701','360600','0,1,17,243',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(244,18,'沈阳',2,'0024','210100','0,1,18,244',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(245,18,'大连',2,'0411','210200','0,1,18,245',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(246,18,'鞍山',2,'0412','210300','0,1,18,246',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(247,18,'本溪',2,'0414','210500','0,1,18,247',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(248,18,'朝阳',2,'0421','211300','0,1,18,248',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(249,18,'丹东',2,'0415','210600','0,1,18,249',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(250,18,'抚顺',2,'0413','210400','0,1,18,250',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(251,18,'阜新',2,'0418','210900','0,1,18,251',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(252,18,'葫芦岛',2,'0429','211400','0,1,18,252',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(253,18,'锦州',2,'0416','210700','0,1,18,253',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(254,18,'辽阳',2,'0419','211000','0,1,18,254',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(255,18,'盘锦',2,'0427','211100','0,1,18,255',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(256,18,'铁岭',2,'0410','211200','0,1,18,256',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(257,18,'营口',2,'0417','210800','0,1,18,257',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(258,19,'呼和浩特',2,'0471','150100','0,1,19,258',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(259,19,'阿拉善盟',2,'0483','152900','0,1,19,259',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(260,19,'巴彦淖尔盟',2,'0478','150800','0,1,19,260',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(261,19,'包头',2,'0472','150200','0,1,19,261',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(262,19,'赤峰',2,'0476','150400','0,1,19,262',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(263,19,'鄂尔多斯',2,'0477','150600','0,1,19,263',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(264,19,'呼伦贝尔',2,'0470','150700','0,1,19,264',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(265,19,'通辽',2,'0475','150500','0,1,19,265',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(266,19,'乌海',2,'0473','150300','0,1,19,266',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(267,19,'乌兰察布市',2,'0474','150900','0,1,19,267',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(268,19,'锡林郭勒盟',2,'0479','152500','0,1,19,268',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(269,19,'兴安盟',2,'0482','152200','0,1,19,269',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(270,20,'银川',2,'0951','640100','0,1,20,270',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(271,20,'固原',2,'0954','640400','0,1,20,271',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(272,20,'石嘴山',2,'0952','640200','0,1,20,272',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(273,20,'吴忠',2,'0953','640300','0,1,20,273',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(274,20,'中卫',2,'0955','640500','0,1,20,274',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(275,21,'西宁',2,'0971','630100','0,1,21,275',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(276,21,'果洛',2,'0975','632600','0,1,21,276',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(277,21,'海北',2,'0970','632200','0,1,21,277',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(278,21,'海东',2,'0972','632100','0,1,21,278',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(279,21,'海南',2,'0974','632500','0,1,21,279',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(280,21,'海西',2,'0979','632800','0,1,21,280',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(281,21,'黄南',2,'0973','632300','0,1,21,281',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(282,21,'玉树',2,'0976','632700','0,1,21,282',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(283,22,'济南',2,'0531','370100','0,1,22,283',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(284,22,'青岛',2,'0532','370200','0,1,22,284',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(285,22,'滨州',2,'0543','371600','0,1,22,285',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(286,22,'德州',2,'0534','371400','0,1,22,286',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(287,22,'东营',2,'0546','370500','0,1,22,287',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(288,22,'菏泽',2,'0530','371700','0,1,22,288',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(289,22,'济宁',2,'0537','370800','0,1,22,289',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(290,22,'莱芜',2,'0634','371200','0,1,22,290',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(291,22,'聊城',2,'0635','371500','0,1,22,291',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(292,22,'临沂',2,'0539','371300','0,1,22,292',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(293,22,'日照',2,'0633','371100','0,1,22,293',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(294,22,'泰安',2,'0538','370900','0,1,22,294',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(295,22,'威海',2,'0631','371000','0,1,22,295',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(296,22,'潍坊',2,'0536','370700','0,1,22,296',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(297,22,'烟台',2,'0535','370600','0,1,22,297',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(298,22,'枣庄',2,'0632','370401','0,1,22,298',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(299,22,'淄博',2,'0533','370300','0,1,22,299',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(300,23,'太原',2,'0351','140100','0,1,23,300',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(301,23,'长治',2,'0355','140400','0,1,23,301',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(302,23,'大同',2,'0352','140200','0,1,23,302',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(303,23,'晋城',2,'0356','140500','0,1,23,303',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(304,23,'晋中',2,'0354','140700','0,1,23,304',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(305,23,'临汾',2,'0357','141000','0,1,23,305',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(306,23,'吕梁',2,'0358','141100','0,1,23,306',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(307,23,'朔州',2,'0349','140600','0,1,23,307',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(308,23,'忻州',2,'0350','140900','0,1,23,308',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(309,23,'阳泉',2,'0353','140300','0,1,23,309',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(310,23,'运城',2,'0359','140800','0,1,23,310',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(311,24,'西安',2,'0029','610100','0,1,24,311',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(312,24,'安康',2,'0915','610900','0,1,24,312',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(313,24,'宝鸡',2,'0917','610300','0,1,24,313',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(314,24,'汉中',2,'0916','610700','0,1,24,314',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(315,24,'商洛',2,'0914','611000','0,1,24,315',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(316,24,'铜川',2,'0919','610200','0,1,24,316',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(317,24,'渭南',2,'0913','610500','0,1,24,317',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(318,24,'咸阳',2,'0910','610400','0,1,24,318',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(319,24,'延安',2,'0911','610600','0,1,24,319',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(320,24,'榆林',2,'0912','610800','0,1,24,320',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(321,25,'上海',2,'0021','310100','0,1,25,321',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(322,26,'成都',2,'0028','510100','0,1,26,322',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(323,26,'绵阳',2,'0816','510700','0,1,26,323',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(324,26,'阿坝',2,'0837','513200','0,1,26,324',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(325,26,'巴中',2,'0827','511900','0,1,26,325',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(326,26,'达州',2,'0818','511700','0,1,26,326',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(327,26,'德阳',2,'0838','510600','0,1,26,327',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(328,26,'甘孜',2,'0836','513300','0,1,26,328',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(329,26,'广安',2,'0826','511600','0,1,26,329',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(330,26,'广元',2,'0839','510800','0,1,26,330',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(331,26,'乐山',2,'0833','511100','0,1,26,331',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(332,26,'凉山',2,'0834','513400','0,1,26,332',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(333,26,'眉山',2,'0833','511400','0,1,26,333',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(334,26,'南充',2,'0817','511300','0,1,26,334',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(335,26,'内江',2,'0832','511000','0,1,26,335',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(336,26,'攀枝花',2,'0812','510400','0,1,26,336',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(337,26,'遂宁',2,'0825','510900','0,1,26,337',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(338,26,'雅安',2,'0835','511800','0,1,26,338',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(339,26,'宜宾',2,'0831','511500','0,1,26,339',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(340,26,'资阳',2,'0832','512000','0,1,26,340',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(341,26,'自贡',2,'0813','510300','0,1,26,341',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(342,26,'泸州',2,'0830','510500','0,1,26,342',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(343,27,'天津',2,'0022','120100','0,1,27,343',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(344,28,'拉萨',2,'0891','540100','0,1,28,344',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(345,28,'阿里',2,'0897','542500','0,1,28,345',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(346,28,'昌都',2,'0895','542100','0,1,28,346',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(347,28,'林芝',2,'0894','542600','0,1,28,347',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(348,28,'那曲',2,'0896','542400','0,1,28,348',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(349,28,'日喀则',2,'0892','542300','0,1,28,349',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(350,28,'山南',2,'0893','542200','0,1,28,350',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(351,29,'乌鲁木齐市',2,'0991','650100','0,1,29,351',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(352,29,'阿克苏',2,'0997','652900','0,1,29,352',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(354,29,'巴音郭楞',2,'0996','652800','0,1,29,354',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(355,29,'博尔塔拉',2,'0909','652700','0,1,29,355',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(356,29,'昌吉',2,'0994','652300','0,1,29,356',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(357,29,'哈密',2,'0902','652200','0,1,29,357',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(358,29,'和田',2,'0903','653200','0,1,29,358',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(359,29,'喀什',2,'0998','653100','0,1,29,359',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(360,29,'克拉玛依',2,'0990','650200','0,1,29,360',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(361,29,'克孜勒苏',2,'0908','653000','0,1,29,361',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(364,29,'吐鲁番',2,'0995','652100','0,1,29,364',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(365,29,'省直辖',2,'0','659000','0,1,29,365',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(366,29,'伊犁',2,'0999','654000','0,1,29,366',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(367,30,'昆明',2,'0871','530100','0,1,30,367',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(368,30,'怒江',2,'0886','533300','0,1,30,368',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(369,30,'思茅',2,'0879','530800','0,1,30,369',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(370,30,'丽江',2,'0888','530700','0,1,30,370',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(371,30,'保山',2,'0875','530500','0,1,30,371',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(372,30,'楚雄',2,'0878','532300','0,1,30,372',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(373,30,'大理',2,'0872','532900','0,1,30,373',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(374,30,'德宏',2,'0692','533100','0,1,30,374',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(375,30,'迪庆',2,'0887','533400','0,1,30,375',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(376,30,'红河',2,'0873','532500','0,1,30,376',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(377,30,'临沧',2,'0883','530900','0,1,30,377',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(378,30,'曲靖',2,'0874','530300','0,1,30,378',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(379,30,'文山',2,'0876','532600','0,1,30,379',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(380,30,'西双版纳',2,'0691','532800','0,1,30,380',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(381,30,'玉溪',2,'0877','530400','0,1,30,381',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(382,30,'昭通',2,'0870','530600','0,1,30,382',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(383,31,'杭州',2,'0571','330100','0,1,31,383',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(384,31,'湖州',2,'0572','330500','0,1,31,384',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(385,31,'嘉兴',2,'0573','330400','0,1,31,385',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(386,31,'金华',2,'0579','330700','0,1,31,386',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(387,31,'丽水',2,'0578','331100','0,1,31,387',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(388,31,'宁波',2,'0574','330200','0,1,31,388',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(389,31,'绍兴',2,'0575','330600','0,1,31,389',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(390,31,'台州',2,'0576','331000','0,1,31,390',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(391,31,'温州',2,'0577','330300','0,1,31,391',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(392,31,'舟山',2,'0580','330900','0,1,31,392',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(393,31,'衢州',2,'0570','330800','0,1,31,393',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(394,32,'重庆',2,'0023','500100','0,1,32,394',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(395,33,'香港',2,'0','0','0,1,33,395',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(396,34,'澳门',2,'0','0','0,1,34,396',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(397,35,'台湾',2,'0','0','0,1,35,397',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(398,36,'迎江区',3,'0','340802','0,1,3,36,398',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(399,36,'大观区',3,'0','340803','0,1,3,36,399',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(400,36,'郊区',3,'0','340811','0,1,3,36,400',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(401,36,'桐城市',3,'0','340881','0,1,3,36,401',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(402,36,'怀宁县',3,'0','340822','0,1,3,36,402',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(403,36,'枞阳县',3,'0','340823','0,1,3,36,403',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(404,36,'潜山县',3,'0','340824','0,1,3,36,404',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(405,36,'太湖县',3,'0','340825','0,1,3,36,405',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(406,36,'宿松县',3,'0','340826','0,1,3,36,406',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(407,36,'望江县',3,'0','340827','0,1,3,36,407',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(408,36,'岳西县',3,'0','340828','0,1,3,36,408',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(409,37,'龙子湖区',3,'0','340302','0,1,3,37,409',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(410,37,'蚌山区',3,'0','340303','0,1,3,37,410',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(411,37,'禹会区',3,'0','340304','0,1,3,37,411',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(412,37,'淮上区',3,'0','340311','0,1,3,37,412',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(413,37,'怀远县',3,'0','340321','0,1,3,37,413',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(414,37,'五河县',3,'0','340322','0,1,3,37,414',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(415,37,'固镇县',3,'0','340323','0,1,3,37,415',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(416,38,'居巢区',3,'0','341402','0,1,3,38,416',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(417,38,'庐江县',3,'0','341421','0,1,3,38,417',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(418,38,'无为县',3,'0','341422','0,1,3,38,418',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(419,38,'含山县',3,'0','341423','0,1,3,38,419',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(420,38,'和县',3,'0','341424','0,1,3,38,420',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(421,39,'贵池区',3,'0','341702','0,1,3,39,421',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(422,39,'东至县',3,'0','341721','0,1,3,39,422',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(423,39,'石台县',3,'0','341722','0,1,3,39,423',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(424,39,'青阳县',3,'0','341723','0,1,3,39,424',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(425,40,'琅琊区',3,'0','341102','0,1,3,40,425',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(426,40,'南谯区',3,'0','341103','0,1,3,40,426',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(427,40,'天长市',3,'0','341181','0,1,3,40,427',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(428,40,'明光市',3,'0','341182','0,1,3,40,428',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(429,40,'来安县',3,'0','341122','0,1,3,40,429',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(430,40,'全椒县',3,'0','341124','0,1,3,40,430',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(431,40,'定远县',3,'0','341125','0,1,3,40,431',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(432,40,'凤阳县',3,'0','341126','0,1,3,40,432',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(437,41,'颍州区',3,'0','341202','0,1,3,41,437',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(438,41,'颍东区',3,'0','341203','0,1,3,41,438',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(439,41,'颍泉区',3,'0','341204','0,1,3,41,439',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(440,41,'界首市',3,'0','341282','0,1,3,41,440',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(441,41,'临泉县',3,'0','341221','0,1,3,41,441',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(442,41,'太和县',3,'0','341222','0,1,3,41,442',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(443,41,'阜南县',3,'0','341225','0,1,3,41,443',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(444,41,'颍上县',3,'0','341226','0,1,3,41,444',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(445,42,'相山区',3,'0','340603','0,1,3,42,445',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(446,42,'杜集区',3,'0','340602','0,1,3,42,446',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(447,42,'烈山区',3,'0','340604','0,1,3,42,447',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(448,42,'濉溪县',3,'0','340621','0,1,3,42,448',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(449,43,'田家庵区',3,'0','340403','0,1,3,43,449',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(450,43,'大通区',3,'0','340402','0,1,3,43,450',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(451,43,'谢家集区',3,'0','340404','0,1,3,43,451',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(452,43,'八公山区',3,'0','340405','0,1,3,43,452',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(453,43,'潘集区',3,'0','340406','0,1,3,43,453',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(454,43,'凤台县',3,'0','340421','0,1,3,43,454',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(455,44,'屯溪区',3,'0','341002','0,1,3,44,455',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(456,44,'黄山区',3,'0','341003','0,1,3,44,456',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(457,44,'徽州区',3,'0','341004','0,1,3,44,457',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(458,44,'歙县',3,'0','341021','0,1,3,44,458',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(459,44,'休宁县',3,'0','341022','0,1,3,44,459',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(460,44,'黟县',3,'0','341023','0,1,3,44,460',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(461,44,'祁门县',3,'0','341024','0,1,3,44,461',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(462,45,'金安区',3,'0','341502','0,1,3,45,462',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(463,45,'裕安区',3,'0','341503','0,1,3,45,463',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(464,45,'寿县',3,'0','341521','0,1,3,45,464',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(465,45,'霍邱县',3,'0','341522','0,1,3,45,465',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(466,45,'舒城县',3,'0','341523','0,1,3,45,466',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(467,45,'金寨县',3,'0','341524','0,1,3,45,467',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(468,45,'霍山县',3,'0','341525','0,1,3,45,468',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(469,46,'雨山区',3,'0','340504','0,1,3,46,469',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(470,46,'花山区',3,'0','340503','0,1,3,46,470',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(471,46,'金家庄区',3,'0','340502','0,1,3,46,471',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(472,46,'当涂县',3,'0','340521','0,1,3,46,472',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(473,47,'墉桥区',3,'0','341302','0,1,3,47,473',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(474,47,'砀山县',3,'0','341321','0,1,3,47,474',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(475,47,'萧县',3,'0','341322','0,1,3,47,475',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(476,47,'灵璧县',3,'0','341323','0,1,3,47,476',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(477,47,'泗县',3,'0','341324','0,1,3,47,477',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(478,48,'铜官山区',3,'0','340702','0,1,3,48,478',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(479,48,'狮子山区',3,'0','340703','0,1,3,48,479',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(480,48,'郊区',3,'0','340711','0,1,3,48,480',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(481,48,'铜陵县',3,'0','340721','0,1,3,48,481',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(482,49,'镜湖区',3,'0','340202','0,1,3,49,482',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(483,49,'马塘区',3,'0','340203','0,1,3,49,483',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(484,49,'鸠江区',3,'0','340207','0,1,3,49,484',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(485,49,'新芜区',3,'0','340204','0,1,3,49,485',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(486,49,'芜湖县',3,'0','340221','0,1,3,49,486',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(487,49,'繁昌县',3,'0','340222','0,1,3,49,487',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(488,49,'南陵县',3,'0','340223','0,1,3,49,488',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(489,50,'宣州区',3,'0','341802','0,1,3,50,489',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(490,50,'宁国市',3,'0','341881','0,1,3,50,490',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(491,50,'郎溪县',3,'0','341821','0,1,3,50,491',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(492,50,'广德县',3,'0','341822','0,1,3,50,492',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(493,50,'泾县',3,'0','341823','0,1,3,50,493',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(494,50,'绩溪县',3,'0','341824','0,1,3,50,494',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(495,50,'旌德县',3,'0','341825','0,1,3,50,495',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(496,51,'涡阳县',3,'0','341621','0,1,3,51,496',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(497,51,'蒙城县',3,'0','341622','0,1,3,51,497',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(498,51,'利辛县',3,'0','341623','0,1,3,51,498',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(499,51,'谯城区',3,'0','341602','0,1,3,51,499',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(500,52,'东城区',3,'0','110101','0,1,2,52,500',1,0,'','2021-03-20 17:34:36','2021-03-22 22:23:38'),
(501,52,'西城区',3,'0','110102','0,1,2,52,501',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(502,52,'海淀区',3,'0','110108','0,1,2,52,502',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(503,52,'朝阳区',3,'0','110105','0,1,2,52,503',1,10,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(504,52,'崇文区',3,'0','110103','0,1,2,52,504',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(505,52,'宣武区',3,'0','110104','0,1,2,52,505',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(506,52,'丰台区',3,'0','110106','0,1,2,52,506',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(507,52,'石景山区',3,'0','110107','0,1,2,52,507',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(508,52,'房山区',3,'0','110111','0,1,2,52,508',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(509,52,'门头沟区',3,'0','110109','0,1,2,52,509',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(510,52,'通州区',3,'0','110112','0,1,2,52,510',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(511,52,'顺义区',3,'0','110113','0,1,2,52,511',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(512,52,'昌平区',3,'0','110114','0,1,2,52,512',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(513,52,'怀柔区',3,'0','110116','0,1,2,52,513',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(514,52,'平谷区',3,'0','110117','0,1,2,52,514',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(515,52,'大兴区',3,'0','110115','0,1,2,52,515',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(516,52,'密云县',3,'0','110228','0,1,2,52,516',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(517,52,'延庆县',3,'0','110229','0,1,2,52,517',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(518,53,'鼓楼区',3,'0','350102','0,1,4,53,518',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(519,53,'台江区',3,'0','350103','0,1,4,53,519',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(520,53,'仓山区',3,'0','350104','0,1,4,53,520',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(521,53,'马尾区',3,'0','350105','0,1,4,53,521',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(522,53,'晋安区',3,'0','350111','0,1,4,53,522',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(523,53,'福清市',3,'0','350181','0,1,4,53,523',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(524,53,'长乐市',3,'0','350182','0,1,4,53,524',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(525,53,'闽侯县',3,'0','350121','0,1,4,53,525',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(526,53,'连江县',3,'0','350122','0,1,4,53,526',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(527,53,'罗源县',3,'0','350123','0,1,4,53,527',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(528,53,'闽清县',3,'0','350124','0,1,4,53,528',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(529,53,'永泰县',3,'0','350125','0,1,4,53,529',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(530,53,'平潭县',3,'0','350128','0,1,4,53,530',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(531,54,'新罗区',3,'0','350802','0,1,4,54,531',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(532,54,'漳平市',3,'0','350881','0,1,4,54,532',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(533,54,'长汀县',3,'0','350821','0,1,4,54,533',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(534,54,'永定县',3,'0','350822','0,1,4,54,534',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(535,54,'上杭县',3,'0','350823','0,1,4,54,535',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(536,54,'武平县',3,'0','350824','0,1,4,54,536',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(537,54,'连城县',3,'0','350825','0,1,4,54,537',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(538,55,'延平区',3,'0','350702','0,1,4,55,538',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(539,55,'邵武市',3,'0','350781','0,1,4,55,539',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(540,55,'武夷山市',3,'0','350782','0,1,4,55,540',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(541,55,'建瓯市',3,'0','350783','0,1,4,55,541',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(542,55,'建阳市',3,'0','350784','0,1,4,55,542',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(543,55,'顺昌县',3,'0','350721','0,1,4,55,543',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(544,55,'浦城县',3,'0','350722','0,1,4,55,544',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(545,55,'光泽县',3,'0','350723','0,1,4,55,545',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(546,55,'松溪县',3,'0','350724','0,1,4,55,546',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(547,55,'政和县',3,'0','350725','0,1,4,55,547',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(548,56,'蕉城区',3,'0','350902','0,1,4,56,548',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(549,56,'福安市',3,'0','350981','0,1,4,56,549',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(550,56,'福鼎市',3,'0','350982','0,1,4,56,550',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(551,56,'霞浦县',3,'0','350921','0,1,4,56,551',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(552,56,'古田县',3,'0','350922','0,1,4,56,552',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(553,56,'屏南县',3,'0','350923','0,1,4,56,553',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(554,56,'寿宁县',3,'0','350924','0,1,4,56,554',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(555,56,'周宁县',3,'0','350925','0,1,4,56,555',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(556,56,'柘荣县',3,'0','350926','0,1,4,56,556',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(557,57,'城厢区',3,'0','350302','0,1,4,57,557',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(558,57,'涵江区',3,'0','350303','0,1,4,57,558',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(559,57,'荔城区',3,'0','350304','0,1,4,57,559',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(560,57,'秀屿区',3,'0','350305','0,1,4,57,560',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(561,57,'仙游县',3,'0','350322','0,1,4,57,561',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(562,58,'鲤城区',3,'0','350502','0,1,4,58,562',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(563,58,'丰泽区',3,'0','350503','0,1,4,58,563',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(564,58,'洛江区',3,'0','350504','0,1,4,58,564',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(566,58,'泉港区',3,'0','350505','0,1,4,58,566',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(567,58,'石狮市',3,'0','350581','0,1,4,58,567',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(568,58,'晋江市',3,'0','350582','0,1,4,58,568',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(569,58,'南安市',3,'0','350583','0,1,4,58,569',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(570,58,'惠安县',3,'0','350521','0,1,4,58,570',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(571,58,'安溪县',3,'0','350524','0,1,4,58,571',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(572,58,'永春县',3,'0','350525','0,1,4,58,572',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(573,58,'德化县',3,'0','350526','0,1,4,58,573',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(574,58,'金门县',3,'0','350527','0,1,4,58,574',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(575,59,'梅列区',3,'0','350402','0,1,4,59,575',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(576,59,'三元区',3,'0','350403','0,1,4,59,576',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(577,59,'永安市',3,'0','350481','0,1,4,59,577',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(578,59,'明溪县',3,'0','350421','0,1,4,59,578',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(579,59,'清流县',3,'0','350423','0,1,4,59,579',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(580,59,'宁化县',3,'0','350424','0,1,4,59,580',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(581,59,'大田县',3,'0','350425','0,1,4,59,581',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(582,59,'尤溪县',3,'0','350426','0,1,4,59,582',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(583,59,'沙县',3,'0','350427','0,1,4,59,583',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(584,59,'将乐县',3,'0','350428','0,1,4,59,584',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(585,59,'泰宁县',3,'0','350429','0,1,4,59,585',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(586,59,'建宁县',3,'0','350430','0,1,4,59,586',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(587,60,'思明区',3,'0','350203','0,1,4,60,587',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(588,60,'海沧区',3,'0','350205','0,1,4,60,588',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(589,60,'湖里区',3,'0','350206','0,1,4,60,589',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(590,60,'集美区',3,'0','350211','0,1,4,60,590',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(591,60,'同安区',3,'0','350212','0,1,4,60,591',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(592,60,'翔安区',3,'0','350213','0,1,4,60,592',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(593,61,'芗城区',3,'0','350602','0,1,4,61,593',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(594,61,'龙文区',3,'0','350603','0,1,4,61,594',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(595,61,'龙海市',3,'0','350681','0,1,4,61,595',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(596,61,'云霄县',3,'0','350622','0,1,4,61,596',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(597,61,'漳浦县',3,'0','350623','0,1,4,61,597',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(598,61,'诏安县',3,'0','350624','0,1,4,61,598',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(599,61,'长泰县',3,'0','350625','0,1,4,61,599',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(600,61,'东山县',3,'0','350626','0,1,4,61,600',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(601,61,'南靖县',3,'0','350627','0,1,4,61,601',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(602,61,'平和县',3,'0','350628','0,1,4,61,602',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(603,61,'华安县',3,'0','350629','0,1,4,61,603',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(604,62,'皋兰县',3,'0','620122','0,1,5,62,604',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(605,62,'城关区',3,'0','620102','0,1,5,62,605',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(606,62,'七里河区',3,'0','620103','0,1,5,62,606',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(607,62,'西固区',3,'0','620104','0,1,5,62,607',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(608,62,'安宁区',3,'0','620105','0,1,5,62,608',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(609,62,'红古区',3,'0','620111','0,1,5,62,609',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(610,62,'永登县',3,'0','620121','0,1,5,62,610',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(611,62,'榆中县',3,'0','620123','0,1,5,62,611',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(612,63,'白银区',3,'0','620402','0,1,5,63,612',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(613,63,'平川区',3,'0','620403','0,1,5,63,613',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(614,63,'会宁县',3,'0','620422','0,1,5,63,614',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(615,63,'景泰县',3,'0','620423','0,1,5,63,615',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(616,63,'靖远县',3,'0','620421','0,1,5,63,616',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(617,64,'临洮县',3,'0','621124','0,1,5,64,617',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(618,64,'陇西县',3,'0','621122','0,1,5,64,618',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(619,64,'通渭县',3,'0','621121','0,1,5,64,619',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(620,64,'渭源县',3,'0','621123','0,1,5,64,620',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(621,64,'漳县',3,'0','621125','0,1,5,64,621',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(622,64,'岷县',3,'0','621126','0,1,5,64,622',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(623,64,'安定区',3,'0','621102','0,1,5,64,623',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(625,65,'合作市',3,'0','623001','0,1,5,65,625',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(626,65,'临潭县',3,'0','623021','0,1,5,65,626',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(627,65,'卓尼县',3,'0','623022','0,1,5,65,627',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(628,65,'舟曲县',3,'0','623023','0,1,5,65,628',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(629,65,'迭部县',3,'0','623024','0,1,5,65,629',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(630,65,'玛曲县',3,'0','623025','0,1,5,65,630',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(631,65,'碌曲县',3,'0','623026','0,1,5,65,631',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(632,65,'夏河县',3,'0','623027','0,1,5,65,632',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(633,66,'嘉峪关市',3,'0','620201','0,1,5,66,633',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(634,67,'金川区',3,'0','620302','0,1,5,67,634',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(635,67,'永昌县',3,'0','620321','0,1,5,67,635',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(636,68,'肃州区',3,'0','620902','0,1,5,68,636',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(637,68,'玉门市',3,'0','620981','0,1,5,68,637',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(638,68,'敦煌市',3,'0','620982','0,1,5,68,638',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(639,68,'金塔县',3,'0','620921','0,1,5,68,639',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(640,68,'安西县',3,'0','620922','0,1,5,68,640',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(641,68,'肃北',3,'0','620923','0,1,5,68,641',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(642,68,'阿克塞',3,'0','620924','0,1,5,68,642',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(643,69,'临夏市',3,'0','622901','0,1,5,69,643',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(644,69,'临夏县',3,'0','622921','0,1,5,69,644',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(645,69,'康乐县',3,'0','622922','0,1,5,69,645',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(646,69,'永靖县',3,'0','622923','0,1,5,69,646',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(647,69,'广河县',3,'0','622924','0,1,5,69,647',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(648,69,'和政县',3,'0','622925','0,1,5,69,648',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(649,69,'东乡族自治县',3,'0','622926','0,1,5,69,649',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(650,69,'积石山',3,'0','622927','0,1,5,69,650',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(651,70,'成县',3,'0','621221','0,1,5,70,651',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(652,70,'徽县',3,'0','621227','0,1,5,70,652',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(653,70,'康县',3,'0','621224','0,1,5,70,653',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(654,70,'礼县',3,'0','621226','0,1,5,70,654',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(655,70,'两当县',3,'0','621228','0,1,5,70,655',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(656,70,'文县',3,'0','621222','0,1,5,70,656',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(657,70,'西和县',3,'0','621225','0,1,5,70,657',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(658,70,'宕昌县',3,'0','621223','0,1,5,70,658',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(659,70,'武都区',3,'0','621202','0,1,5,70,659',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(660,71,'崇信县',3,'0','620823','0,1,5,71,660',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(661,71,'华亭县',3,'0','620824','0,1,5,71,661',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(662,71,'静宁县',3,'0','620826','0,1,5,71,662',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(663,71,'灵台县',3,'0','620822','0,1,5,71,663',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(664,71,'崆峒区',3,'0','620802','0,1,5,71,664',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(665,71,'庄浪县',3,'0','620825','0,1,5,71,665',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(666,71,'泾川县',3,'0','620821','0,1,5,71,666',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(667,72,'合水县',3,'0','621024','0,1,5,72,667',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(668,72,'华池县',3,'0','621023','0,1,5,72,668',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(669,72,'环县',3,'0','621022','0,1,5,72,669',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(670,72,'宁县',3,'0','621026','0,1,5,72,670',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(671,72,'庆城县',3,'0','621021','0,1,5,72,671',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(672,72,'西峰区',3,'0','621002','0,1,5,72,672',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(673,72,'镇原县',3,'0','621027','0,1,5,72,673',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(674,72,'正宁县',3,'0','621025','0,1,5,72,674',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(675,73,'甘谷县',3,'0','620523','0,1,5,73,675',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(676,73,'秦安县',3,'0','620522','0,1,5,73,676',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(677,73,'清水县',3,'0','620521','0,1,5,73,677',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(678,73,'秦城区',3,'0','620502','0,1,5,73,678',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(679,73,'北道区',3,'0','620503','0,1,5,73,679',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(680,73,'武山县',3,'0','620524','0,1,5,73,680',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(681,73,'张家川',3,'0','620525','0,1,5,73,681',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(682,74,'古浪县',3,'0','620622','0,1,5,74,682',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(683,74,'民勤县',3,'0','620621','0,1,5,74,683',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(684,74,'天祝',3,'0','620623','0,1,5,74,684',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(685,74,'凉州区',3,'0','620602','0,1,5,74,685',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(686,75,'高台县',3,'0','620724','0,1,5,75,686',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(687,75,'临泽县',3,'0','620723','0,1,5,75,687',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(688,75,'民乐县',3,'0','620722','0,1,5,75,688',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(689,75,'山丹县',3,'0','620725','0,1,5,75,689',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(690,75,'肃南',3,'0','620721','0,1,5,75,690',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(691,75,'甘州区',3,'0','620702','0,1,5,75,691',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(692,76,'从化市',3,'0','440184','0,1,6,76,692',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(693,76,'天河区',3,'0','440106','0,1,6,76,693',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(694,76,'东山区',3,'0','440102','0,1,6,76,694',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(695,76,'白云区',3,'0','440111','0,1,6,76,695',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(696,76,'海珠区',3,'0','440105','0,1,6,76,696',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(697,76,'荔湾区',3,'0','440103','0,1,6,76,697',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(698,76,'越秀区',3,'0','440104','0,1,6,76,698',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(699,76,'黄埔区',3,'0','440112','0,1,6,76,699',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(700,76,'番禺区',3,'0','440113','0,1,6,76,700',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(701,76,'花都区',3,'0','440114','0,1,6,76,701',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(702,76,'增城区',3,'0','440183','0,1,6,76,702',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(703,76,'芳村区',3,'0','440107','0,1,6,76,703',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(705,77,'福田区',3,'0','440304','0,1,6,77,705',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(706,77,'罗湖区',3,'0','440303','0,1,6,77,706',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(707,77,'南山区',3,'0','440305','0,1,6,77,707',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(708,77,'宝安区',3,'0','440306','0,1,6,77,708',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(709,77,'龙岗区',3,'0','440307','0,1,6,77,709',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(710,77,'盐田区',3,'0','440308','0,1,6,77,710',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(711,78,'湘桥区',3,'0','445102','0,1,6,78,711',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(712,78,'潮安县',3,'0','445121','0,1,6,78,712',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(713,78,'饶平县',3,'0','445122','0,1,6,78,713',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(714,79,'南城区',3,'0','0','0,1,6,79,714',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(715,79,'东城区',3,'0','0','0,1,6,79,715',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(716,79,'万江区',3,'0','0','0,1,6,79,716',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(717,79,'莞城区',3,'0','0','0,1,6,79,717',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(746,80,'禅城区',3,'0','440604','0,1,6,80,746',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(747,80,'南海区',3,'0','440605','0,1,6,80,747',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(748,80,'顺德区',3,'0','440606','0,1,6,80,748',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(749,80,'三水区',3,'0','440607','0,1,6,80,749',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(750,80,'高明区',3,'0','440608','0,1,6,80,750',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(751,81,'东源县',3,'0','441625','0,1,6,81,751',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(752,81,'和平县',3,'0','441624','0,1,6,81,752',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(753,81,'源城区',3,'0','441602','0,1,6,81,753',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(754,81,'连平县',3,'0','441623','0,1,6,81,754',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(755,81,'龙川县',3,'0','441622','0,1,6,81,755',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(756,81,'紫金县',3,'0','441621','0,1,6,81,756',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(757,82,'惠阳区',3,'0','441303','0,1,6,82,757',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(758,82,'惠城区',3,'0','441302','0,1,6,82,758',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(760,82,'博罗县',3,'0','441322','0,1,6,82,760',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(761,82,'惠东县',3,'0','441323','0,1,6,82,761',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(762,82,'龙门县',3,'0','441324','0,1,6,82,762',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(763,83,'江海区',3,'0','440704','0,1,6,83,763',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(764,83,'蓬江区',3,'0','440703','0,1,6,83,764',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(765,83,'新会区',3,'0','440705','0,1,6,83,765',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(766,83,'台山市',3,'0','440781','0,1,6,83,766',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(767,83,'开平市',3,'0','440783','0,1,6,83,767',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(768,83,'鹤山市',3,'0','440784','0,1,6,83,768',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(769,83,'恩平市',3,'0','440785','0,1,6,83,769',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(770,84,'榕城区',3,'0','445202','0,1,6,84,770',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(771,84,'普宁市',3,'0','445281','0,1,6,84,771',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(772,84,'揭东县',3,'0','445221','0,1,6,84,772',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(773,84,'揭西县',3,'0','445222','0,1,6,84,773',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(774,84,'惠来县',3,'0','445224','0,1,6,84,774',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(775,85,'茂南区',3,'0','440902','0,1,6,85,775',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(776,85,'茂港区',3,'0','440903','0,1,6,85,776',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(777,85,'高州市',3,'0','440981','0,1,6,85,777',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(778,85,'化州市',3,'0','440982','0,1,6,85,778',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(779,85,'信宜市',3,'0','440983','0,1,6,85,779',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(780,85,'电白县',3,'0','440923','0,1,6,85,780',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(781,86,'梅县',3,'0','441421','0,1,6,86,781',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(782,86,'梅江区',3,'0','441402','0,1,6,86,782',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(783,86,'兴宁市',3,'0','441481','0,1,6,86,783',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(784,86,'大埔县',3,'0','441422','0,1,6,86,784',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(785,86,'丰顺县',3,'0','441423','0,1,6,86,785',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(786,86,'五华县',3,'0','441424','0,1,6,86,786',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(787,86,'平远县',3,'0','441426','0,1,6,86,787',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(788,86,'蕉岭县',3,'0','441427','0,1,6,86,788',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(789,87,'清城区',3,'0','441802','0,1,6,87,789',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(790,87,'英德市',3,'0','441881','0,1,6,87,790',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(791,87,'连州市',3,'0','441882','0,1,6,87,791',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(792,87,'佛冈县',3,'0','441821','0,1,6,87,792',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(793,87,'阳山县',3,'0','441823','0,1,6,87,793',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(794,87,'清新县',3,'0','441827','0,1,6,87,794',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(795,87,'连山',3,'0','441825','0,1,6,87,795',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(796,87,'连南',3,'0','441826','0,1,6,87,796',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(797,88,'南澳县',3,'0','440523','0,1,6,88,797',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(798,88,'潮阳区',3,'0','440513','0,1,6,88,798',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(799,88,'澄海区',3,'0','440515','0,1,6,88,799',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(800,88,'龙湖区',3,'0','440507','0,1,6,88,800',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(801,88,'金平区',3,'0','440511','0,1,6,88,801',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(802,88,'濠江区',3,'0','440512','0,1,6,88,802',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(803,88,'潮南区',3,'0','440514','0,1,6,88,803',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(804,89,'城区',3,'0','441502','0,1,6,89,804',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(805,89,'陆丰市',3,'0','441581','0,1,6,89,805',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(806,89,'海丰县',3,'0','441521','0,1,6,89,806',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(807,89,'陆河县',3,'0','441523','0,1,6,89,807',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(808,90,'曲江县',3,'0','440221','0,1,6,90,808',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(809,90,'浈江区',3,'0','440204','0,1,6,90,809',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(810,90,'武江区',3,'0','440203','0,1,6,90,810',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(811,90,'北江区',3,'0','440202','0,1,6,90,811',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(812,90,'乐昌市',3,'0','440281','0,1,6,90,812',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(813,90,'南雄市',3,'0','440282','0,1,6,90,813',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(814,90,'始兴县',3,'0','440222','0,1,6,90,814',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(815,90,'仁化县',3,'0','440224','0,1,6,90,815',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(816,90,'翁源县',3,'0','440229','0,1,6,90,816',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(817,90,'新丰县',3,'0','440233','0,1,6,90,817',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(818,90,'乳源',3,'0','440232','0,1,6,90,818',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(819,91,'江城区',3,'0','441702','0,1,6,91,819',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(820,91,'阳春市',3,'0','441781','0,1,6,91,820',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(821,91,'阳西县',3,'0','441721','0,1,6,91,821',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(822,91,'阳东县',3,'0','441723','0,1,6,91,822',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(823,92,'云城区',3,'0','445302','0,1,6,92,823',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(824,92,'罗定市',3,'0','445381','0,1,6,92,824',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(825,92,'新兴县',3,'0','445321','0,1,6,92,825',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(826,92,'郁南县',3,'0','445322','0,1,6,92,826',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(827,92,'云安县',3,'0','445323','0,1,6,92,827',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(828,93,'赤坎区',3,'0','440802','0,1,6,93,828',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(829,93,'霞山区',3,'0','440803','0,1,6,93,829',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(830,93,'坡头区',3,'0','440804','0,1,6,93,830',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(831,93,'麻章区',3,'0','440811','0,1,6,93,831',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(832,93,'廉江市',3,'0','440881','0,1,6,93,832',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(833,93,'雷州市',3,'0','440882','0,1,6,93,833',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(834,93,'吴川市',3,'0','440883','0,1,6,93,834',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(835,93,'遂溪县',3,'0','440823','0,1,6,93,835',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(836,93,'徐闻县',3,'0','440825','0,1,6,93,836',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(837,94,'端州区',3,'0','441202','0,1,6,94,837',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(838,94,'高要市',3,'0','441283','0,1,6,94,838',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(839,94,'四会市',3,'0','441284','0,1,6,94,839',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(840,94,'广宁县',3,'0','441223','0,1,6,94,840',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(841,94,'怀集县',3,'0','441224','0,1,6,94,841',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(842,94,'封开县',3,'0','441225','0,1,6,94,842',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(843,94,'德庆县',3,'0','441226','0,1,6,94,843',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(844,95,'石岐街道',3,'0','0','0,1,6,95,844',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(845,95,'东区街道',3,'0','0','0,1,6,95,845',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(846,95,'西区街道',3,'0','0','0,1,6,95,846',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(847,95,'环城街道',3,'0','0','0,1,6,95,847',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(848,95,'中山港街道',3,'0','0','0,1,6,95,848',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(849,95,'五桂山街道',3,'0','0','0,1,6,95,849',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(850,96,'香洲区',3,'0','440402','0,1,6,96,850',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(851,96,'斗门区',3,'0','440403','0,1,6,96,851',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(852,96,'金湾区',3,'0','440404','0,1,6,96,852',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(853,97,'邕宁区',3,'0','450121','0,1,7,97,853',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(854,97,'新城区',3,'0','450103','0,1,7,97,854',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(855,97,'兴宁区',3,'0','450102','0,1,7,97,855',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(856,97,'永新区',3,'0','450106','0,1,7,97,856',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(857,97,'城北区',3,'0','450104','0,1,7,97,857',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(858,97,'江南区',3,'0','450105','0,1,7,97,858',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(859,97,'武鸣县',3,'0','450122','0,1,7,97,859',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(860,97,'隆安县',3,'0','450123','0,1,7,97,860',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(861,97,'马山县',3,'0','450124','0,1,7,97,861',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(862,97,'上林县',3,'0','450125','0,1,7,97,862',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(863,97,'宾阳县',3,'0','450126','0,1,7,97,863',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(864,97,'横县',3,'0','450127','0,1,7,97,864',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(865,98,'秀峰区',3,'0','450302','0,1,7,98,865',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(866,98,'叠彩区',3,'0','450303','0,1,7,98,866',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(867,98,'象山区',3,'0','450304','0,1,7,98,867',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(868,98,'七星区',3,'0','450305','0,1,7,98,868',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(869,98,'雁山区',3,'0','450311','0,1,7,98,869',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(870,98,'阳朔县',3,'0','450321','0,1,7,98,870',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(871,98,'临桂县',3,'0','450322','0,1,7,98,871',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(872,98,'灵川县',3,'0','450323','0,1,7,98,872',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(873,98,'全州县',3,'0','450324','0,1,7,98,873',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(874,98,'平乐县',3,'0','450330','0,1,7,98,874',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(875,98,'兴安县',3,'0','450325','0,1,7,98,875',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(876,98,'灌阳县',3,'0','450327','0,1,7,98,876',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(877,98,'荔浦县',3,'0','450331','0,1,7,98,877',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(878,98,'资源县',3,'0','450329','0,1,7,98,878',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(879,98,'永福县',3,'0','450326','0,1,7,98,879',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(880,98,'龙胜',3,'0','450328','0,1,7,98,880',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(881,98,'恭城',3,'0','450332','0,1,7,98,881',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(882,99,'右江区',3,'0','451002','0,1,7,99,882',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(883,99,'凌云县',3,'0','451027','0,1,7,99,883',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(884,99,'平果县',3,'0','451023','0,1,7,99,884',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(885,99,'西林县',3,'0','451030','0,1,7,99,885',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(886,99,'乐业县',3,'0','451028','0,1,7,99,886',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(887,99,'德保县',3,'0','451024','0,1,7,99,887',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(888,99,'田林县',3,'0','451029','0,1,7,99,888',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(889,99,'田阳县',3,'0','451021','0,1,7,99,889',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(890,99,'靖西县',3,'0','451025','0,1,7,99,890',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(891,99,'田东县',3,'0','451022','0,1,7,99,891',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(892,99,'那坡县',3,'0','451026','0,1,7,99,892',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(893,99,'隆林',3,'0','451031','0,1,7,99,893',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(894,100,'海城区',3,'0','450502','0,1,7,100,894',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(895,100,'银海区',3,'0','450503','0,1,7,100,895',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(896,100,'铁山港区',3,'0','450512','0,1,7,100,896',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(897,100,'合浦县',3,'0','450521','0,1,7,100,897',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(898,101,'江洲区',3,'0','451402','0,1,7,101,898',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(899,101,'凭祥市',3,'0','451481','0,1,7,101,899',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(900,101,'宁明县',3,'0','451422','0,1,7,101,900',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(901,101,'扶绥县',3,'0','451421','0,1,7,101,901',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(902,101,'龙州县',3,'0','451423','0,1,7,101,902',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(903,101,'大新县',3,'0','451424','0,1,7,101,903',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(904,101,'天等县',3,'0','451425','0,1,7,101,904',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(905,102,'港口区',3,'0','450602','0,1,7,102,905',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(906,102,'防城区',3,'0','450603','0,1,7,102,906',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(907,102,'东兴市',3,'0','450681','0,1,7,102,907',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(908,102,'上思县',3,'0','450621','0,1,7,102,908',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(909,103,'港北区',3,'0','450802','0,1,7,103,909',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(910,103,'港南区',3,'0','450803','0,1,7,103,910',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(911,103,'覃塘区',3,'0','450804','0,1,7,103,911',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(912,103,'桂平市',3,'0','450881','0,1,7,103,912',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(913,103,'平南县',3,'0','450821','0,1,7,103,913',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(914,104,'金城江区',3,'0','451202','0,1,7,104,914',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(915,104,'宜州市',3,'0','451281','0,1,7,104,915',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(916,104,'天峨县',3,'0','451222','0,1,7,104,916',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(917,104,'凤山县',3,'0','451223','0,1,7,104,917',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(918,104,'南丹县',3,'0','451221','0,1,7,104,918',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(919,104,'东兰县',3,'0','451224','0,1,7,104,919',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(920,104,'都安',3,'0','451228','0,1,7,104,920',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(921,104,'罗城',3,'0','451225','0,1,7,104,921',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(922,104,'巴马',3,'0','451227','0,1,7,104,922',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(923,104,'环江',3,'0','451226','0,1,7,104,923',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(924,104,'大化',3,'0','451229','0,1,7,104,924',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(925,105,'八步区',3,'0','451102','0,1,7,105,925',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(926,105,'钟山县',3,'0','451122','0,1,7,105,926',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(927,105,'昭平县',3,'0','451121','0,1,7,105,927',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(928,105,'富川',3,'0','451123','0,1,7,105,928',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(929,106,'兴宾区',3,'0','451302','0,1,7,106,929',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(930,106,'合山市',3,'0','451381','0,1,7,106,930',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(931,106,'象州县',3,'0','451322','0,1,7,106,931',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(932,106,'武宣县',3,'0','451323','0,1,7,106,932',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(933,106,'忻城县',3,'0','451321','0,1,7,106,933',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(934,106,'金秀',3,'0','451324','0,1,7,106,934',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(935,107,'城中区',3,'0','450202','0,1,7,107,935',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(936,107,'鱼峰区',3,'0','450203','0,1,7,107,936',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(937,107,'柳北区',3,'0','450205','0,1,7,107,937',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(938,107,'柳南区',3,'0','450204','0,1,7,107,938',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(939,107,'柳江县',3,'0','450221','0,1,7,107,939',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(940,107,'柳城县',3,'0','450222','0,1,7,107,940',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(941,107,'鹿寨县',3,'0','450223','0,1,7,107,941',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(942,107,'融安县',3,'0','450224','0,1,7,107,942',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(943,107,'融水',3,'0','450225','0,1,7,107,943',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(944,107,'三江',3,'0','450226','0,1,7,107,944',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(945,108,'钦南区',3,'0','450702','0,1,7,108,945',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(946,108,'钦北区',3,'0','450703','0,1,7,108,946',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(947,108,'灵山县',3,'0','450721','0,1,7,108,947',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(948,108,'浦北县',3,'0','450722','0,1,7,108,948',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(949,109,'万秀区',3,'0','450403','0,1,7,109,949',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(950,109,'蝶山区',3,'0','450404','0,1,7,109,950',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(951,109,'长洲区',3,'0','450405','0,1,7,109,951',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(952,109,'岑溪市',3,'0','450481','0,1,7,109,952',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(953,109,'苍梧县',3,'0','450421','0,1,7,109,953',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(954,109,'藤县',3,'0','450422','0,1,7,109,954',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(955,109,'蒙山县',3,'0','450423','0,1,7,109,955',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(956,110,'玉州区',3,'0','450902','0,1,7,110,956',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(957,110,'北流市',3,'0','450981','0,1,7,110,957',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(958,110,'容县',3,'0','450921','0,1,7,110,958',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(959,110,'陆川县',3,'0','450922','0,1,7,110,959',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(960,110,'博白县',3,'0','450923','0,1,7,110,960',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(961,110,'兴业县',3,'0','450924','0,1,7,110,961',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(962,111,'南明区',3,'0','520102','0,1,8,111,962',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(963,111,'云岩区',3,'0','520103','0,1,8,111,963',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(964,111,'花溪区',3,'0','520111','0,1,8,111,964',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(965,111,'乌当区',3,'0','520112','0,1,8,111,965',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(966,111,'白云区',3,'0','520113','0,1,8,111,966',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(967,111,'小河区',3,'0','520114','0,1,8,111,967',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(970,111,'清镇市',3,'0','520181','0,1,8,111,970',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(971,111,'开阳县',3,'0','520121','0,1,8,111,971',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(972,111,'修文县',3,'0','520123','0,1,8,111,972',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(973,111,'息烽县',3,'0','520122','0,1,8,111,973',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(974,112,'西秀区',3,'0','520402','0,1,8,112,974',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(975,112,'关岭',3,'0','520424','0,1,8,112,975',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(976,112,'镇宁',3,'0','520423','0,1,8,112,976',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(977,112,'紫云',3,'0','520425','0,1,8,112,977',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(978,112,'平坝县',3,'0','520421','0,1,8,112,978',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(979,112,'普定县',3,'0','520422','0,1,8,112,979',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(980,113,'毕节市',3,'0','522401','0,1,8,113,980',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(981,113,'大方县',3,'0','522422','0,1,8,113,981',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(982,113,'黔西县',3,'0','522423','0,1,8,113,982',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(983,113,'金沙县',3,'0','522424','0,1,8,113,983',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(984,113,'织金县',3,'0','522425','0,1,8,113,984',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(985,113,'纳雍县',3,'0','522426','0,1,8,113,985',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(986,113,'赫章县',3,'0','522428','0,1,8,113,986',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(987,113,'威宁',3,'0','522427','0,1,8,113,987',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(988,114,'钟山区',3,'0','520201','0,1,8,114,988',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(989,114,'六枝特区',3,'0','520203','0,1,8,114,989',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(990,114,'水城县',3,'0','520221','0,1,8,114,990',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(991,114,'盘县',3,'0','520222','0,1,8,114,991',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(992,115,'凯里市',3,'0','522601','0,1,8,115,992',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(993,115,'黄平县',3,'0','522622','0,1,8,115,993',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(994,115,'施秉县',3,'0','522623','0,1,8,115,994',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(995,115,'三穗县',3,'0','522624','0,1,8,115,995',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(996,115,'镇远县',3,'0','522625','0,1,8,115,996',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(997,115,'岑巩县',3,'0','522626','0,1,8,115,997',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(998,115,'天柱县',3,'0','522627','0,1,8,115,998',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(999,115,'锦屏县',3,'0','522628','0,1,8,115,999',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1000,115,'剑河县',3,'0','522629','0,1,8,115,1000',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1001,115,'台江县',3,'0','522630','0,1,8,115,1001',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1002,115,'黎平县',3,'0','522631','0,1,8,115,1002',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1003,115,'榕江县',3,'0','522632','0,1,8,115,1003',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1004,115,'从江县',3,'0','522633','0,1,8,115,1004',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1005,115,'雷山县',3,'0','522634','0,1,8,115,1005',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1006,115,'麻江县',3,'0','522635','0,1,8,115,1006',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1007,115,'丹寨县',3,'0','522636','0,1,8,115,1007',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1008,116,'都匀市',3,'0','522701','0,1,8,116,1008',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1009,116,'福泉市',3,'0','522702','0,1,8,116,1009',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1010,116,'荔波县',3,'0','522722','0,1,8,116,1010',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1011,116,'贵定县',3,'0','522723','0,1,8,116,1011',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1012,116,'瓮安县',3,'0','522725','0,1,8,116,1012',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1013,116,'独山县',3,'0','522726','0,1,8,116,1013',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1014,116,'平塘县',3,'0','522727','0,1,8,116,1014',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1015,116,'罗甸县',3,'0','522728','0,1,8,116,1015',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1016,116,'长顺县',3,'0','522729','0,1,8,116,1016',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1017,116,'龙里县',3,'0','522730','0,1,8,116,1017',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1018,116,'惠水县',3,'0','522731','0,1,8,116,1018',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1019,116,'三都',3,'0','522732','0,1,8,116,1019',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1020,117,'兴义市',3,'0','522301','0,1,8,117,1020',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1021,117,'兴仁县',3,'0','522322','0,1,8,117,1021',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1022,117,'普安县',3,'0','522323','0,1,8,117,1022',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1023,117,'晴隆县',3,'0','522324','0,1,8,117,1023',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1024,117,'贞丰县',3,'0','522325','0,1,8,117,1024',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1025,117,'望谟县',3,'0','522326','0,1,8,117,1025',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1026,117,'册亨县',3,'0','522327','0,1,8,117,1026',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1027,117,'安龙县',3,'0','522328','0,1,8,117,1027',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1028,118,'铜仁市',3,'0','522201','0,1,8,118,1028',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1029,118,'江口县',3,'0','522222','0,1,8,118,1029',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1030,118,'石阡县',3,'0','522224','0,1,8,118,1030',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1031,118,'思南县',3,'0','522225','0,1,8,118,1031',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1032,118,'德江县',3,'0','522227','0,1,8,118,1032',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1033,118,'玉屏',3,'0','522223','0,1,8,118,1033',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1034,118,'印江',3,'0','522226','0,1,8,118,1034',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1035,118,'沿河',3,'0','522228','0,1,8,118,1035',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1036,118,'松桃',3,'0','522229','0,1,8,118,1036',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1037,118,'万山特区',3,'0','522230','0,1,8,118,1037',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1038,119,'红花岗区',3,'0','520302','0,1,8,119,1038',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1041,119,'汇川区',3,'0','520303','0,1,8,119,1041',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1042,119,'赤水市',3,'0','520381','0,1,8,119,1042',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1043,119,'仁怀市',3,'0','520382','0,1,8,119,1043',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1044,119,'遵义县',3,'0','520321','0,1,8,119,1044',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1045,119,'桐梓县',3,'0','520322','0,1,8,119,1045',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1046,119,'绥阳县',3,'0','520323','0,1,8,119,1046',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1047,119,'正安县',3,'0','520324','0,1,8,119,1047',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1048,119,'凤冈县',3,'0','520327','0,1,8,119,1048',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1049,119,'湄潭县',3,'0','520328','0,1,8,119,1049',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1050,119,'余庆县',3,'0','520329','0,1,8,119,1050',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1051,119,'习水县',3,'0','520330','0,1,8,119,1051',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1052,119,'道真',3,'0','520325','0,1,8,119,1052',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1053,119,'务川',3,'0','520326','0,1,8,119,1053',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1054,120,'秀英区',3,'0','460105','0,1,9,120,1054',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1055,120,'龙华区',3,'0','460106','0,1,9,120,1055',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1056,120,'琼山区',3,'0','460107','0,1,9,120,1056',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1057,120,'美兰区',3,'0','460108','0,1,9,120,1057',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1058,137,'市区',3,'0','0','0,1,9,137,1058',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1059,137,'洋浦开发区',3,'0','0','0,1,9,137,1059',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1060,137,'那大镇',3,'0','0','0,1,9,137,1060',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1061,137,'王五镇',3,'0','0','0,1,9,137,1061',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1062,137,'雅星镇',3,'0','0','0,1,9,137,1062',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1063,137,'大成镇',3,'0','0','0,1,9,137,1063',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1064,137,'中和镇',3,'0','0','0,1,9,137,1064',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1065,137,'峨蔓镇',3,'0','0','0,1,9,137,1065',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1066,137,'南丰镇',3,'0','0','0,1,9,137,1066',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1067,137,'白马井镇',3,'0','0','0,1,9,137,1067',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1068,137,'兰洋镇',3,'0','0','0,1,9,137,1068',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1069,137,'和庆镇',3,'0','0','0,1,9,137,1069',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1070,137,'海头镇',3,'0','0','0,1,9,137,1070',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1071,137,'排浦镇',3,'0','0','0,1,9,137,1071',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1072,137,'东成镇',3,'0','0','0,1,9,137,1072',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1073,137,'光村镇',3,'0','0','0,1,9,137,1073',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1074,137,'木棠镇',3,'0','0','0,1,9,137,1074',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1075,137,'新州镇',3,'0','0','0,1,9,137,1075',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1076,137,'三都镇',3,'0','0','0,1,9,137,1076',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1077,137,'其他',3,'0','0','0,1,9,137,1077',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1078,138,'长安区',3,'0','130102','0,1,10,138,1078',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1079,138,'桥东区',3,'0','130103','0,1,10,138,1079',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1080,138,'桥西区',3,'0','130104','0,1,10,138,1080',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1081,138,'新华区',3,'0','130105','0,1,10,138,1081',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1082,138,'裕华区',3,'0','130108','0,1,10,138,1082',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1083,138,'井陉矿区',3,'0','130107','0,1,10,138,1083',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1085,138,'辛集市',3,'0','130181','0,1,10,138,1085',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1086,138,'藁城市',3,'0','130182','0,1,10,138,1086',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1087,138,'晋州市',3,'0','130183','0,1,10,138,1087',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1088,138,'新乐市',3,'0','130184','0,1,10,138,1088',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1089,138,'鹿泉市',3,'0','130185','0,1,10,138,1089',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1090,138,'井陉县',3,'0','130121','0,1,10,138,1090',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1091,138,'正定县',3,'0','130123','0,1,10,138,1091',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1092,138,'栾城县',3,'0','130124','0,1,10,138,1092',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1093,138,'行唐县',3,'0','130125','0,1,10,138,1093',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1094,138,'灵寿县',3,'0','130126','0,1,10,138,1094',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1095,138,'高邑县',3,'0','130127','0,1,10,138,1095',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1096,138,'深泽县',3,'0','130128','0,1,10,138,1096',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1097,138,'赞皇县',3,'0','130129','0,1,10,138,1097',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1098,138,'无极县',3,'0','130130','0,1,10,138,1098',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1099,138,'平山县',3,'0','130131','0,1,10,138,1099',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1100,138,'元氏县',3,'0','130132','0,1,10,138,1100',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1101,138,'赵县',3,'0','130133','0,1,10,138,1101',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1102,139,'新市区',3,'0','130602','0,1,10,139,1102',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1103,139,'南市区',3,'0','130604','0,1,10,139,1103',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1104,139,'北市区',3,'0','130603','0,1,10,139,1104',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1105,139,'涿州市',3,'0','130681','0,1,10,139,1105',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1106,139,'定州市',3,'0','130682','0,1,10,139,1106',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1107,139,'安国市',3,'0','130683','0,1,10,139,1107',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1108,139,'高碑店市',3,'0','130684','0,1,10,139,1108',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1109,139,'满城县',3,'0','130621','0,1,10,139,1109',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1110,139,'清苑县',3,'0','130622','0,1,10,139,1110',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1111,139,'涞水县',3,'0','130623','0,1,10,139,1111',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1112,139,'阜平县',3,'0','130624','0,1,10,139,1112',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1113,139,'徐水县',3,'0','130625','0,1,10,139,1113',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1114,139,'定兴县',3,'0','130626','0,1,10,139,1114',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1115,139,'唐县',3,'0','130627','0,1,10,139,1115',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1116,139,'高阳县',3,'0','130628','0,1,10,139,1116',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1117,139,'容城县',3,'0','130629','0,1,10,139,1117',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1118,139,'涞源县',3,'0','130630','0,1,10,139,1118',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1119,139,'望都县',3,'0','130631','0,1,10,139,1119',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1120,139,'安新县',3,'0','130632','0,1,10,139,1120',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1121,139,'易县',3,'0','130633','0,1,10,139,1121',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1122,139,'曲阳县',3,'0','130634','0,1,10,139,1122',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1123,139,'蠡县',3,'0','130635','0,1,10,139,1123',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1124,139,'顺平县',3,'0','130636','0,1,10,139,1124',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1125,139,'博野县',3,'0','130637','0,1,10,139,1125',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1126,139,'雄县',3,'0','130638','0,1,10,139,1126',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1127,140,'运河区',3,'0','130903','0,1,10,140,1127',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1128,140,'新华区',3,'0','130902','0,1,10,140,1128',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1129,140,'泊头市',3,'0','130981','0,1,10,140,1129',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1130,140,'任丘市',3,'0','130982','0,1,10,140,1130',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1131,140,'黄骅市',3,'0','130983','0,1,10,140,1131',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1132,140,'河间市',3,'0','130984','0,1,10,140,1132',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1133,140,'沧县',3,'0','130921','0,1,10,140,1133',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1134,140,'青县',3,'0','130922','0,1,10,140,1134',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1135,140,'东光县',3,'0','130923','0,1,10,140,1135',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1136,140,'海兴县',3,'0','130924','0,1,10,140,1136',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1137,140,'盐山县',3,'0','130925','0,1,10,140,1137',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1138,140,'肃宁县',3,'0','130926','0,1,10,140,1138',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1139,140,'南皮县',3,'0','130927','0,1,10,140,1139',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1140,140,'吴桥县',3,'0','130928','0,1,10,140,1140',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1141,140,'献县',3,'0','130929','0,1,10,140,1141',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1142,140,'孟村回族自治县',3,'0','130930','0,1,10,140,1142',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1143,141,'双桥区',3,'0','130802','0,1,10,141,1143',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1144,141,'双滦区',3,'0','130803','0,1,10,141,1144',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1145,141,'鹰手营子矿区',3,'0','130804','0,1,10,141,1145',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1146,141,'承德县',3,'0','130821','0,1,10,141,1146',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1147,141,'兴隆县',3,'0','130822','0,1,10,141,1147',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1148,141,'平泉县',3,'0','130823','0,1,10,141,1148',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1149,141,'滦平县',3,'0','130824','0,1,10,141,1149',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1150,141,'隆化县',3,'0','130825','0,1,10,141,1150',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1151,141,'丰宁',3,'0','130826','0,1,10,141,1151',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1152,141,'宽城',3,'0','130827','0,1,10,141,1152',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1153,141,'围场',3,'0','130828','0,1,10,141,1153',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1154,142,'从台区',3,'0','130403','0,1,10,142,1154',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1155,142,'复兴区',3,'0','130404','0,1,10,142,1155',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1156,142,'邯山区',3,'0','130402','0,1,10,142,1156',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1157,142,'峰峰矿区',3,'0','130406','0,1,10,142,1157',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1158,142,'武安市',3,'0','130481','0,1,10,142,1158',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1159,142,'邯郸县',3,'0','130421','0,1,10,142,1159',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1160,142,'临漳县',3,'0','130423','0,1,10,142,1160',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1161,142,'成安县',3,'0','130424','0,1,10,142,1161',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1162,142,'大名县',3,'0','130425','0,1,10,142,1162',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1163,142,'涉县',3,'0','130426','0,1,10,142,1163',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1164,142,'磁县',3,'0','130427','0,1,10,142,1164',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1165,142,'肥乡县',3,'0','130428','0,1,10,142,1165',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1166,142,'永年县',3,'0','130429','0,1,10,142,1166',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1167,142,'邱县',3,'0','130430','0,1,10,142,1167',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1168,142,'鸡泽县',3,'0','130431','0,1,10,142,1168',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1169,142,'广平县',3,'0','130432','0,1,10,142,1169',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1170,142,'馆陶县',3,'0','130433','0,1,10,142,1170',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1171,142,'魏县',3,'0','130434','0,1,10,142,1171',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1172,142,'曲周县',3,'0','130435','0,1,10,142,1172',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1173,143,'桃城区',3,'0','131102','0,1,10,143,1173',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1174,143,'冀州市',3,'0','131181','0,1,10,143,1174',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1175,143,'深州市',3,'0','131182','0,1,10,143,1175',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1176,143,'枣强县',3,'0','131121','0,1,10,143,1176',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1177,143,'武邑县',3,'0','131122','0,1,10,143,1177',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1178,143,'武强县',3,'0','131123','0,1,10,143,1178',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1179,143,'饶阳县',3,'0','131124','0,1,10,143,1179',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1180,143,'安平县',3,'0','131125','0,1,10,143,1180',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1181,143,'故城县',3,'0','131126','0,1,10,143,1181',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1182,143,'景县',3,'0','131127','0,1,10,143,1182',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1183,143,'阜城县',3,'0','131128','0,1,10,143,1183',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1184,144,'安次区',3,'0','131002','0,1,10,144,1184',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1185,144,'广阳区',3,'0','131003','0,1,10,144,1185',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1186,144,'霸州市',3,'0','131081','0,1,10,144,1186',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1187,144,'三河市',3,'0','131082','0,1,10,144,1187',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1188,144,'固安县',3,'0','131022','0,1,10,144,1188',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1189,144,'永清县',3,'0','131023','0,1,10,144,1189',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1190,144,'香河县',3,'0','131024','0,1,10,144,1190',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1191,144,'大城县',3,'0','131025','0,1,10,144,1191',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1192,144,'文安县',3,'0','131026','0,1,10,144,1192',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1193,144,'大厂',3,'0','131028','0,1,10,144,1193',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1194,145,'海港区',3,'0','130302','0,1,10,145,1194',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1195,145,'山海关区',3,'0','130303','0,1,10,145,1195',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1196,145,'北戴河区',3,'0','130304','0,1,10,145,1196',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1197,145,'昌黎县',3,'0','130322','0,1,10,145,1197',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1198,145,'抚宁县',3,'0','130323','0,1,10,145,1198',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1199,145,'卢龙县',3,'0','130324','0,1,10,145,1199',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1200,145,'青龙满族自治县',3,'0','130321','0,1,10,145,1200',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1201,146,'路北区',3,'0','130203','0,1,10,146,1201',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1202,146,'路南区',3,'0','130202','0,1,10,146,1202',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1203,146,'古冶区',3,'0','130204','0,1,10,146,1203',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1204,146,'开平区',3,'0','130205','0,1,10,146,1204',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1205,146,'丰南区',3,'0','130207','0,1,10,146,1205',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1206,146,'丰润区',3,'0','130208','0,1,10,146,1206',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1207,146,'遵化市',3,'0','130281','0,1,10,146,1207',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1208,146,'迁安市',3,'0','130283','0,1,10,146,1208',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1209,146,'滦县',3,'0','130223','0,1,10,146,1209',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1210,146,'滦南县',3,'0','130224','0,1,10,146,1210',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1211,146,'乐亭县',3,'0','130225','0,1,10,146,1211',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1212,146,'迁西县',3,'0','130227','0,1,10,146,1212',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1213,146,'玉田县',3,'0','130229','0,1,10,146,1213',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1214,146,'唐海县',3,'0','130230','0,1,10,146,1214',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1215,147,'桥东区',3,'0','130502','0,1,10,147,1215',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1216,147,'桥西区',3,'0','130503','0,1,10,147,1216',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1217,147,'南宫市',3,'0','130581','0,1,10,147,1217',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1218,147,'沙河市',3,'0','130582','0,1,10,147,1218',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1219,147,'邢台县',3,'0','130521','0,1,10,147,1219',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1220,147,'临城县',3,'0','130522','0,1,10,147,1220',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1221,147,'内丘县',3,'0','130523','0,1,10,147,1221',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1222,147,'柏乡县',3,'0','130524','0,1,10,147,1222',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1223,147,'隆尧县',3,'0','130525','0,1,10,147,1223',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1224,147,'任县',3,'0','130526','0,1,10,147,1224',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1225,147,'南和县',3,'0','130527','0,1,10,147,1225',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1226,147,'宁晋县',3,'0','130528','0,1,10,147,1226',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1227,147,'巨鹿县',3,'0','130529','0,1,10,147,1227',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1228,147,'新河县',3,'0','130530','0,1,10,147,1228',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1229,147,'广宗县',3,'0','130531','0,1,10,147,1229',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1230,147,'平乡县',3,'0','130532','0,1,10,147,1230',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1231,147,'威县',3,'0','130533','0,1,10,147,1231',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1232,147,'清河县',3,'0','130534','0,1,10,147,1232',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1233,147,'临西县',3,'0','130535','0,1,10,147,1233',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1234,148,'桥西区',3,'0','130703','0,1,10,148,1234',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1235,148,'桥东区',3,'0','130702','0,1,10,148,1235',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1236,148,'宣化区',3,'0','130705','0,1,10,148,1236',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1237,148,'下花园区',3,'0','130706','0,1,10,148,1237',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1238,148,'宣化县',3,'0','130721','0,1,10,148,1238',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1239,148,'张北县',3,'0','130722','0,1,10,148,1239',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1240,148,'康保县',3,'0','130723','0,1,10,148,1240',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1241,148,'沽源县',3,'0','130724','0,1,10,148,1241',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1242,148,'尚义县',3,'0','130725','0,1,10,148,1242',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1243,148,'蔚县',3,'0','130726','0,1,10,148,1243',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1244,148,'阳原县',3,'0','130727','0,1,10,148,1244',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1245,148,'怀安县',3,'0','130728','0,1,10,148,1245',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1246,148,'万全县',3,'0','130729','0,1,10,148,1246',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1247,148,'怀来县',3,'0','130730','0,1,10,148,1247',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1248,148,'涿鹿县',3,'0','130731','0,1,10,148,1248',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1249,148,'赤城县',3,'0','130732','0,1,10,148,1249',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1250,148,'崇礼县',3,'0','130733','0,1,10,148,1250',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1251,149,'金水区',3,'0','410105','0,1,11,149,1251',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1252,149,'邙山区',3,'0','410108','0,1,11,149,1252',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1253,149,'二七区',3,'0','410103','0,1,11,149,1253',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1254,149,'管城区',3,'0','410104','0,1,11,149,1254',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1255,149,'中原区',3,'0','410102','0,1,11,149,1255',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1256,149,'上街区',3,'0','410106','0,1,11,149,1256',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1262,149,'巩义市',3,'0','410181','0,1,11,149,1262',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1263,149,'荥阳市',3,'0','410182','0,1,11,149,1263',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1264,149,'新密市',3,'0','410183','0,1,11,149,1264',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1265,149,'新郑市',3,'0','410184','0,1,11,149,1265',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1266,149,'登封市',3,'0','410185','0,1,11,149,1266',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1267,149,'中牟县',3,'0','410122','0,1,11,149,1267',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1268,150,'西工区',3,'0','410303','0,1,11,150,1268',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1269,150,'老城区',3,'0','410302','0,1,11,150,1269',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1270,150,'涧西区',3,'0','410305','0,1,11,150,1270',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1271,150,'瀍河回族区',3,'4103','0','0,1,11,150,1271',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1272,150,'洛龙区',3,'0','410307','0,1,11,150,1272',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1273,150,'吉利区',3,'0','410306','0,1,11,150,1273',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1274,150,'偃师市',3,'0','410381','0,1,11,150,1274',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1275,150,'孟津县',3,'0','410322','0,1,11,150,1275',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1276,150,'新安县',3,'0','410323','0,1,11,150,1276',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1277,150,'栾川县',3,'0','410324','0,1,11,150,1277',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1278,150,'嵩县',3,'0','410325','0,1,11,150,1278',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1279,150,'汝阳县',3,'0','410326','0,1,11,150,1279',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1280,150,'宜阳县',3,'0','410327','0,1,11,150,1280',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1281,150,'洛宁县',3,'0','410328','0,1,11,150,1281',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1282,150,'伊川县',3,'0','410329','0,1,11,150,1282',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1283,151,'鼓楼区',3,'0','410204','0,1,11,151,1283',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1284,151,'龙亭区',3,'0','410202','0,1,11,151,1284',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1285,151,'顺河回族区',3,'0','410203','0,1,11,151,1285',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1286,151,'南关区',3,'0','410205','0,1,11,151,1286',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1287,151,'禹王台区',3,'0','0','0,1,11,151,1287',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1288,151,'杞县',3,'0','410221','0,1,11,151,1288',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1289,151,'通许县',3,'0','410222','0,1,11,151,1289',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1290,151,'尉氏县',3,'0','410223','0,1,11,151,1290',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1291,151,'开封县',3,'0','410224','0,1,11,151,1291',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1292,151,'兰考县',3,'0','410225','0,1,11,151,1292',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1293,152,'北关区',3,'0','410503','0,1,11,152,1293',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1294,152,'文峰区',3,'0','410502','0,1,11,152,1294',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1295,152,'殷都区',3,'0','410505','0,1,11,152,1295',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1296,152,'龙安区',3,'0','410506','0,1,11,152,1296',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1297,152,'林州市',3,'0','410581','0,1,11,152,1297',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1298,152,'安阳县',3,'0','410522','0,1,11,152,1298',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1299,152,'汤阴县',3,'0','410523','0,1,11,152,1299',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1300,152,'滑县',3,'0','410526','0,1,11,152,1300',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1301,152,'内黄县',3,'0','410527','0,1,11,152,1301',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1302,153,'淇滨区',3,'0','410611','0,1,11,153,1302',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1303,153,'山城区',3,'0','410603','0,1,11,153,1303',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1304,153,'鹤山区',3,'0','410602','0,1,11,153,1304',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1305,153,'浚县',3,'0','410621','0,1,11,153,1305',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1306,153,'淇县',3,'0','410622','0,1,11,153,1306',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1308,155,'解放区',3,'0','410802','0,1,11,155,1308',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1309,155,'中站区',3,'0','410803','0,1,11,155,1309',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1310,155,'马村区',3,'0','410804','0,1,11,155,1310',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1311,155,'山阳区',3,'0','410811','0,1,11,155,1311',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1312,155,'沁阳市',3,'0','410882','0,1,11,155,1312',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1313,155,'孟州市',3,'0','410883','0,1,11,155,1313',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1314,155,'修武县',3,'0','410821','0,1,11,155,1314',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1315,155,'博爱县',3,'0','410822','0,1,11,155,1315',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1316,155,'武陟县',3,'0','410823','0,1,11,155,1316',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1317,155,'温县',3,'0','410825','0,1,11,155,1317',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1318,156,'卧龙区',3,'0','411303','0,1,11,156,1318',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1319,156,'宛城区',3,'0','411302','0,1,11,156,1319',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1320,156,'邓州市',3,'0','411381','0,1,11,156,1320',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1321,156,'南召县',3,'0','411321','0,1,11,156,1321',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1322,156,'方城县',3,'0','411322','0,1,11,156,1322',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1323,156,'西峡县',3,'0','411323','0,1,11,156,1323',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1324,156,'镇平县',3,'0','411324','0,1,11,156,1324',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1325,156,'内乡县',3,'0','411325','0,1,11,156,1325',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1326,156,'淅川县',3,'0','411326','0,1,11,156,1326',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1327,156,'社旗县',3,'0','411327','0,1,11,156,1327',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1328,156,'唐河县',3,'0','411328','0,1,11,156,1328',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1329,156,'新野县',3,'0','411329','0,1,11,156,1329',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1330,156,'桐柏县',3,'0','411330','0,1,11,156,1330',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1331,157,'新华区',3,'0','410402','0,1,11,157,1331',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1332,157,'卫东区',3,'0','410403','0,1,11,157,1332',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1333,157,'湛河区',3,'0','410411','0,1,11,157,1333',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1334,157,'石龙区',3,'0','410404','0,1,11,157,1334',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1335,157,'舞钢市',3,'0','410481','0,1,11,157,1335',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1336,157,'汝州市',3,'0','410482','0,1,11,157,1336',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1337,157,'宝丰县',3,'0','410421','0,1,11,157,1337',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1338,157,'叶县',3,'0','410422','0,1,11,157,1338',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1339,157,'鲁山县',3,'0','410423','0,1,11,157,1339',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1340,157,'郏县',3,'0','410425','0,1,11,157,1340',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1341,158,'湖滨区',3,'0','411202','0,1,11,158,1341',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1342,158,'义马市',3,'0','411281','0,1,11,158,1342',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1343,158,'灵宝市',3,'0','411282','0,1,11,158,1343',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1344,158,'渑池县',3,'0','411221','0,1,11,158,1344',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1345,158,'陕县',3,'0','411222','0,1,11,158,1345',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1346,158,'卢氏县',3,'0','411224','0,1,11,158,1346',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1347,159,'梁园区',3,'0','411402','0,1,11,159,1347',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1348,159,'睢阳区',3,'0','411403','0,1,11,159,1348',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1349,159,'永城市',3,'0','411481','0,1,11,159,1349',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1350,159,'民权县',3,'0','411421','0,1,11,159,1350',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1351,159,'睢县',3,'0','411422','0,1,11,159,1351',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1352,159,'宁陵县',3,'0','411423','0,1,11,159,1352',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1353,159,'虞城县',3,'0','411425','0,1,11,159,1353',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1354,159,'柘城县',3,'0','411424','0,1,11,159,1354',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1355,159,'夏邑县',3,'0','411426','0,1,11,159,1355',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1356,160,'卫滨区',3,'0','410703','0,1,11,160,1356',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1357,160,'红旗区',3,'0','410702','0,1,11,160,1357',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1358,160,'凤泉区',3,'0','410704','0,1,11,160,1358',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1359,160,'牧野区',3,'0','410711','0,1,11,160,1359',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1360,160,'卫辉市',3,'0','410781','0,1,11,160,1360',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1361,160,'辉县市',3,'0','410782','0,1,11,160,1361',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1362,160,'新乡县',3,'0','410721','0,1,11,160,1362',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1363,160,'获嘉县',3,'0','410724','0,1,11,160,1363',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1364,160,'原阳县',3,'0','410725','0,1,11,160,1364',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1365,160,'延津县',3,'0','410726','0,1,11,160,1365',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1366,160,'封丘县',3,'0','410727','0,1,11,160,1366',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1367,160,'长垣县',3,'0','410728','0,1,11,160,1367',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1368,161,'浉河区',3,'0','411502','0,1,11,161,1368',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1369,161,'平桥区',3,'0','411503','0,1,11,161,1369',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1370,161,'罗山县',3,'0','411521','0,1,11,161,1370',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1371,161,'光山县',3,'0','411522','0,1,11,161,1371',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1372,161,'新县',3,'0','411523','0,1,11,161,1372',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1373,161,'商城县',3,'0','411524','0,1,11,161,1373',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1374,161,'固始县',3,'0','411525','0,1,11,161,1374',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1375,161,'潢川县',3,'0','411526','0,1,11,161,1375',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1376,161,'淮滨县',3,'0','411527','0,1,11,161,1376',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1377,161,'息县',3,'0','411528','0,1,11,161,1377',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1378,162,'魏都区',3,'0','411002','0,1,11,162,1378',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1379,162,'禹州市',3,'0','411081','0,1,11,162,1379',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1380,162,'长葛市',3,'0','411082','0,1,11,162,1380',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1381,162,'许昌县',3,'0','411023','0,1,11,162,1381',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1382,162,'鄢陵县',3,'0','411024','0,1,11,162,1382',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1383,162,'襄城县',3,'0','411025','0,1,11,162,1383',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1384,163,'川汇区',3,'0','411602','0,1,11,163,1384',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1385,163,'项城市',3,'0','411681','0,1,11,163,1385',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1386,163,'扶沟县',3,'0','411621','0,1,11,163,1386',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1387,163,'西华县',3,'0','411622','0,1,11,163,1387',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1388,163,'商水县',3,'0','411623','0,1,11,163,1388',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1389,163,'沈丘县',3,'0','411624','0,1,11,163,1389',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1390,163,'郸城县',3,'0','411625','0,1,11,163,1390',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1391,163,'淮阳县',3,'0','411626','0,1,11,163,1391',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1392,163,'太康县',3,'0','411627','0,1,11,163,1392',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1393,163,'鹿邑县',3,'0','411628','0,1,11,163,1393',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1394,164,'驿城区',3,'0','411702','0,1,11,164,1394',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1395,164,'西平县',3,'0','411721','0,1,11,164,1395',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1396,164,'上蔡县',3,'0','411722','0,1,11,164,1396',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1397,164,'平舆县',3,'0','411723','0,1,11,164,1397',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1398,164,'正阳县',3,'0','411724','0,1,11,164,1398',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1399,164,'确山县',3,'0','411725','0,1,11,164,1399',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1400,164,'泌阳县',3,'0','411726','0,1,11,164,1400',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1401,164,'汝南县',3,'0','411727','0,1,11,164,1401',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1402,164,'遂平县',3,'0','411728','0,1,11,164,1402',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1403,164,'新蔡县',3,'0','411729','0,1,11,164,1403',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1404,165,'郾城区',3,'0','411123','0,1,11,165,1404',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1405,165,'源汇区',3,'0','411102','0,1,11,165,1405',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1406,165,'召陵区',3,'0','0','0,1,11,165,1406',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1407,165,'舞阳县',3,'0','411121','0,1,11,165,1407',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1408,165,'临颍县',3,'0','411122','0,1,11,165,1408',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1409,166,'华龙区',3,'0','410902','0,1,11,166,1409',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1410,166,'清丰县',3,'0','410922','0,1,11,166,1410',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1411,166,'南乐县',3,'0','410923','0,1,11,166,1411',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1412,166,'范县',3,'0','410926','0,1,11,166,1412',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1413,166,'台前县',3,'0','410927','0,1,11,166,1413',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1414,166,'濮阳县',3,'0','410928','0,1,11,166,1414',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1415,167,'道里区',3,'0','230102','0,1,12,167,1415',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1416,167,'南岗区',3,'0','230103','0,1,12,167,1416',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1417,167,'动力区',3,'0','230107','0,1,12,167,1417',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1418,167,'平房区',3,'0','230108','0,1,12,167,1418',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1419,167,'香坊区',3,'0','230106','0,1,12,167,1419',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1421,167,'道外区',3,'0','230104','0,1,12,167,1421',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1422,167,'阿城区',3,'0','230181','0,1,12,167,1422',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1423,167,'呼兰区',3,'0','230111','0,1,12,167,1423',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1424,167,'松北区',3,'0','230109','0,1,12,167,1424',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1425,167,'尚志市',3,'0','230183','0,1,12,167,1425',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1426,167,'双城市',3,'0','230182','0,1,12,167,1426',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1427,167,'五常市',3,'0','230184','0,1,12,167,1427',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1428,167,'方正县',3,'0','230124','0,1,12,167,1428',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1429,167,'宾县',3,'0','230125','0,1,12,167,1429',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1430,167,'依兰县',3,'0','230123','0,1,12,167,1430',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1431,167,'巴彦县',3,'0','230126','0,1,12,167,1431',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1432,167,'通河县',3,'0','230128','0,1,12,167,1432',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1433,167,'木兰县',3,'0','230127','0,1,12,167,1433',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1434,167,'延寿县',3,'0','230129','0,1,12,167,1434',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1435,168,'萨尔图区',3,'0','230602','0,1,12,168,1435',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1436,168,'红岗区',3,'0','230605','0,1,12,168,1436',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1437,168,'龙凤区',3,'0','230603','0,1,12,168,1437',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1438,168,'让胡路区',3,'0','230604','0,1,12,168,1438',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1439,168,'大同区',3,'0','230606','0,1,12,168,1439',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1440,168,'肇州县',3,'0','230621','0,1,12,168,1440',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1441,168,'肇源县',3,'0','230622','0,1,12,168,1441',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1442,168,'林甸县',3,'0','230623','0,1,12,168,1442',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1443,168,'杜尔伯特',3,'0','230624','0,1,12,168,1443',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1444,169,'呼玛县',3,'0','232721','0,1,12,169,1444',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1445,169,'漠河县',3,'0','232723','0,1,12,169,1445',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1446,169,'塔河县',3,'0','232722','0,1,12,169,1446',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1447,170,'兴山区',3,'0','230407','0,1,12,170,1447',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1448,170,'工农区',3,'0','230403','0,1,12,170,1448',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1449,170,'南山区',3,'0','230404','0,1,12,170,1449',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1450,170,'兴安区',3,'0','230405','0,1,12,170,1450',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1451,170,'向阳区',3,'0','230402','0,1,12,170,1451',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1452,170,'东山区',3,'0','230406','0,1,12,170,1452',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1453,170,'萝北县',3,'0','230421','0,1,12,170,1453',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1454,170,'绥滨县',3,'0','230422','0,1,12,170,1454',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1455,171,'爱辉区',3,'0','231102','0,1,12,171,1455',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1456,171,'五大连池市',3,'0','231182','0,1,12,171,1456',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1457,171,'北安市',3,'0','231181','0,1,12,171,1457',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1458,171,'嫩江县',3,'0','231121','0,1,12,171,1458',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1459,171,'逊克县',3,'0','231123','0,1,12,171,1459',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1460,171,'孙吴县',3,'0','231124','0,1,12,171,1460',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1461,172,'鸡冠区',3,'0','230302','0,1,12,172,1461',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1462,172,'恒山区',3,'0','230303','0,1,12,172,1462',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1463,172,'城子河区',3,'0','230306','0,1,12,172,1463',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1464,172,'滴道区',3,'0','230304','0,1,12,172,1464',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1465,172,'梨树区',3,'0','230305','0,1,12,172,1465',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1466,172,'虎林市',3,'0','230381','0,1,12,172,1466',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1467,172,'密山市',3,'0','230382','0,1,12,172,1467',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1468,172,'鸡东县',3,'0','230321','0,1,12,172,1468',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1469,173,'前进区',3,'0','230804','0,1,12,173,1469',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1470,173,'郊区',3,'0','230811','0,1,12,173,1470',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1471,173,'向阳区',3,'0','230803','0,1,12,173,1471',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1472,173,'东风区',3,'0','230805','0,1,12,173,1472',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1473,173,'同江市',3,'0','230881','0,1,12,173,1473',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1474,173,'富锦市',3,'0','230882','0,1,12,173,1474',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1475,173,'桦南县',3,'0','230822','0,1,12,173,1475',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1476,173,'桦川县',3,'0','230826','0,1,12,173,1476',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1477,173,'汤原县',3,'0','230828','0,1,12,173,1477',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1478,173,'抚远县',3,'0','230833','0,1,12,173,1478',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1479,174,'爱民区',3,'0','231004','0,1,12,174,1479',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1480,174,'东安区',3,'0','231002','0,1,12,174,1480',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1481,174,'阳明区',3,'0','231003','0,1,12,174,1481',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1482,174,'西安区',3,'0','231005','0,1,12,174,1482',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1483,174,'绥芬河市',3,'0','231081','0,1,12,174,1483',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1484,174,'海林市',3,'0','231083','0,1,12,174,1484',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1485,174,'宁安市',3,'0','231084','0,1,12,174,1485',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1486,174,'穆棱市',3,'0','231085','0,1,12,174,1486',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1487,174,'东宁县',3,'0','231024','0,1,12,174,1487',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1488,174,'林口县',3,'0','231025','0,1,12,174,1488',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1489,175,'桃山区',3,'0','230903','0,1,12,175,1489',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1490,175,'新兴区',3,'0','230902','0,1,12,175,1490',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1491,175,'茄子河区',3,'0','230904','0,1,12,175,1491',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1492,175,'勃利县',3,'0','230921','0,1,12,175,1492',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1493,176,'龙沙区',3,'0','230202','0,1,12,176,1493',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1494,176,'昂昂溪区',3,'0','230205','0,1,12,176,1494',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1495,176,'铁峰区',3,'0','230204','0,1,12,176,1495',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1496,176,'建华区',3,'0','230203','0,1,12,176,1496',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1497,176,'富拉尔基区',3,'0','230206','0,1,12,176,1497',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1498,176,'碾子山区',3,'0','230207','0,1,12,176,1498',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1499,176,'梅里斯达斡尔区',3,'0','230208','0,1,12,176,1499',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1500,176,'讷河市',3,'0','230281','0,1,12,176,1500',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1501,176,'龙江县',3,'0','230221','0,1,12,176,1501',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1502,176,'依安县',3,'0','230223','0,1,12,176,1502',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1503,176,'泰来县',3,'0','230224','0,1,12,176,1503',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1504,176,'甘南县',3,'0','230225','0,1,12,176,1504',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1505,176,'富裕县',3,'0','230227','0,1,12,176,1505',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1506,176,'克山县',3,'0','230229','0,1,12,176,1506',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1507,176,'克东县',3,'0','230230','0,1,12,176,1507',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1508,176,'拜泉县',3,'0','230231','0,1,12,176,1508',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1509,177,'尖山区',3,'0','230502','0,1,12,177,1509',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1510,177,'岭东区',3,'0','230503','0,1,12,177,1510',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1511,177,'四方台区',3,'0','230505','0,1,12,177,1511',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1512,177,'宝山区',3,'0','230506','0,1,12,177,1512',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1513,177,'集贤县',3,'0','230521','0,1,12,177,1513',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1514,177,'友谊县',3,'0','230522','0,1,12,177,1514',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1515,177,'宝清县',3,'0','230523','0,1,12,177,1515',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1516,177,'饶河县',3,'0','230524','0,1,12,177,1516',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1517,178,'北林区',3,'0','231202','0,1,12,178,1517',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1518,178,'安达市',3,'0','231281','0,1,12,178,1518',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1519,178,'肇东市',3,'0','231282','0,1,12,178,1519',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1520,178,'海伦市',3,'0','231283','0,1,12,178,1520',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1521,178,'望奎县',3,'0','231221','0,1,12,178,1521',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1522,178,'兰西县',3,'0','231222','0,1,12,178,1522',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1523,178,'青冈县',3,'0','231223','0,1,12,178,1523',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1524,178,'庆安县',3,'0','231224','0,1,12,178,1524',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1525,178,'明水县',3,'0','231225','0,1,12,178,1525',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1526,178,'绥棱县',3,'0','231226','0,1,12,178,1526',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1527,179,'伊春区',3,'0','230702','0,1,12,179,1527',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1528,179,'带岭区',3,'0','230713','0,1,12,179,1528',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1529,179,'南岔区',3,'0','230703','0,1,12,179,1529',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1530,179,'金山屯区',3,'0','230709','0,1,12,179,1530',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1531,179,'西林区',3,'0','230705','0,1,12,179,1531',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1532,179,'美溪区',3,'0','230708','0,1,12,179,1532',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1533,179,'乌马河区',3,'0','230711','0,1,12,179,1533',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1534,179,'翠峦区',3,'0','230706','0,1,12,179,1534',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1535,179,'友好区',3,'0','230704','0,1,12,179,1535',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1536,179,'上甘岭区',3,'0','230716','0,1,12,179,1536',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1537,179,'五营区',3,'0','230710','0,1,12,179,1537',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1538,179,'红星区',3,'0','230715','0,1,12,179,1538',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1539,179,'新青区',3,'0','230707','0,1,12,179,1539',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1540,179,'汤旺河区',3,'0','230712','0,1,12,179,1540',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1541,179,'乌伊岭区',3,'0','230714','0,1,12,179,1541',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1542,179,'铁力市',3,'0','230781','0,1,12,179,1542',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1543,179,'嘉荫县',3,'0','230722','0,1,12,179,1543',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1544,180,'江岸区',3,'0','420102','0,1,13,180,1544',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1545,180,'武昌区',3,'0','420106','0,1,13,180,1545',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1546,180,'江汉区',3,'0','420103','0,1,13,180,1546',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1547,180,'硚口区',3,'0','420104','0,1,13,180,1547',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1548,180,'汉阳区',3,'0','420105','0,1,13,180,1548',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1549,180,'青山区',3,'0','420107','0,1,13,180,1549',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1550,180,'洪山区',3,'0','420111','0,1,13,180,1550',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1551,180,'东西湖区',3,'0','420112','0,1,13,180,1551',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1552,180,'汉南区',3,'0','420113','0,1,13,180,1552',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1553,180,'蔡甸区',3,'0','420114','0,1,13,180,1553',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1554,180,'江夏区',3,'0','420115','0,1,13,180,1554',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1555,180,'黄陂区',3,'0','420116','0,1,13,180,1555',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1556,180,'新洲区',3,'0','420117','0,1,13,180,1556',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1557,180,'经济开发区',3,'0','0','0,1,13,180,1557',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1558,181,'仙桃市',3,'0','0','0,1,13,181,1558',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1559,182,'鄂城区',3,'0','420704','0,1,13,182,1559',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1560,182,'华容区',3,'0','420703','0,1,13,182,1560',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1561,182,'梁子湖区',3,'0','420702','0,1,13,182,1561',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1562,183,'黄州区',3,'0','421102','0,1,13,183,1562',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1563,183,'麻城市',3,'0','421181','0,1,13,183,1563',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1564,183,'武穴市',3,'0','421182','0,1,13,183,1564',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1565,183,'团风县',3,'0','421121','0,1,13,183,1565',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1566,183,'红安县',3,'0','421122','0,1,13,183,1566',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1567,183,'罗田县',3,'0','421123','0,1,13,183,1567',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1568,183,'英山县',3,'0','421124','0,1,13,183,1568',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1569,183,'浠水县',3,'0','421125','0,1,13,183,1569',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1570,183,'蕲春县',3,'0','421126','0,1,13,183,1570',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1571,183,'黄梅县',3,'0','421127','0,1,13,183,1571',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1572,184,'黄石港区',3,'0','420202','0,1,13,184,1572',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1573,184,'西塞山区',3,'0','420203','0,1,13,184,1573',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1574,184,'下陆区',3,'0','420204','0,1,13,184,1574',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1575,184,'铁山区',3,'0','420205','0,1,13,184,1575',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1576,184,'大冶市',3,'0','420281','0,1,13,184,1576',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1577,184,'阳新县',3,'0','420222','0,1,13,184,1577',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1578,185,'东宝区',3,'0','420802','0,1,13,185,1578',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1579,185,'掇刀区',3,'0','420804','0,1,13,185,1579',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1580,185,'钟祥市',3,'0','420881','0,1,13,185,1580',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1581,185,'京山县',3,'0','420821','0,1,13,185,1581',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1582,185,'沙洋县',3,'0','420822','0,1,13,185,1582',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1583,186,'沙市区',3,'0','421002','0,1,13,186,1583',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1584,186,'荆州区',3,'0','421003','0,1,13,186,1584',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1585,186,'石首市',3,'0','421081','0,1,13,186,1585',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1586,186,'洪湖市',3,'0','421083','0,1,13,186,1586',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1587,186,'松滋市',3,'0','421087','0,1,13,186,1587',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1588,186,'公安县',3,'0','421022','0,1,13,186,1588',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1589,186,'监利县',3,'0','421023','0,1,13,186,1589',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1590,186,'江陵县',3,'0','421024','0,1,13,186,1590',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1591,187,'潜江市',3,'0','0','0,1,13,187,1591',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1592,188,'神农架林区',3,'0','0','0,1,13,188,1592',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1593,189,'张湾区',3,'0','420303','0,1,13,189,1593',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1594,189,'茅箭区',3,'0','420302','0,1,13,189,1594',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1595,189,'丹江口市',3,'0','420381','0,1,13,189,1595',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1596,189,'郧县',3,'0','420321','0,1,13,189,1596',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1597,189,'郧西县',3,'0','420322','0,1,13,189,1597',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1598,189,'竹山县',3,'0','420323','0,1,13,189,1598',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1599,189,'竹溪县',3,'0','420324','0,1,13,189,1599',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1600,189,'房县',3,'0','420325','0,1,13,189,1600',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1601,190,'曾都区',3,'0','421302','0,1,13,190,1601',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1602,190,'广水市',3,'0','421381','0,1,13,190,1602',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1603,191,'天门市',3,'0','0','0,1,13,191,1603',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1604,192,'咸安区',3,'0','421202','0,1,13,192,1604',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1605,192,'赤壁市',3,'0','421281','0,1,13,192,1605',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1606,192,'嘉鱼县',3,'0','421221','0,1,13,192,1606',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1607,192,'通城县',3,'0','421222','0,1,13,192,1607',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1608,192,'崇阳县',3,'0','421223','0,1,13,192,1608',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1609,192,'通山县',3,'0','421224','0,1,13,192,1609',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1610,193,'襄城区',3,'0','420602','0,1,13,193,1610',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1611,193,'樊城区',3,'0','420606','0,1,13,193,1611',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1612,193,'襄阳区',3,'0','420607','0,1,13,193,1612',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1613,193,'老河口市',3,'0','420682','0,1,13,193,1613',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1614,193,'枣阳市',3,'0','420683','0,1,13,193,1614',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1615,193,'宜城市',3,'0','420684','0,1,13,193,1615',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1616,193,'南漳县',3,'0','420624','0,1,13,193,1616',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1617,193,'谷城县',3,'0','420625','0,1,13,193,1617',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1618,193,'保康县',3,'0','420626','0,1,13,193,1618',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1619,194,'孝南区',3,'0','420902','0,1,13,194,1619',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1620,194,'应城市',3,'0','420981','0,1,13,194,1620',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1621,194,'安陆市',3,'0','420982','0,1,13,194,1621',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1622,194,'汉川市',3,'0','420984','0,1,13,194,1622',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1623,194,'孝昌县',3,'0','420921','0,1,13,194,1623',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1624,194,'大悟县',3,'0','420922','0,1,13,194,1624',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1625,194,'云梦县',3,'0','420923','0,1,13,194,1625',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1626,195,'长阳',3,'0','420528','0,1,13,195,1626',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1627,195,'五峰',3,'0','420529','0,1,13,195,1627',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1628,195,'西陵区',3,'0','420502','0,1,13,195,1628',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1629,195,'伍家岗区',3,'0','420503','0,1,13,195,1629',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1630,195,'点军区',3,'0','420504','0,1,13,195,1630',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1631,195,'猇亭区',3,'0','420505','0,1,13,195,1631',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1632,195,'夷陵区',3,'0','420506','0,1,13,195,1632',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1633,195,'宜都市',3,'0','420581','0,1,13,195,1633',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1634,195,'当阳市',3,'0','420582','0,1,13,195,1634',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1635,195,'枝江市',3,'0','420583','0,1,13,195,1635',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1636,195,'远安县',3,'0','420525','0,1,13,195,1636',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1637,195,'兴山县',3,'0','420526','0,1,13,195,1637',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1638,195,'秭归县',3,'0','420527','0,1,13,195,1638',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1639,196,'恩施市',3,'0','422801','0,1,13,196,1639',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1640,196,'利川市',3,'0','422802','0,1,13,196,1640',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1641,196,'建始县',3,'0','422822','0,1,13,196,1641',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1642,196,'巴东县',3,'0','422823','0,1,13,196,1642',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1643,196,'宣恩县',3,'0','422825','0,1,13,196,1643',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1644,196,'咸丰县',3,'0','422826','0,1,13,196,1644',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1645,196,'来凤县',3,'0','422827','0,1,13,196,1645',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1646,196,'鹤峰县',3,'0','422828','0,1,13,196,1646',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1647,197,'岳麓区',3,'0','430104','0,1,14,197,1647',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1648,197,'芙蓉区',3,'0','430102','0,1,14,197,1648',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1649,197,'天心区',3,'0','430103','0,1,14,197,1649',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1650,197,'开福区',3,'0','430105','0,1,14,197,1650',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1651,197,'雨花区',3,'0','430111','0,1,14,197,1651',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1652,197,'开发区',3,'0','0','0,1,14,197,1652',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1653,197,'浏阳市',3,'0','430181','0,1,14,197,1653',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1654,197,'长沙县',3,'0','430121','0,1,14,197,1654',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1655,197,'望城县',3,'0','430122','0,1,14,197,1655',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1656,197,'宁乡县',3,'0','430124','0,1,14,197,1656',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1657,198,'永定区',3,'0','430802','0,1,14,198,1657',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1658,198,'武陵源区',3,'0','430811','0,1,14,198,1658',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1659,198,'慈利县',3,'0','430821','0,1,14,198,1659',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1660,198,'桑植县',3,'0','430822','0,1,14,198,1660',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1661,199,'武陵区',3,'0','430702','0,1,14,199,1661',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1662,199,'鼎城区',3,'0','430703','0,1,14,199,1662',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1663,199,'津市市',3,'0','430781','0,1,14,199,1663',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1664,199,'安乡县',3,'0','430721','0,1,14,199,1664',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1665,199,'汉寿县',3,'0','430722','0,1,14,199,1665',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1666,199,'澧县',3,'0','430723','0,1,14,199,1666',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1667,199,'临澧县',3,'0','430724','0,1,14,199,1667',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1668,199,'桃源县',3,'0','430725','0,1,14,199,1668',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1669,199,'石门县',3,'0','430726','0,1,14,199,1669',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1670,200,'北湖区',3,'0','431002','0,1,14,200,1670',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1671,200,'苏仙区',3,'0','431003','0,1,14,200,1671',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1672,200,'资兴市',3,'0','431081','0,1,14,200,1672',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1673,200,'桂阳县',3,'0','431021','0,1,14,200,1673',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1674,200,'宜章县',3,'0','431022','0,1,14,200,1674',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1675,200,'永兴县',3,'0','431023','0,1,14,200,1675',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1676,200,'嘉禾县',3,'0','431024','0,1,14,200,1676',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1677,200,'临武县',3,'0','431025','0,1,14,200,1677',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1678,200,'汝城县',3,'0','431026','0,1,14,200,1678',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1679,200,'桂东县',3,'0','431027','0,1,14,200,1679',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1680,200,'安仁县',3,'0','431028','0,1,14,200,1680',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1681,201,'雁峰区',3,'0','430406','0,1,14,201,1681',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1682,201,'珠晖区',3,'0','430405','0,1,14,201,1682',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1683,201,'石鼓区',3,'0','430407','0,1,14,201,1683',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1684,201,'蒸湘区',3,'0','430408','0,1,14,201,1684',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1685,201,'南岳区',3,'0','430412','0,1,14,201,1685',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1686,201,'耒阳市',3,'0','430481','0,1,14,201,1686',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1687,201,'常宁市',3,'0','430482','0,1,14,201,1687',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1688,201,'衡阳县',3,'0','430421','0,1,14,201,1688',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1689,201,'衡南县',3,'0','430422','0,1,14,201,1689',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1690,201,'衡山县',3,'0','430423','0,1,14,201,1690',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1691,201,'衡东县',3,'0','430424','0,1,14,201,1691',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1692,201,'祁东县',3,'0','430426','0,1,14,201,1692',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1693,202,'鹤城区',3,'0','431202','0,1,14,202,1693',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1694,202,'靖州',3,'0','431229','0,1,14,202,1694',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1695,202,'麻阳',3,'0','431226','0,1,14,202,1695',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1696,202,'通道',3,'0','431230','0,1,14,202,1696',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1697,202,'新晃',3,'0','431227','0,1,14,202,1697',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1698,202,'芷江',3,'0','431228','0,1,14,202,1698',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1699,202,'沅陵县',3,'0','431222','0,1,14,202,1699',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1700,202,'辰溪县',3,'0','431223','0,1,14,202,1700',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1701,202,'溆浦县',3,'0','431224','0,1,14,202,1701',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1702,202,'中方县',3,'0','431221','0,1,14,202,1702',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1703,202,'会同县',3,'0','431225','0,1,14,202,1703',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1704,202,'洪江市',3,'0','431281','0,1,14,202,1704',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1705,203,'娄星区',3,'0','431302','0,1,14,203,1705',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1706,203,'冷水江市',3,'0','431381','0,1,14,203,1706',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1707,203,'涟源市',3,'0','431382','0,1,14,203,1707',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1708,203,'双峰县',3,'0','431321','0,1,14,203,1708',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1709,203,'新化县',3,'0','431322','0,1,14,203,1709',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1710,204,'城步',3,'0','430529','0,1,14,204,1710',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1711,204,'双清区',3,'0','430502','0,1,14,204,1711',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1712,204,'大祥区',3,'0','430503','0,1,14,204,1712',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1713,204,'北塔区',3,'0','430511','0,1,14,204,1713',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1714,204,'武冈市',3,'0','430581','0,1,14,204,1714',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1715,204,'邵东县',3,'0','430521','0,1,14,204,1715',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1716,204,'新邵县',3,'0','430522','0,1,14,204,1716',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1717,204,'邵阳县',3,'0','430523','0,1,14,204,1717',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1718,204,'隆回县',3,'0','430524','0,1,14,204,1718',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1719,204,'洞口县',3,'0','430525','0,1,14,204,1719',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1720,204,'绥宁县',3,'0','430527','0,1,14,204,1720',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1721,204,'新宁县',3,'0','430528','0,1,14,204,1721',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1722,205,'岳塘区',3,'0','430304','0,1,14,205,1722',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1723,205,'雨湖区',3,'0','430302','0,1,14,205,1723',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1724,205,'湘乡市',3,'0','430381','0,1,14,205,1724',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1725,205,'韶山市',3,'0','430382','0,1,14,205,1725',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1726,205,'湘潭县',3,'0','430321','0,1,14,205,1726',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1727,206,'吉首市',3,'0','433101','0,1,14,206,1727',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1728,206,'泸溪县',3,'0','433122','0,1,14,206,1728',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1729,206,'凤凰县',3,'0','433123','0,1,14,206,1729',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1730,206,'花垣县',3,'0','433124','0,1,14,206,1730',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1731,206,'保靖县',3,'0','433125','0,1,14,206,1731',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1732,206,'古丈县',3,'0','433126','0,1,14,206,1732',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1733,206,'永顺县',3,'0','433127','0,1,14,206,1733',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1734,206,'龙山县',3,'0','433130','0,1,14,206,1734',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1735,207,'赫山区',3,'0','430903','0,1,14,207,1735',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1736,207,'资阳区',3,'0','430902','0,1,14,207,1736',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1737,207,'沅江市',3,'0','430981','0,1,14,207,1737',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1738,207,'南县',3,'0','430921','0,1,14,207,1738',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1739,207,'桃江县',3,'0','430922','0,1,14,207,1739',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1740,207,'安化县',3,'0','430923','0,1,14,207,1740',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1741,208,'江华',3,'0','431129','0,1,14,208,1741',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1742,208,'冷水滩区',3,'0','431103','0,1,14,208,1742',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1743,208,'芝山区',3,'0','431102','0,1,14,208,1743',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1744,208,'祁阳县',3,'0','431121','0,1,14,208,1744',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1745,208,'东安县',3,'0','431122','0,1,14,208,1745',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1746,208,'双牌县',3,'0','431123','0,1,14,208,1746',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1747,208,'道县',3,'0','431124','0,1,14,208,1747',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1748,208,'江永县',3,'0','431125','0,1,14,208,1748',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1749,208,'宁远县',3,'0','431126','0,1,14,208,1749',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1750,208,'蓝山县',3,'0','431127','0,1,14,208,1750',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1751,208,'新田县',3,'0','431128','0,1,14,208,1751',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1752,209,'岳阳楼区',3,'0','430602','0,1,14,209,1752',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1753,209,'君山区',3,'0','430611','0,1,14,209,1753',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1754,209,'云溪区',3,'0','430603','0,1,14,209,1754',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1755,209,'汨罗市',3,'0','430681','0,1,14,209,1755',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1756,209,'临湘市',3,'0','430682','0,1,14,209,1756',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1757,209,'岳阳县',3,'0','430621','0,1,14,209,1757',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1758,209,'华容县',3,'0','430623','0,1,14,209,1758',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1759,209,'湘阴县',3,'0','430624','0,1,14,209,1759',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1760,209,'平江县',3,'0','430626','0,1,14,209,1760',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1761,210,'天元区',3,'0','430211','0,1,14,210,1761',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1762,210,'荷塘区',3,'0','430202','0,1,14,210,1762',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1763,210,'芦淞区',3,'0','430203','0,1,14,210,1763',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1764,210,'石峰区',3,'0','430204','0,1,14,210,1764',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1765,210,'醴陵市',3,'0','430281','0,1,14,210,1765',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1766,210,'株洲县',3,'0','430221','0,1,14,210,1766',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1767,210,'攸县',3,'0','430223','0,1,14,210,1767',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1768,210,'茶陵县',3,'0','430224','0,1,14,210,1768',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1769,210,'炎陵县',3,'0','430225','0,1,14,210,1769',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1770,211,'朝阳区',3,'0','220104','0,1,15,211,1770',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1771,211,'宽城区',3,'0','220103','0,1,15,211,1771',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1772,211,'二道区',3,'0','220105','0,1,15,211,1772',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1773,211,'南关区',3,'0','220102','0,1,15,211,1773',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1774,211,'绿园区',3,'0','220106','0,1,15,211,1774',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1775,211,'双阳区',3,'0','220112','0,1,15,211,1775',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1780,211,'德惠市',3,'0','220183','0,1,15,211,1780',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1781,211,'九台市',3,'0','220181','0,1,15,211,1781',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1782,211,'榆树市',3,'0','220182','0,1,15,211,1782',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1783,211,'农安县',3,'0','220122','0,1,15,211,1783',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1784,212,'船营区',3,'0','220204','0,1,15,212,1784',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1785,212,'昌邑区',3,'0','220202','0,1,15,212,1785',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1786,212,'龙潭区',3,'0','220203','0,1,15,212,1786',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1787,212,'丰满区',3,'0','220211','0,1,15,212,1787',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1788,212,'蛟河市',3,'0','220281','0,1,15,212,1788',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1789,212,'桦甸市',3,'0','220282','0,1,15,212,1789',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1790,212,'舒兰市',3,'0','220283','0,1,15,212,1790',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1791,212,'磐石市',3,'0','220284','0,1,15,212,1791',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1792,212,'永吉县',3,'0','220221','0,1,15,212,1792',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1793,213,'洮北区',3,'0','220802','0,1,15,213,1793',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1794,213,'洮南市',3,'0','220881','0,1,15,213,1794',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1795,213,'大安市',3,'0','220882','0,1,15,213,1795',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1796,213,'镇赉县',3,'0','220821','0,1,15,213,1796',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1797,213,'通榆县',3,'0','220822','0,1,15,213,1797',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1798,214,'江源区',3,'0','220625','0,1,15,214,1798',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1799,214,'八道江区',3,'0','220602','0,1,15,214,1799',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1800,214,'长白',3,'0','220623','0,1,15,214,1800',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1801,214,'临江市',3,'0','220681','0,1,15,214,1801',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1802,214,'抚松县',3,'0','220621','0,1,15,214,1802',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1803,214,'靖宇县',3,'0','220622','0,1,15,214,1803',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1804,215,'龙山区',3,'0','220402','0,1,15,215,1804',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1805,215,'西安区',3,'0','220403','0,1,15,215,1805',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1806,215,'东丰县',3,'0','220421','0,1,15,215,1806',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1807,215,'东辽县',3,'0','220422','0,1,15,215,1807',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1808,216,'铁西区',3,'0','220302','0,1,15,216,1808',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1809,216,'铁东区',3,'0','220303','0,1,15,216,1809',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1810,216,'伊通',3,'0','220323','0,1,15,216,1810',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1811,216,'公主岭市',3,'0','220381','0,1,15,216,1811',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1812,216,'双辽市',3,'0','220382','0,1,15,216,1812',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1813,216,'梨树县',3,'0','220322','0,1,15,216,1813',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1814,217,'前郭尔罗斯',3,'0','220721','0,1,15,217,1814',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1815,217,'宁江区',3,'0','220702','0,1,15,217,1815',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1816,217,'长岭县',3,'0','220722','0,1,15,217,1816',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1817,217,'乾安县',3,'0','220723','0,1,15,217,1817',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1818,217,'扶余县',3,'0','220724','0,1,15,217,1818',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1819,218,'东昌区',3,'0','220502','0,1,15,218,1819',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1820,218,'二道江区',3,'0','220503','0,1,15,218,1820',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1821,218,'梅河口市',3,'0','220581','0,1,15,218,1821',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1822,218,'集安市',3,'0','220582','0,1,15,218,1822',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1823,218,'通化县',3,'0','220521','0,1,15,218,1823',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1824,218,'辉南县',3,'0','220523','0,1,15,218,1824',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1825,218,'柳河县',3,'0','220524','0,1,15,218,1825',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1826,219,'延吉市',3,'0','222401','0,1,15,219,1826',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1827,219,'图们市',3,'0','222402','0,1,15,219,1827',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1828,219,'敦化市',3,'0','222403','0,1,15,219,1828',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1829,219,'珲春市',3,'0','222404','0,1,15,219,1829',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1830,219,'龙井市',3,'0','222405','0,1,15,219,1830',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1831,219,'和龙市',3,'0','222406','0,1,15,219,1831',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1832,219,'安图县',3,'0','222426','0,1,15,219,1832',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1833,219,'汪清县',3,'0','222424','0,1,15,219,1833',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1834,220,'玄武区',3,'0','320102','0,1,16,220,1834',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1835,220,'鼓楼区',3,'0','320106','0,1,16,220,1835',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1836,220,'白下区',3,'0','320103','0,1,16,220,1836',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1837,220,'建邺区',3,'0','320105','0,1,16,220,1837',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1838,220,'秦淮区',3,'0','320104','0,1,16,220,1838',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1839,220,'雨花台区',3,'0','320114','0,1,16,220,1839',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1840,220,'下关区',3,'0','320107','0,1,16,220,1840',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1841,220,'栖霞区',3,'0','320113','0,1,16,220,1841',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1842,220,'浦口区',3,'0','320111','0,1,16,220,1842',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1843,220,'江宁区',3,'0','320115','0,1,16,220,1843',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1844,220,'六合区',3,'0','320116','0,1,16,220,1844',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1845,220,'溧水县',3,'0','320124','0,1,16,220,1845',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1846,220,'高淳县',3,'0','320125','0,1,16,220,1846',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1847,221,'沧浪区',3,'0','320502','0,1,16,221,1847',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1848,221,'金阊区',3,'0','320504','0,1,16,221,1848',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1849,221,'平江区',3,'0','320503','0,1,16,221,1849',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1850,221,'虎丘区',3,'0','320505','0,1,16,221,1850',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1851,221,'吴中区',3,'0','320506','0,1,16,221,1851',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1852,221,'相城区',3,'0','320507','0,1,16,221,1852',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1854,221,'昆山市',3,'0','320583','0,1,16,221,1854',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1855,221,'常熟市',3,'0','320581','0,1,16,221,1855',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1856,221,'张家港市',3,'0','320582','0,1,16,221,1856',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1868,221,'吴江市',3,'0','320584','0,1,16,221,1868',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1869,221,'太仓市',3,'0','320585','0,1,16,221,1869',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1870,222,'崇安区',3,'0','320202','0,1,16,222,1870',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1871,222,'北塘区',3,'0','320204','0,1,16,222,1871',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1872,222,'南长区',3,'0','320203','0,1,16,222,1872',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1873,222,'锡山区',3,'0','320205','0,1,16,222,1873',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1874,222,'惠山区',3,'0','320206','0,1,16,222,1874',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1875,222,'滨湖区',3,'0','320211','0,1,16,222,1875',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1877,222,'江阴市',3,'0','320281','0,1,16,222,1877',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1878,222,'宜兴市',3,'0','320282','0,1,16,222,1878',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1879,223,'天宁区',3,'0','320402','0,1,16,223,1879',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1880,223,'钟楼区',3,'0','320404','0,1,16,223,1880',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1881,223,'戚墅堰区',3,'0','320405','0,1,16,223,1881',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1883,223,'新北区',3,'0','320411','0,1,16,223,1883',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1884,223,'武进区',3,'0','320412','0,1,16,223,1884',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1885,223,'溧阳市',3,'0','320481','0,1,16,223,1885',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1886,223,'金坛市',3,'0','320482','0,1,16,223,1886',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1887,224,'清河区',3,'0','320802','0,1,16,224,1887',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1888,224,'清浦区',3,'0','320811','0,1,16,224,1888',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1889,224,'楚州区',3,'0','320803','0,1,16,224,1889',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1890,224,'淮阴区',3,'0','320804','0,1,16,224,1890',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1891,224,'涟水县',3,'0','320826','0,1,16,224,1891',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1892,224,'洪泽县',3,'0','320829','0,1,16,224,1892',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1893,224,'盱眙县',3,'0','320830','0,1,16,224,1893',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1894,224,'金湖县',3,'0','320831','0,1,16,224,1894',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1895,225,'新浦区',3,'0','320705','0,1,16,225,1895',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1896,225,'连云区',3,'0','320703','0,1,16,225,1896',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1897,225,'海州区',3,'0','320706','0,1,16,225,1897',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1898,225,'赣榆县',3,'0','320721','0,1,16,225,1898',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1899,225,'东海县',3,'0','320722','0,1,16,225,1899',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1900,225,'灌云县',3,'0','320723','0,1,16,225,1900',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1901,225,'灌南县',3,'0','320724','0,1,16,225,1901',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1902,226,'崇川区',3,'0','320602','0,1,16,226,1902',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1903,226,'港闸区',3,'0','320611','0,1,16,226,1903',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1905,226,'启东市',3,'0','320681','0,1,16,226,1905',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1906,226,'如皋市',3,'0','320682','0,1,16,226,1906',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1907,226,'通州市',3,'0','320683','0,1,16,226,1907',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1908,226,'海门市',3,'0','320684','0,1,16,226,1908',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1909,226,'海安县',3,'0','320621','0,1,16,226,1909',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1910,226,'如东县',3,'0','320623','0,1,16,226,1910',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1911,227,'宿城区',3,'0','321302','0,1,16,227,1911',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1912,227,'宿豫区',3,'0','321311','0,1,16,227,1912',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1914,227,'沭阳县',3,'0','321322','0,1,16,227,1914',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1915,227,'泗阳县',3,'0','321323','0,1,16,227,1915',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1916,227,'泗洪县',3,'0','321324','0,1,16,227,1916',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1917,228,'海陵区',3,'0','321202','0,1,16,228,1917',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1918,228,'高港区',3,'0','321203','0,1,16,228,1918',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1919,228,'兴化市',3,'0','321281','0,1,16,228,1919',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1920,228,'靖江市',3,'0','321282','0,1,16,228,1920',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1921,228,'泰兴市',3,'0','321283','0,1,16,228,1921',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1922,228,'姜堰市',3,'0','321284','0,1,16,228,1922',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1923,229,'云龙区',3,'0','320303','0,1,16,229,1923',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1924,229,'鼓楼区',3,'0','320302','0,1,16,229,1924',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1925,229,'九里区',3,'0','320304','0,1,16,229,1925',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1926,229,'贾汪区',3,'0','320305','0,1,16,229,1926',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1927,229,'泉山区',3,'0','320311','0,1,16,229,1927',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1928,229,'新沂市',3,'0','320381','0,1,16,229,1928',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1929,229,'邳州市',3,'0','320382','0,1,16,229,1929',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1930,229,'丰县',3,'0','320321','0,1,16,229,1930',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1931,229,'沛县',3,'0','320322','0,1,16,229,1931',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1932,229,'铜山县',3,'0','320323','0,1,16,229,1932',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1933,229,'睢宁县',3,'0','320324','0,1,16,229,1933',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1935,230,'亭湖区',3,'0','320902','0,1,16,230,1935',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1936,230,'盐都区',3,'0','320903','0,1,16,230,1936',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1938,230,'东台市',3,'0','320981','0,1,16,230,1938',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1939,230,'大丰市',3,'0','320982','0,1,16,230,1939',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1940,230,'响水县',3,'0','320921','0,1,16,230,1940',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1941,230,'滨海县',3,'0','320922','0,1,16,230,1941',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1942,230,'阜宁县',3,'0','320923','0,1,16,230,1942',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1943,230,'射阳县',3,'0','320924','0,1,16,230,1943',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1944,230,'建湖县',3,'0','320925','0,1,16,230,1944',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1945,231,'广陵区',3,'0','321002','0,1,16,231,1945',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1946,231,'郊区',3,'0','321011','0,1,16,231,1946',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1947,231,'邗江区',3,'0','321003','0,1,16,231,1947',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1948,231,'仪征市',3,'0','321081','0,1,16,231,1948',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1949,231,'高邮市',3,'0','321084','0,1,16,231,1949',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1950,231,'江都市',3,'0','321088','0,1,16,231,1950',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1951,231,'宝应县',3,'0','321023','0,1,16,231,1951',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1952,232,'京口区',3,'0','321102','0,1,16,232,1952',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1953,232,'润州区',3,'0','321111','0,1,16,232,1953',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1954,232,'丹徒区',3,'0','321112','0,1,16,232,1954',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1955,232,'丹阳市',3,'0','321181','0,1,16,232,1955',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1956,232,'扬中市',3,'0','321182','0,1,16,232,1956',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1957,232,'句容市',3,'0','321183','0,1,16,232,1957',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1958,233,'东湖区',3,'0','360102','0,1,17,233,1958',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1959,233,'西湖区',3,'0','360103','0,1,17,233,1959',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1960,233,'青云谱区',3,'0','360104','0,1,17,233,1960',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1961,233,'湾里区',3,'0','360105','0,1,17,233,1961',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1962,233,'青山湖区',3,'0','360111','0,1,17,233,1962',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1963,233,'红谷滩新区',3,'0','0','0,1,17,233,1963',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1964,233,'昌北区',3,'0','0','0,1,17,233,1964',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1965,233,'高新区',3,'0','0','0,1,17,233,1965',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1966,233,'南昌县',3,'0','360121','0,1,17,233,1966',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1967,233,'新建县',3,'0','360122','0,1,17,233,1967',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1968,233,'安义县',3,'0','360123','0,1,17,233,1968',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1969,233,'进贤县',3,'0','360124','0,1,17,233,1969',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1970,234,'临川区',3,'0','361002','0,1,17,234,1970',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1971,234,'南城县',3,'0','361021','0,1,17,234,1971',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1972,234,'黎川县',3,'0','361022','0,1,17,234,1972',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1973,234,'南丰县',3,'0','361023','0,1,17,234,1973',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1974,234,'崇仁县',3,'0','361024','0,1,17,234,1974',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1975,234,'乐安县',3,'0','361025','0,1,17,234,1975',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1976,234,'宜黄县',3,'0','361026','0,1,17,234,1976',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1977,234,'金溪县',3,'0','361027','0,1,17,234,1977',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1978,234,'资溪县',3,'0','361028','0,1,17,234,1978',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1979,234,'东乡县',3,'0','361029','0,1,17,234,1979',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1980,234,'广昌县',3,'0','361030','0,1,17,234,1980',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1981,235,'章贡区',3,'0','360702','0,1,17,235,1981',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1982,235,'于都县',3,'0','360731','0,1,17,235,1982',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1983,235,'瑞金市',3,'0','360781','0,1,17,235,1983',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1984,235,'南康市',3,'0','360782','0,1,17,235,1984',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1985,235,'赣县',3,'0','360721','0,1,17,235,1985',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1986,235,'信丰县',3,'0','360722','0,1,17,235,1986',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1987,235,'大余县',3,'0','360723','0,1,17,235,1987',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1988,235,'上犹县',3,'0','360724','0,1,17,235,1988',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1989,235,'崇义县',3,'0','360725','0,1,17,235,1989',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1990,235,'安远县',3,'0','360726','0,1,17,235,1990',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1991,235,'龙南县',3,'0','360727','0,1,17,235,1991',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1992,235,'定南县',3,'0','360728','0,1,17,235,1992',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1993,235,'全南县',3,'0','360729','0,1,17,235,1993',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1994,235,'宁都县',3,'0','360730','0,1,17,235,1994',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1995,235,'兴国县',3,'0','360732','0,1,17,235,1995',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1996,235,'会昌县',3,'0','360733','0,1,17,235,1996',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1997,235,'寻乌县',3,'0','360734','0,1,17,235,1997',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1998,235,'石城县',3,'0','360735','0,1,17,235,1998',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(1999,236,'安福县',3,'0','360829','0,1,17,236,1999',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2000,236,'吉州区',3,'0','360802','0,1,17,236,2000',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2001,236,'青原区',3,'0','360803','0,1,17,236,2001',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2002,236,'井冈山市',3,'0','360881','0,1,17,236,2002',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2003,236,'吉安县',3,'0','360821','0,1,17,236,2003',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2004,236,'吉水县',3,'0','360822','0,1,17,236,2004',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2005,236,'峡江县',3,'0','360823','0,1,17,236,2005',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2006,236,'新干县',3,'0','360824','0,1,17,236,2006',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2007,236,'永丰县',3,'0','360825','0,1,17,236,2007',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2008,236,'泰和县',3,'0','360826','0,1,17,236,2008',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2009,236,'遂川县',3,'0','360827','0,1,17,236,2009',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2010,236,'万安县',3,'0','360828','0,1,17,236,2010',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2011,236,'永新县',3,'0','360830','0,1,17,236,2011',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2012,237,'珠山区',3,'0','360203','0,1,17,237,2012',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2013,237,'昌江区',3,'0','360202','0,1,17,237,2013',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2014,237,'乐平市',3,'0','360281','0,1,17,237,2014',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2015,237,'浮梁县',3,'0','360222','0,1,17,237,2015',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2016,238,'浔阳区',3,'0','360403','0,1,17,238,2016',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2017,238,'庐山区',3,'0','360402','0,1,17,238,2017',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2018,238,'瑞昌市',3,'0','360481','0,1,17,238,2018',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2019,238,'九江县',3,'0','360421','0,1,17,238,2019',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2020,238,'武宁县',3,'0','360423','0,1,17,238,2020',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2021,238,'修水县',3,'0','360424','0,1,17,238,2021',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2022,238,'永修县',3,'0','360425','0,1,17,238,2022',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2023,238,'德安县',3,'0','360426','0,1,17,238,2023',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2024,238,'星子县',3,'0','360427','0,1,17,238,2024',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2025,238,'都昌县',3,'0','360428','0,1,17,238,2025',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2026,238,'湖口县',3,'0','360429','0,1,17,238,2026',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2027,238,'彭泽县',3,'0','360430','0,1,17,238,2027',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2028,239,'安源区',3,'0','360302','0,1,17,239,2028',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2029,239,'湘东区',3,'0','360313','0,1,17,239,2029',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2030,239,'莲花县',3,'0','360321','0,1,17,239,2030',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2031,239,'芦溪县',3,'0','360323','0,1,17,239,2031',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2032,239,'上栗县',3,'0','360322','0,1,17,239,2032',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2033,240,'信州区',3,'0','361102','0,1,17,240,2033',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2034,240,'德兴市',3,'0','361181','0,1,17,240,2034',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2035,240,'上饶县',3,'0','361121','0,1,17,240,2035',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2036,240,'广丰县',3,'0','361122','0,1,17,240,2036',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2037,240,'玉山县',3,'0','361123','0,1,17,240,2037',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2038,240,'铅山县',3,'0','361124','0,1,17,240,2038',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2039,240,'横峰县',3,'0','361125','0,1,17,240,2039',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2040,240,'弋阳县',3,'0','361126','0,1,17,240,2040',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2041,240,'余干县',3,'0','361127','0,1,17,240,2041',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2042,240,'鄱阳县',3,'0','361128','0,1,17,240,2042',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2043,240,'万年县',3,'0','361129','0,1,17,240,2043',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2044,240,'婺源县',3,'0','361130','0,1,17,240,2044',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2045,241,'渝水区',3,'0','360502','0,1,17,241,2045',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2046,241,'分宜县',3,'0','360521','0,1,17,241,2046',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2047,242,'袁州区',3,'0','360902','0,1,17,242,2047',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2048,242,'丰城市',3,'0','360981','0,1,17,242,2048',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2049,242,'樟树市',3,'0','360982','0,1,17,242,2049',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2050,242,'高安市',3,'0','360983','0,1,17,242,2050',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2051,242,'奉新县',3,'0','360921','0,1,17,242,2051',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2052,242,'万载县',3,'0','360922','0,1,17,242,2052',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2053,242,'上高县',3,'0','360923','0,1,17,242,2053',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2054,242,'宜丰县',3,'0','360924','0,1,17,242,2054',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2055,242,'靖安县',3,'0','360925','0,1,17,242,2055',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2056,242,'铜鼓县',3,'0','360926','0,1,17,242,2056',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2057,243,'月湖区',3,'0','360602','0,1,17,243,2057',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2058,243,'贵溪市',3,'0','360681','0,1,17,243,2058',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2059,243,'余江县',3,'0','360622','0,1,17,243,2059',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2060,244,'沈河区',3,'0','210103','0,1,18,244,2060',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2061,244,'皇姑区',3,'0','210105','0,1,18,244,2061',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2062,244,'和平区',3,'0','210102','0,1,18,244,2062',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2063,244,'大东区',3,'0','210104','0,1,18,244,2063',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2064,244,'铁西区',3,'0','210106','0,1,18,244,2064',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2065,244,'苏家屯区',3,'0','210111','0,1,18,244,2065',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2066,244,'东陵区',3,'0','210112','0,1,18,244,2066',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2067,244,'沈北新区',3,'0','0','0,1,18,244,2067',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2068,244,'于洪区',3,'0','210114','0,1,18,244,2068',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2069,244,'浑南新区',3,'0','0','0,1,18,244,2069',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2070,244,'新民市',3,'0','210181','0,1,18,244,2070',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2071,244,'辽中县',3,'0','210122','0,1,18,244,2071',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2072,244,'康平县',3,'0','210123','0,1,18,244,2072',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2073,244,'法库县',3,'0','210124','0,1,18,244,2073',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2074,245,'西岗区',3,'0','210203','0,1,18,245,2074',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2075,245,'中山区',3,'0','210202','0,1,18,245,2075',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2076,245,'沙河口区',3,'0','210204','0,1,18,245,2076',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2077,245,'甘井子区',3,'0','210211','0,1,18,245,2077',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2078,245,'旅顺口区',3,'0','210212','0,1,18,245,2078',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2079,245,'金州区',3,'0','210213','0,1,18,245,2079',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2081,245,'瓦房店市',3,'0','210281','0,1,18,245,2081',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2082,245,'普兰店市',3,'0','210282','0,1,18,245,2082',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2083,245,'庄河市',3,'0','210283','0,1,18,245,2083',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2084,245,'长海县',3,'0','210224','0,1,18,245,2084',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2085,246,'铁东区',3,'0','210302','0,1,18,246,2085',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2086,246,'铁西区',3,'0','210303','0,1,18,246,2086',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2087,246,'立山区',3,'0','210304','0,1,18,246,2087',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2088,246,'千山区',3,'0','210311','0,1,18,246,2088',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2089,246,'岫岩',3,'0','210323','0,1,18,246,2089',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2090,246,'海城市',3,'0','210381','0,1,18,246,2090',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2091,246,'台安县',3,'0','210321','0,1,18,246,2091',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2092,247,'本溪',3,'0','210521','0,1,18,247,2092',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2093,247,'平山区',3,'0','210502','0,1,18,247,2093',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2094,247,'明山区',3,'0','210504','0,1,18,247,2094',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2095,247,'溪湖区',3,'0','210503','0,1,18,247,2095',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2096,247,'南芬区',3,'0','210505','0,1,18,247,2096',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2097,247,'桓仁',3,'0','210522','0,1,18,247,2097',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2098,248,'双塔区',3,'0','211302','0,1,18,248,2098',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2099,248,'龙城区',3,'0','211303','0,1,18,248,2099',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2100,248,'喀喇沁左翼蒙古族自治县',3,'0','211324','0,1,18,248,2100',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2101,248,'北票市',3,'0','211381','0,1,18,248,2101',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2102,248,'凌源市',3,'0','211382','0,1,18,248,2102',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2103,248,'朝阳县',3,'0','211321','0,1,18,248,2103',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2104,248,'建平县',3,'0','211322','0,1,18,248,2104',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2105,249,'振兴区',3,'0','210603','0,1,18,249,2105',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2106,249,'元宝区',3,'0','210602','0,1,18,249,2106',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2107,249,'振安区',3,'0','210604','0,1,18,249,2107',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2108,249,'宽甸',3,'0','210624','0,1,18,249,2108',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2109,249,'东港市',3,'0','210681','0,1,18,249,2109',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2110,249,'凤城市',3,'0','210682','0,1,18,249,2110',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2111,250,'顺城区',3,'0','210411','0,1,18,250,2111',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2112,250,'新抚区',3,'0','210402','0,1,18,250,2112',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2113,250,'东洲区',3,'0','210403','0,1,18,250,2113',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2114,250,'望花区',3,'0','210404','0,1,18,250,2114',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2115,250,'清原',3,'0','210423','0,1,18,250,2115',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2116,250,'新宾',3,'0','210422','0,1,18,250,2116',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2117,250,'抚顺县',3,'0','210421','0,1,18,250,2117',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2118,251,'阜新',3,'0','210921','0,1,18,251,2118',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2119,251,'海州区',3,'0','210902','0,1,18,251,2119',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2120,251,'新邱区',3,'0','210903','0,1,18,251,2120',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2121,251,'太平区',3,'0','210904','0,1,18,251,2121',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2122,251,'清河门区',3,'0','210905','0,1,18,251,2122',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2123,251,'细河区',3,'0','210911','0,1,18,251,2123',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2124,251,'彰武县',3,'0','210922','0,1,18,251,2124',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2125,252,'龙港区',3,'0','211403','0,1,18,252,2125',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2126,252,'南票区',3,'0','211404','0,1,18,252,2126',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2127,252,'连山区',3,'0','211402','0,1,18,252,2127',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2128,252,'兴城市',3,'0','211481','0,1,18,252,2128',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2129,252,'绥中县',3,'0','211421','0,1,18,252,2129',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2130,252,'建昌县',3,'0','211422','0,1,18,252,2130',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2131,253,'太和区',3,'0','210711','0,1,18,253,2131',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2132,253,'古塔区',3,'0','210702','0,1,18,253,2132',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2133,253,'凌河区',3,'0','210703','0,1,18,253,2133',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2134,253,'凌海市',3,'0','210781','0,1,18,253,2134',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2135,253,'北镇市',3,'0','210782','0,1,18,253,2135',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2136,253,'黑山县',3,'0','210726','0,1,18,253,2136',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2137,253,'义县',3,'0','210727','0,1,18,253,2137',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2138,254,'白塔区',3,'0','211002','0,1,18,254,2138',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2139,254,'文圣区',3,'0','211003','0,1,18,254,2139',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2140,254,'宏伟区',3,'0','211004','0,1,18,254,2140',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2141,254,'太子河区',3,'0','211011','0,1,18,254,2141',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2142,254,'弓长岭区',3,'0','211005','0,1,18,254,2142',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2143,254,'灯塔市',3,'0','211081','0,1,18,254,2143',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2144,254,'辽阳县',3,'0','211021','0,1,18,254,2144',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2145,255,'双台子区',3,'0','211102','0,1,18,255,2145',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2146,255,'兴隆台区',3,'0','211103','0,1,18,255,2146',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2147,255,'大洼县',3,'0','211121','0,1,18,255,2147',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2148,255,'盘山县',3,'0','211122','0,1,18,255,2148',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2149,256,'银州区',3,'0','211202','0,1,18,256,2149',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2150,256,'清河区',3,'0','211204','0,1,18,256,2150',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2151,256,'调兵山市',3,'0','211281','0,1,18,256,2151',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2152,256,'开原市',3,'0','211282','0,1,18,256,2152',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2153,256,'铁岭县',3,'0','211221','0,1,18,256,2153',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2154,256,'西丰县',3,'0','211223','0,1,18,256,2154',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2155,256,'昌图县',3,'0','211224','0,1,18,256,2155',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2156,257,'站前区',3,'0','210802','0,1,18,257,2156',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2157,257,'西市区',3,'0','210803','0,1,18,257,2157',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2158,257,'鲅鱼圈区',3,'0','210804','0,1,18,257,2158',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2159,257,'老边区',3,'0','210811','0,1,18,257,2159',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2160,257,'盖州市',3,'0','210881','0,1,18,257,2160',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2161,257,'大石桥市',3,'0','210882','0,1,18,257,2161',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2162,258,'回民区',3,'0','150103','0,1,19,258,2162',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2163,258,'玉泉区',3,'0','150104','0,1,19,258,2163',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2164,258,'新城区',3,'0','150102','0,1,19,258,2164',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2165,258,'赛罕区',3,'0','150105','0,1,19,258,2165',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2166,258,'清水河县',3,'0','150124','0,1,19,258,2166',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2167,258,'土默特左旗',3,'0','150121','0,1,19,258,2167',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2168,258,'托克托县',3,'0','150122','0,1,19,258,2168',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2169,258,'和林格尔县',3,'0','150123','0,1,19,258,2169',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2170,258,'武川县',3,'0','150125','0,1,19,258,2170',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2171,259,'阿拉善左旗',3,'0','152921','0,1,19,259,2171',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2172,259,'阿拉善右旗',3,'0','152922','0,1,19,259,2172',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2173,259,'额济纳旗',3,'0','152923','0,1,19,259,2173',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2174,260,'临河区',3,'0','150802','0,1,19,260,2174',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2175,260,'五原县',3,'0','150821','0,1,19,260,2175',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2176,260,'磴口县',3,'0','150822','0,1,19,260,2176',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2177,260,'乌拉特前旗',3,'0','150823','0,1,19,260,2177',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2178,260,'乌拉特中旗',3,'0','150824','0,1,19,260,2178',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2179,260,'乌拉特后旗',3,'0','150825','0,1,19,260,2179',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2180,260,'杭锦后旗',3,'0','150826','0,1,19,260,2180',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2181,261,'昆都仑区',3,'0','150203','0,1,19,261,2181',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2182,261,'青山区',3,'0','150204','0,1,19,261,2182',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2183,261,'东河区',3,'0','150202','0,1,19,261,2183',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2184,261,'九原区',3,'0','150207','0,1,19,261,2184',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2185,261,'石拐区',3,'0','150205','0,1,19,261,2185',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2186,261,'白云矿区',3,'0','150206','0,1,19,261,2186',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2187,261,'土默特右旗',3,'0','150221','0,1,19,261,2187',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2188,261,'固阳县',3,'0','150222','0,1,19,261,2188',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2189,261,'达尔罕茂明安联合旗',3,'0','150223','0,1,19,261,2189',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2190,262,'红山区',3,'0','150402','0,1,19,262,2190',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2191,262,'元宝山区',3,'0','150403','0,1,19,262,2191',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2192,262,'松山区',3,'0','150404','0,1,19,262,2192',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2193,262,'阿鲁科尔沁旗',3,'0','150421','0,1,19,262,2193',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2194,262,'巴林左旗',3,'0','150422','0,1,19,262,2194',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2195,262,'巴林右旗',3,'0','150423','0,1,19,262,2195',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2196,262,'林西县',3,'0','150424','0,1,19,262,2196',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2197,262,'克什克腾旗',3,'0','150425','0,1,19,262,2197',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2198,262,'翁牛特旗',3,'0','150426','0,1,19,262,2198',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2199,262,'喀喇沁旗',3,'0','150428','0,1,19,262,2199',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2200,262,'宁城县',3,'0','150429','0,1,19,262,2200',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2201,262,'敖汉旗',3,'0','150430','0,1,19,262,2201',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2202,263,'东胜区',3,'0','150602','0,1,19,263,2202',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2203,263,'达拉特旗',3,'0','150621','0,1,19,263,2203',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2204,263,'准格尔旗',3,'0','150622','0,1,19,263,2204',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2205,263,'鄂托克前旗',3,'0','150623','0,1,19,263,2205',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2206,263,'鄂托克旗',3,'0','150624','0,1,19,263,2206',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2207,263,'杭锦旗',3,'0','150625','0,1,19,263,2207',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2208,263,'乌审旗',3,'0','150626','0,1,19,263,2208',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2209,263,'伊金霍洛旗',3,'0','150627','0,1,19,263,2209',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2210,264,'海拉尔区',3,'0','150702','0,1,19,264,2210',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2211,264,'莫力达瓦',3,'0','150722','0,1,19,264,2211',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2212,264,'满洲里市',3,'0','150781','0,1,19,264,2212',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2213,264,'牙克石市',3,'0','150782','0,1,19,264,2213',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2214,264,'扎兰屯市',3,'0','150783','0,1,19,264,2214',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2215,264,'额尔古纳市',3,'0','150784','0,1,19,264,2215',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2216,264,'根河市',3,'0','150785','0,1,19,264,2216',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2217,264,'阿荣旗',3,'0','150721','0,1,19,264,2217',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2218,264,'鄂伦春自治旗',3,'0','150723','0,1,19,264,2218',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2219,264,'鄂温克族自治旗',3,'0','150724','0,1,19,264,2219',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2220,264,'陈巴尔虎旗',3,'0','150725','0,1,19,264,2220',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2221,264,'新巴尔虎左旗',3,'0','150726','0,1,19,264,2221',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2222,264,'新巴尔虎右旗',3,'0','150727','0,1,19,264,2222',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2223,265,'科尔沁区',3,'0','150502','0,1,19,265,2223',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2224,265,'霍林郭勒市',3,'0','150581','0,1,19,265,2224',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2225,265,'科尔沁左翼中旗',3,'0','150521','0,1,19,265,2225',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2226,265,'科尔沁左翼后旗',3,'0','150522','0,1,19,265,2226',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2227,265,'开鲁县',3,'0','150523','0,1,19,265,2227',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2228,265,'库伦旗',3,'0','150524','0,1,19,265,2228',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2229,265,'奈曼旗',3,'0','150525','0,1,19,265,2229',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2230,265,'扎鲁特旗',3,'0','150526','0,1,19,265,2230',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2231,266,'海勃湾区',3,'0','150302','0,1,19,266,2231',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2232,266,'乌达区',3,'0','150304','0,1,19,266,2232',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2233,266,'海南区',3,'0','150303','0,1,19,266,2233',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2234,267,'化德县',3,'0','150922','0,1,19,267,2234',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2235,267,'集宁区',3,'0','150902','0,1,19,267,2235',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2236,267,'丰镇市',3,'0','150981','0,1,19,267,2236',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2237,267,'卓资县',3,'0','150921','0,1,19,267,2237',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2238,267,'商都县',3,'0','150923','0,1,19,267,2238',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2239,267,'兴和县',3,'0','150924','0,1,19,267,2239',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2240,267,'凉城县',3,'0','150925','0,1,19,267,2240',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2241,267,'察哈尔右翼前旗',3,'0','150926','0,1,19,267,2241',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2242,267,'察哈尔右翼中旗',3,'0','150927','0,1,19,267,2242',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2243,267,'察哈尔右翼后旗',3,'0','150928','0,1,19,267,2243',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2244,267,'四子王旗',3,'0','150929','0,1,19,267,2244',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2245,268,'二连浩特市',3,'0','152501','0,1,19,268,2245',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2246,268,'锡林浩特市',3,'0','152502','0,1,19,268,2246',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2247,268,'阿巴嘎旗',3,'0','152522','0,1,19,268,2247',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2248,268,'苏尼特左旗',3,'0','152523','0,1,19,268,2248',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2249,268,'苏尼特右旗',3,'0','152524','0,1,19,268,2249',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2250,268,'东乌珠穆沁旗',3,'0','152525','0,1,19,268,2250',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2251,268,'西乌珠穆沁旗',3,'0','152526','0,1,19,268,2251',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2252,268,'太仆寺旗',3,'0','152527','0,1,19,268,2252',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2253,268,'镶黄旗',3,'0','152528','0,1,19,268,2253',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2254,268,'正镶白旗',3,'0','152529','0,1,19,268,2254',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2255,268,'正蓝旗',3,'0','152530','0,1,19,268,2255',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2256,268,'多伦县',3,'0','152531','0,1,19,268,2256',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2257,269,'乌兰浩特市',3,'0','152201','0,1,19,269,2257',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2258,269,'阿尔山市',3,'0','152202','0,1,19,269,2258',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2259,269,'科尔沁右翼前旗',3,'0','152221','0,1,19,269,2259',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2260,269,'科尔沁右翼中旗',3,'0','152222','0,1,19,269,2260',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2261,269,'扎赉特旗',3,'0','152223','0,1,19,269,2261',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2262,269,'突泉县',3,'0','152224','0,1,19,269,2262',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2263,270,'西夏区',3,'0','640105','0,1,20,270,2263',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2264,270,'金凤区',3,'0','640106','0,1,20,270,2264',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2265,270,'兴庆区',3,'0','640104','0,1,20,270,2265',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2266,270,'灵武市',3,'0','640181','0,1,20,270,2266',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2267,270,'永宁县',3,'0','640121','0,1,20,270,2267',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2268,270,'贺兰县',3,'0','640122','0,1,20,270,2268',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2269,271,'原州区',3,'0','640402','0,1,20,271,2269',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2271,271,'西吉县',3,'0','640422','0,1,20,271,2271',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2272,271,'隆德县',3,'0','640423','0,1,20,271,2272',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2273,271,'泾源县',3,'0','640424','0,1,20,271,2273',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2274,271,'彭阳县',3,'0','640425','0,1,20,271,2274',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2276,272,'大武口区',3,'0','640202','0,1,20,272,2276',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2277,272,'惠农区',3,'0','640205','0,1,20,272,2277',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2279,272,'平罗县',3,'0','640221','0,1,20,272,2279',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2280,273,'利通区',3,'0','640302','0,1,20,273,2280',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2282,273,'青铜峡市',3,'0','640381','0,1,20,273,2282',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2284,273,'盐池县',3,'0','640323','0,1,20,273,2284',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2285,273,'同心县',3,'0','640324','0,1,20,273,2285',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2286,274,'沙坡头区',3,'0','640502','0,1,20,274,2286',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2287,274,'海原县',3,'0','640522','0,1,20,274,2287',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2288,274,'中宁县',3,'0','640521','0,1,20,274,2288',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2289,275,'城中区',3,'0','630103','0,1,21,275,2289',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2290,275,'城东区',3,'0','630102','0,1,21,275,2290',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2291,275,'城西区',3,'0','630104','0,1,21,275,2291',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2292,275,'城北区',3,'0','630105','0,1,21,275,2292',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2293,275,'湟中县',3,'0','630122','0,1,21,275,2293',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2294,275,'湟源县',3,'0','630123','0,1,21,275,2294',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2295,275,'大通',3,'0','630121','0,1,21,275,2295',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2296,276,'玛沁县',3,'0','632621','0,1,21,276,2296',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2297,276,'班玛县',3,'0','632622','0,1,21,276,2297',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2298,276,'甘德县',3,'0','632623','0,1,21,276,2298',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2299,276,'达日县',3,'0','632624','0,1,21,276,2299',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2300,276,'久治县',3,'0','632625','0,1,21,276,2300',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2301,276,'玛多县',3,'0','632626','0,1,21,276,2301',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2302,277,'海晏县',3,'0','632223','0,1,21,277,2302',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2303,277,'祁连县',3,'0','632222','0,1,21,277,2303',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2304,277,'刚察县',3,'0','632224','0,1,21,277,2304',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2305,277,'门源',3,'0','632221','0,1,21,277,2305',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2306,278,'平安县',3,'0','632121','0,1,21,278,2306',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2307,278,'乐都县',3,'0','632123','0,1,21,278,2307',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2308,278,'民和',3,'0','632122','0,1,21,278,2308',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2309,278,'互助',3,'0','632126','0,1,21,278,2309',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2310,278,'化隆',3,'0','632127','0,1,21,278,2310',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2311,278,'循化',3,'0','632128','0,1,21,278,2311',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2312,279,'共和县',3,'0','632521','0,1,21,279,2312',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2313,279,'同德县',3,'0','632522','0,1,21,279,2313',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2314,279,'贵德县',3,'0','632523','0,1,21,279,2314',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2315,279,'兴海县',3,'0','632524','0,1,21,279,2315',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2316,279,'贵南县',3,'0','632525','0,1,21,279,2316',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2317,280,'德令哈市',3,'0','632802','0,1,21,280,2317',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2318,280,'格尔木市',3,'0','632801','0,1,21,280,2318',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2319,280,'乌兰县',3,'0','632821','0,1,21,280,2319',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2320,280,'都兰县',3,'0','632822','0,1,21,280,2320',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2321,280,'天峻县',3,'0','632823','0,1,21,280,2321',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2322,281,'同仁县',3,'0','632321','0,1,21,281,2322',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2323,281,'尖扎县',3,'0','632322','0,1,21,281,2323',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2324,281,'泽库县',3,'0','632323','0,1,21,281,2324',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2325,281,'河南蒙古族自治县',3,'0','632324','0,1,21,281,2325',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2326,282,'玉树县',3,'0','632721','0,1,21,282,2326',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2327,282,'杂多县',3,'0','632722','0,1,21,282,2327',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2328,282,'称多县',3,'0','632723','0,1,21,282,2328',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2329,282,'治多县',3,'0','632724','0,1,21,282,2329',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2330,282,'囊谦县',3,'0','632725','0,1,21,282,2330',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2331,282,'曲麻莱县',3,'0','632726','0,1,21,282,2331',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2332,283,'市中区',3,'0','370103','0,1,22,283,2332',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2333,283,'历下区',3,'0','370102','0,1,22,283,2333',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2334,283,'天桥区',3,'0','370105','0,1,22,283,2334',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2335,283,'槐荫区',3,'0','370104','0,1,22,283,2335',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2336,283,'历城区',3,'0','370112','0,1,22,283,2336',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2337,283,'长清区',3,'0','370113','0,1,22,283,2337',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2338,283,'章丘市',3,'0','370181','0,1,22,283,2338',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2339,283,'平阴县',3,'0','370124','0,1,22,283,2339',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2340,283,'济阳县',3,'0','370125','0,1,22,283,2340',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2341,283,'商河县',3,'0','370126','0,1,22,283,2341',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2342,284,'市南区',3,'0','370202','0,1,22,284,2342',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2343,284,'市北区',3,'0','370203','0,1,22,284,2343',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2344,284,'城阳区',3,'0','370214','0,1,22,284,2344',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2345,284,'四方区',3,'0','370205','0,1,22,284,2345',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2346,284,'李沧区',3,'0','370213','0,1,22,284,2346',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2347,284,'黄岛区',3,'0','370211','0,1,22,284,2347',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2348,284,'崂山区',3,'0','370212','0,1,22,284,2348',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2349,284,'胶州市',3,'0','370281','0,1,22,284,2349',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2350,284,'即墨市',3,'0','370282','0,1,22,284,2350',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2351,284,'平度市',3,'0','370283','0,1,22,284,2351',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2352,284,'胶南市',3,'0','370284','0,1,22,284,2352',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2353,284,'莱西市',3,'0','370285','0,1,22,284,2353',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2354,285,'滨城区',3,'0','371602','0,1,22,285,2354',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2355,285,'惠民县',3,'0','371621','0,1,22,285,2355',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2356,285,'阳信县',3,'0','371622','0,1,22,285,2356',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2357,285,'无棣县',3,'0','371623','0,1,22,285,2357',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2358,285,'沾化县',3,'0','371624','0,1,22,285,2358',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2359,285,'博兴县',3,'0','371625','0,1,22,285,2359',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2360,285,'邹平县',3,'0','371626','0,1,22,285,2360',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2361,286,'德城区',3,'0','371402','0,1,22,286,2361',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2362,286,'陵县',3,'0','371421','0,1,22,286,2362',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2363,286,'乐陵市',3,'0','371481','0,1,22,286,2363',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2364,286,'禹城市',3,'0','371482','0,1,22,286,2364',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2365,286,'宁津县',3,'0','371422','0,1,22,286,2365',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2366,286,'庆云县',3,'0','371423','0,1,22,286,2366',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2367,286,'临邑县',3,'0','371424','0,1,22,286,2367',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2368,286,'齐河县',3,'0','371425','0,1,22,286,2368',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2369,286,'平原县',3,'0','371426','0,1,22,286,2369',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2370,286,'夏津县',3,'0','371427','0,1,22,286,2370',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2371,286,'武城县',3,'0','371428','0,1,22,286,2371',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2372,287,'东营区',3,'0','370502','0,1,22,287,2372',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2373,287,'河口区',3,'0','370503','0,1,22,287,2373',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2374,287,'垦利县',3,'0','370521','0,1,22,287,2374',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2375,287,'利津县',3,'0','370522','0,1,22,287,2375',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2376,287,'广饶县',3,'0','370523','0,1,22,287,2376',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2377,288,'牡丹区',3,'0','371702','0,1,22,288,2377',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2378,288,'曹县',3,'0','371721','0,1,22,288,2378',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2379,288,'单县',3,'0','371722','0,1,22,288,2379',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2380,288,'成武县',3,'0','371723','0,1,22,288,2380',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2381,288,'巨野县',3,'0','371724','0,1,22,288,2381',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2382,288,'郓城县',3,'0','371725','0,1,22,288,2382',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2383,288,'鄄城县',3,'0','371726','0,1,22,288,2383',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2384,288,'定陶县',3,'0','371727','0,1,22,288,2384',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2385,288,'东明县',3,'0','371728','0,1,22,288,2385',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2386,289,'市中区',3,'0','370802','0,1,22,289,2386',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2387,289,'任城区',3,'0','370811','0,1,22,289,2387',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2388,289,'曲阜市',3,'0','370881','0,1,22,289,2388',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2389,289,'兖州市',3,'0','370882','0,1,22,289,2389',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2390,289,'邹城市',3,'0','370883','0,1,22,289,2390',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2391,289,'微山县',3,'0','370826','0,1,22,289,2391',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2392,289,'鱼台县',3,'0','370827','0,1,22,289,2392',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2393,289,'金乡县',3,'0','370828','0,1,22,289,2393',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2394,289,'嘉祥县',3,'0','370829','0,1,22,289,2394',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2395,289,'汶上县',3,'0','370830','0,1,22,289,2395',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2396,289,'泗水县',3,'0','370831','0,1,22,289,2396',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2397,289,'梁山县',3,'0','370832','0,1,22,289,2397',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2398,290,'莱城区',3,'0','371202','0,1,22,290,2398',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2399,290,'钢城区',3,'0','371203','0,1,22,290,2399',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2400,291,'东昌府区',3,'0','371502','0,1,22,291,2400',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2401,291,'临清市',3,'0','371581','0,1,22,291,2401',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2402,291,'阳谷县',3,'0','371521','0,1,22,291,2402',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2403,291,'莘县',3,'0','371522','0,1,22,291,2403',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2404,291,'茌平县',3,'0','371523','0,1,22,291,2404',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2405,291,'东阿县',3,'0','371524','0,1,22,291,2405',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2406,291,'冠县',3,'0','371525','0,1,22,291,2406',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2407,291,'高唐县',3,'0','371526','0,1,22,291,2407',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2408,292,'兰山区',3,'0','371302','0,1,22,292,2408',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2409,292,'罗庄区',3,'0','371311','0,1,22,292,2409',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2410,292,'河东区',3,'0','371312','0,1,22,292,2410',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2411,292,'沂南县',3,'0','371321','0,1,22,292,2411',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2412,292,'郯城县',3,'0','371322','0,1,22,292,2412',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2413,292,'沂水县',3,'0','371323','0,1,22,292,2413',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2414,292,'苍山县',3,'0','371324','0,1,22,292,2414',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2415,292,'费县',3,'0','371325','0,1,22,292,2415',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2416,292,'平邑县',3,'0','371326','0,1,22,292,2416',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2417,292,'莒南县',3,'0','371327','0,1,22,292,2417',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2418,292,'蒙阴县',3,'0','371328','0,1,22,292,2418',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2419,292,'临沭县',3,'0','371329','0,1,22,292,2419',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2420,293,'东港区',3,'0','371102','0,1,22,293,2420',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2421,293,'岚山区',3,'0','0','0,1,22,293,2421',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2422,293,'五莲县',3,'0','371121','0,1,22,293,2422',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2423,293,'莒县',3,'0','371122','0,1,22,293,2423',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2424,294,'泰山区',3,'0','370902','0,1,22,294,2424',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2425,294,'岱岳区',3,'0','370903','0,1,22,294,2425',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2426,294,'新泰市',3,'0','370982','0,1,22,294,2426',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2427,294,'肥城市',3,'0','370983','0,1,22,294,2427',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2428,294,'宁阳县',3,'0','370921','0,1,22,294,2428',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2429,294,'东平县',3,'0','370923','0,1,22,294,2429',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2430,295,'荣成市',3,'0','371082','0,1,22,295,2430',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2431,295,'乳山市',3,'0','371083','0,1,22,295,2431',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2432,295,'环翠区',3,'0','371002','0,1,22,295,2432',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2433,295,'文登市',3,'0','371081','0,1,22,295,2433',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2434,296,'潍城区',3,'0','370702','0,1,22,296,2434',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2435,296,'寒亭区',3,'0','370703','0,1,22,296,2435',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2436,296,'坊子区',3,'0','370704','0,1,22,296,2436',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2437,296,'奎文区',3,'0','370705','0,1,22,296,2437',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2438,296,'青州市',3,'0','370781','0,1,22,296,2438',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2439,296,'诸城市',3,'0','370782','0,1,22,296,2439',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2440,296,'寿光市',3,'0','370783','0,1,22,296,2440',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2441,296,'安丘市',3,'0','370784','0,1,22,296,2441',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2442,296,'高密市',3,'0','370785','0,1,22,296,2442',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2443,296,'昌邑市',3,'0','370786','0,1,22,296,2443',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2444,296,'临朐县',3,'0','370724','0,1,22,296,2444',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2445,296,'昌乐县',3,'0','370725','0,1,22,296,2445',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2446,297,'芝罘区',3,'0','370602','0,1,22,297,2446',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2447,297,'福山区',3,'0','370611','0,1,22,297,2447',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2448,297,'牟平区',3,'0','370612','0,1,22,297,2448',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2449,297,'莱山区',3,'0','370613','0,1,22,297,2449',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2451,297,'龙口市',3,'0','370681','0,1,22,297,2451',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2452,297,'莱阳市',3,'0','370682','0,1,22,297,2452',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2453,297,'莱州市',3,'0','370683','0,1,22,297,2453',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2454,297,'蓬莱市',3,'0','370684','0,1,22,297,2454',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2455,297,'招远市',3,'0','370685','0,1,22,297,2455',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2456,297,'栖霞市',3,'0','370686','0,1,22,297,2456',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2457,297,'海阳市',3,'0','370687','0,1,22,297,2457',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2458,297,'长岛县',3,'0','370634','0,1,22,297,2458',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2459,298,'市中区',3,'0','370402','0,1,22,298,2459',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2460,298,'山亭区',3,'0','370406','0,1,22,298,2460',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2461,298,'峄城区',3,'0','370404','0,1,22,298,2461',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2462,298,'台儿庄区',3,'0','370405','0,1,22,298,2462',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2463,298,'薛城区',3,'0','370403','0,1,22,298,2463',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2464,298,'滕州市',3,'0','370481','0,1,22,298,2464',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2465,299,'张店区',3,'0','370303','0,1,22,299,2465',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2466,299,'临淄区',3,'0','370305','0,1,22,299,2466',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2467,299,'淄川区',3,'0','370302','0,1,22,299,2467',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2468,299,'博山区',3,'0','370304','0,1,22,299,2468',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2469,299,'周村区',3,'0','370306','0,1,22,299,2469',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2470,299,'桓台县',3,'0','370321','0,1,22,299,2470',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2471,299,'高青县',3,'0','370322','0,1,22,299,2471',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2472,299,'沂源县',3,'0','370323','0,1,22,299,2472',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2473,300,'杏花岭区',3,'0','140107','0,1,23,300,2473',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2474,300,'小店区',3,'0','140105','0,1,23,300,2474',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2475,300,'迎泽区',3,'0','140106','0,1,23,300,2475',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2476,300,'尖草坪区',3,'0','140108','0,1,23,300,2476',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2477,300,'万柏林区',3,'0','140109','0,1,23,300,2477',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2478,300,'晋源区',3,'0','140110','0,1,23,300,2478',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2482,300,'清徐县',3,'0','140121','0,1,23,300,2482',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2483,300,'阳曲县',3,'0','140122','0,1,23,300,2483',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2484,300,'娄烦县',3,'0','140123','0,1,23,300,2484',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2485,300,'古交市',3,'0','140181','0,1,23,300,2485',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2486,301,'城区',3,'0','140402','0,1,23,301,2486',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2487,301,'郊区',3,'0','140411','0,1,23,301,2487',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2488,301,'沁县',3,'0','140430','0,1,23,301,2488',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2489,301,'潞城市',3,'0','140481','0,1,23,301,2489',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2490,301,'长治县',3,'0','140421','0,1,23,301,2490',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2491,301,'襄垣县',3,'0','140423','0,1,23,301,2491',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2492,301,'屯留县',3,'0','140424','0,1,23,301,2492',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2493,301,'平顺县',3,'0','140425','0,1,23,301,2493',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2494,301,'黎城县',3,'0','140426','0,1,23,301,2494',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2495,301,'壶关县',3,'0','140427','0,1,23,301,2495',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2496,301,'长子县',3,'0','140428','0,1,23,301,2496',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2497,301,'武乡县',3,'0','140429','0,1,23,301,2497',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2498,301,'沁源县',3,'0','140431','0,1,23,301,2498',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2499,302,'城区',3,'0','140202','0,1,23,302,2499',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2500,302,'矿区',3,'0','140203','0,1,23,302,2500',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2501,302,'南郊区',3,'0','140211','0,1,23,302,2501',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2502,302,'新荣区',3,'0','140212','0,1,23,302,2502',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2503,302,'阳高县',3,'0','140221','0,1,23,302,2503',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2504,302,'天镇县',3,'0','140222','0,1,23,302,2504',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2505,302,'广灵县',3,'0','140223','0,1,23,302,2505',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2506,302,'灵丘县',3,'0','140224','0,1,23,302,2506',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2507,302,'浑源县',3,'0','140225','0,1,23,302,2507',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2508,302,'左云县',3,'0','140226','0,1,23,302,2508',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2509,302,'大同县',3,'0','140227','0,1,23,302,2509',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2510,303,'城区',3,'0','140502','0,1,23,303,2510',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2511,303,'高平市',3,'0','140581','0,1,23,303,2511',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2512,303,'沁水县',3,'0','140521','0,1,23,303,2512',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2513,303,'阳城县',3,'0','140522','0,1,23,303,2513',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2514,303,'陵川县',3,'0','140524','0,1,23,303,2514',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2515,303,'泽州县',3,'0','140525','0,1,23,303,2515',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2516,304,'榆次区',3,'0','140702','0,1,23,304,2516',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2517,304,'介休市',3,'0','140781','0,1,23,304,2517',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2518,304,'榆社县',3,'0','140721','0,1,23,304,2518',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2519,304,'左权县',3,'0','140722','0,1,23,304,2519',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2520,304,'和顺县',3,'0','140723','0,1,23,304,2520',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2521,304,'昔阳县',3,'0','140724','0,1,23,304,2521',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2522,304,'寿阳县',3,'0','140725','0,1,23,304,2522',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2523,304,'太谷县',3,'0','140726','0,1,23,304,2523',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2524,304,'祁县',3,'0','140727','0,1,23,304,2524',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2525,304,'平遥县',3,'0','140728','0,1,23,304,2525',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2526,304,'灵石县',3,'0','140729','0,1,23,304,2526',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2527,305,'尧都区',3,'0','141002','0,1,23,305,2527',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2528,305,'侯马市',3,'0','141081','0,1,23,305,2528',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2529,305,'霍州市',3,'0','141082','0,1,23,305,2529',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2530,305,'曲沃县',3,'0','141021','0,1,23,305,2530',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2531,305,'翼城县',3,'0','141022','0,1,23,305,2531',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2532,305,'襄汾县',3,'0','141023','0,1,23,305,2532',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2533,305,'洪洞县',3,'0','141024','0,1,23,305,2533',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2534,305,'吉县',3,'0','141028','0,1,23,305,2534',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2535,305,'安泽县',3,'0','141026','0,1,23,305,2535',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2536,305,'浮山县',3,'0','141027','0,1,23,305,2536',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2537,305,'古县',3,'0','141025','0,1,23,305,2537',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2538,305,'乡宁县',3,'0','141029','0,1,23,305,2538',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2539,305,'大宁县',3,'0','141030','0,1,23,305,2539',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2540,305,'隰县',3,'0','141031','0,1,23,305,2540',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2541,305,'永和县',3,'0','141032','0,1,23,305,2541',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2542,305,'蒲县',3,'0','141033','0,1,23,305,2542',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2543,305,'汾西县',3,'0','141034','0,1,23,305,2543',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2545,306,'离石区',3,'0','141102','0,1,23,306,2545',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2546,306,'孝义市',3,'0','141181','0,1,23,306,2546',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2547,306,'汾阳市',3,'0','141182','0,1,23,306,2547',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2548,306,'文水县',3,'0','141121','0,1,23,306,2548',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2549,306,'交城县',3,'0','141122','0,1,23,306,2549',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2550,306,'兴县',3,'0','141123','0,1,23,306,2550',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2551,306,'临县',3,'0','141124','0,1,23,306,2551',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2552,306,'柳林县',3,'0','141125','0,1,23,306,2552',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2553,306,'石楼县',3,'0','141126','0,1,23,306,2553',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2554,306,'岚县',3,'0','141127','0,1,23,306,2554',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2555,306,'方山县',3,'0','141128','0,1,23,306,2555',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2556,306,'中阳县',3,'0','141129','0,1,23,306,2556',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2557,306,'交口县',3,'0','141130','0,1,23,306,2557',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2558,307,'朔城区',3,'0','140602','0,1,23,307,2558',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2559,307,'平鲁区',3,'0','140603','0,1,23,307,2559',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2560,307,'山阴县',3,'0','140621','0,1,23,307,2560',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2561,307,'应县',3,'0','140622','0,1,23,307,2561',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2562,307,'右玉县',3,'0','140623','0,1,23,307,2562',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2563,307,'怀仁县',3,'0','140624','0,1,23,307,2563',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2564,308,'忻府区',3,'0','140902','0,1,23,308,2564',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2565,308,'原平市',3,'0','140981','0,1,23,308,2565',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2566,308,'定襄县',3,'0','140921','0,1,23,308,2566',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2567,308,'五台县',3,'0','140922','0,1,23,308,2567',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2568,308,'代县',3,'0','140923','0,1,23,308,2568',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2569,308,'繁峙县',3,'0','140924','0,1,23,308,2569',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2570,308,'宁武县',3,'0','140925','0,1,23,308,2570',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2571,308,'静乐县',3,'0','140926','0,1,23,308,2571',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2572,308,'神池县',3,'0','140927','0,1,23,308,2572',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2573,308,'五寨县',3,'0','140928','0,1,23,308,2573',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2574,308,'岢岚县',3,'0','140929','0,1,23,308,2574',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2575,308,'河曲县',3,'0','140930','0,1,23,308,2575',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2576,308,'保德县',3,'0','140931','0,1,23,308,2576',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2577,308,'偏关县',3,'0','140932','0,1,23,308,2577',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2578,309,'城区',3,'0','140302','0,1,23,309,2578',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2579,309,'矿区',3,'0','140303','0,1,23,309,2579',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2580,309,'郊区',3,'0','140311','0,1,23,309,2580',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2581,309,'平定县',3,'0','140321','0,1,23,309,2581',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2582,309,'盂县',3,'0','140322','0,1,23,309,2582',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2583,310,'盐湖区',3,'0','140802','0,1,23,310,2583',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2584,310,'永济市',3,'0','140881','0,1,23,310,2584',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2585,310,'河津市',3,'0','140882','0,1,23,310,2585',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2586,310,'临猗县',3,'0','140821','0,1,23,310,2586',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2587,310,'万荣县',3,'0','140822','0,1,23,310,2587',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2588,310,'闻喜县',3,'0','140823','0,1,23,310,2588',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2589,310,'稷山县',3,'0','140824','0,1,23,310,2589',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2590,310,'新绛县',3,'0','140825','0,1,23,310,2590',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2591,310,'绛县',3,'0','140826','0,1,23,310,2591',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2592,310,'垣曲县',3,'0','140827','0,1,23,310,2592',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2593,310,'夏县',3,'0','140828','0,1,23,310,2593',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2594,310,'平陆县',3,'0','140829','0,1,23,310,2594',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2595,310,'芮城县',3,'0','140830','0,1,23,310,2595',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2596,311,'莲湖区',3,'0','610104','0,1,24,311,2596',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2597,311,'新城区',3,'0','610102','0,1,24,311,2597',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2598,311,'碑林区',3,'0','610103','0,1,24,311,2598',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2599,311,'雁塔区',3,'0','610113','0,1,24,311,2599',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2600,311,'灞桥区',3,'0','610111','0,1,24,311,2600',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2601,311,'未央区',3,'0','610112','0,1,24,311,2601',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2602,311,'阎良区',3,'0','610114','0,1,24,311,2602',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2603,311,'临潼区',3,'0','610115','0,1,24,311,2603',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2604,311,'长安区',3,'0','610116','0,1,24,311,2604',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2605,311,'蓝田县',3,'0','610122','0,1,24,311,2605',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2606,311,'周至县',3,'0','610124','0,1,24,311,2606',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2607,311,'户县',3,'0','610125','0,1,24,311,2607',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2608,311,'高陵县',3,'0','610126','0,1,24,311,2608',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2609,312,'汉滨区',3,'0','610902','0,1,24,312,2609',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2610,312,'汉阴县',3,'0','610921','0,1,24,312,2610',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2611,312,'石泉县',3,'0','610922','0,1,24,312,2611',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2612,312,'宁陕县',3,'0','610923','0,1,24,312,2612',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2613,312,'紫阳县',3,'0','610924','0,1,24,312,2613',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2614,312,'岚皋县',3,'0','610925','0,1,24,312,2614',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2615,312,'平利县',3,'0','610926','0,1,24,312,2615',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2616,312,'镇坪县',3,'0','610927','0,1,24,312,2616',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2617,312,'旬阳县',3,'0','610928','0,1,24,312,2617',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2618,312,'白河县',3,'0','610929','0,1,24,312,2618',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2619,313,'陈仓区',3,'0','610304','0,1,24,313,2619',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2620,313,'渭滨区',3,'0','610302','0,1,24,313,2620',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2621,313,'金台区',3,'0','610303','0,1,24,313,2621',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2622,313,'凤翔县',3,'0','610322','0,1,24,313,2622',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2623,313,'岐山县',3,'0','610323','0,1,24,313,2623',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2624,313,'扶风县',3,'0','610324','0,1,24,313,2624',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2625,313,'眉县',3,'0','610326','0,1,24,313,2625',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2626,313,'陇县',3,'0','610327','0,1,24,313,2626',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2627,313,'千阳县',3,'0','610328','0,1,24,313,2627',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2628,313,'麟游县',3,'0','610329','0,1,24,313,2628',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2629,313,'凤县',3,'0','610330','0,1,24,313,2629',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2630,313,'太白县',3,'0','610331','0,1,24,313,2630',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2631,314,'汉台区',3,'0','610702','0,1,24,314,2631',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2632,314,'南郑县',3,'0','610721','0,1,24,314,2632',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2633,314,'城固县',3,'0','610722','0,1,24,314,2633',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2634,314,'洋县',3,'0','610723','0,1,24,314,2634',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2635,314,'西乡县',3,'0','610724','0,1,24,314,2635',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2636,314,'勉县',3,'0','610725','0,1,24,314,2636',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2637,314,'宁强县',3,'0','610726','0,1,24,314,2637',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2638,314,'略阳县',3,'0','610727','0,1,24,314,2638',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2639,314,'镇巴县',3,'0','610728','0,1,24,314,2639',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2640,314,'留坝县',3,'0','610729','0,1,24,314,2640',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2641,314,'佛坪县',3,'0','610730','0,1,24,314,2641',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2642,315,'商州区',3,'0','611002','0,1,24,315,2642',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2643,315,'洛南县',3,'0','611021','0,1,24,315,2643',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2644,315,'丹凤县',3,'0','611022','0,1,24,315,2644',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2645,315,'商南县',3,'0','611023','0,1,24,315,2645',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2646,315,'山阳县',3,'0','611024','0,1,24,315,2646',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2647,315,'镇安县',3,'0','611025','0,1,24,315,2647',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2648,315,'柞水县',3,'0','611026','0,1,24,315,2648',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2649,316,'耀州区',3,'0','610204','0,1,24,316,2649',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2650,316,'王益区',3,'0','610202','0,1,24,316,2650',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2651,316,'印台区',3,'0','610203','0,1,24,316,2651',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2652,316,'宜君县',3,'0','610222','0,1,24,316,2652',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2653,317,'临渭区',3,'0','610502','0,1,24,317,2653',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2654,317,'韩城市',3,'0','610581','0,1,24,317,2654',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2655,317,'华阴市',3,'0','610582','0,1,24,317,2655',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2656,317,'华县',3,'0','610521','0,1,24,317,2656',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2657,317,'潼关县',3,'0','610522','0,1,24,317,2657',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2658,317,'大荔县',3,'0','610523','0,1,24,317,2658',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2659,317,'合阳县',3,'0','610524','0,1,24,317,2659',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2660,317,'澄城县',3,'0','610525','0,1,24,317,2660',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2661,317,'蒲城县',3,'0','610526','0,1,24,317,2661',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2662,317,'白水县',3,'0','610527','0,1,24,317,2662',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2663,317,'富平县',3,'0','610528','0,1,24,317,2663',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2664,318,'秦都区',3,'0','610402','0,1,24,318,2664',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2665,318,'渭城区',3,'0','610404','0,1,24,318,2665',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2666,318,'杨凌区',3,'0','610403','0,1,24,318,2666',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2667,318,'兴平市',3,'0','610481','0,1,24,318,2667',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2668,318,'三原县',3,'0','610422','0,1,24,318,2668',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2669,318,'泾阳县',3,'0','610423','0,1,24,318,2669',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2670,318,'乾县',3,'0','610424','0,1,24,318,2670',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2671,318,'礼泉县',3,'0','610425','0,1,24,318,2671',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2672,318,'永寿县',3,'0','610426','0,1,24,318,2672',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2673,318,'彬县',3,'0','610427','0,1,24,318,2673',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2674,318,'长武县',3,'0','610428','0,1,24,318,2674',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2675,318,'旬邑县',3,'0','610429','0,1,24,318,2675',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2676,318,'淳化县',3,'0','610430','0,1,24,318,2676',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2677,318,'武功县',3,'0','610431','0,1,24,318,2677',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2678,319,'吴起县',3,'0','610626','0,1,24,319,2678',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2679,319,'宝塔区',3,'0','610602','0,1,24,319,2679',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2680,319,'延长县',3,'0','610621','0,1,24,319,2680',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2681,319,'延川县',3,'0','610622','0,1,24,319,2681',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2682,319,'子长县',3,'0','610623','0,1,24,319,2682',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2683,319,'安塞县',3,'0','610624','0,1,24,319,2683',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2684,319,'志丹县',3,'0','610625','0,1,24,319,2684',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2685,319,'甘泉县',3,'0','610627','0,1,24,319,2685',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2686,319,'富县',3,'0','610628','0,1,24,319,2686',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2687,319,'洛川县',3,'0','610629','0,1,24,319,2687',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2688,319,'宜川县',3,'0','610630','0,1,24,319,2688',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2689,319,'黄龙县',3,'0','610631','0,1,24,319,2689',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2690,319,'黄陵县',3,'0','610632','0,1,24,319,2690',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2691,320,'榆阳区',3,'0','610802','0,1,24,320,2691',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2692,320,'神木县',3,'0','610821','0,1,24,320,2692',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2693,320,'府谷县',3,'0','610822','0,1,24,320,2693',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2694,320,'横山县',3,'0','610823','0,1,24,320,2694',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2695,320,'靖边县',3,'0','610824','0,1,24,320,2695',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2696,320,'定边县',3,'0','610825','0,1,24,320,2696',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2697,320,'绥德县',3,'0','610826','0,1,24,320,2697',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2698,320,'米脂县',3,'0','610827','0,1,24,320,2698',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2699,320,'佳县',3,'0','610828','0,1,24,320,2699',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2700,320,'吴堡县',3,'0','610829','0,1,24,320,2700',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2701,320,'清涧县',3,'0','610830','0,1,24,320,2701',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2702,320,'子洲县',3,'0','610831','0,1,24,320,2702',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2703,321,'长宁区',3,'0','310105','0,1,25,321,2703',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2704,321,'闸北区',3,'0','310108','0,1,25,321,2704',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2705,321,'闵行区',3,'0','310112','0,1,25,321,2705',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2706,321,'徐汇区',3,'0','310104','0,1,25,321,2706',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2707,321,'浦东新区',3,'0','310115','0,1,25,321,2707',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2708,321,'杨浦区',3,'0','310110','0,1,25,321,2708',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2709,321,'普陀区',3,'0','310107','0,1,25,321,2709',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2710,321,'静安区',3,'0','310106','0,1,25,321,2710',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2711,321,'卢湾区',3,'0','310103','0,1,25,321,2711',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2712,321,'虹口区',3,'0','310109','0,1,25,321,2712',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2713,321,'黄浦区',3,'0','310101','0,1,25,321,2713',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2714,321,'南汇区',3,'0','310119','0,1,25,321,2714',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2715,321,'松江区',3,'0','310117','0,1,25,321,2715',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2716,321,'嘉定区',3,'0','310114','0,1,25,321,2716',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2717,321,'宝山区',3,'0','310113','0,1,25,321,2717',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2718,321,'青浦区',3,'0','310118','0,1,25,321,2718',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2719,321,'金山区',3,'0','310116','0,1,25,321,2719',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2720,321,'奉贤区',3,'0','310120','0,1,25,321,2720',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2721,321,'崇明区',3,'0','310230','0,1,25,321,2721',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2722,322,'青羊区',3,'0','510105','0,1,26,322,2722',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2723,322,'锦江区',3,'0','510104','0,1,26,322,2723',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2724,322,'金牛区',3,'0','510106','0,1,26,322,2724',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2725,322,'武侯区',3,'0','510107','0,1,26,322,2725',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2726,322,'成华区',3,'0','510108','0,1,26,322,2726',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2727,322,'龙泉驿区',3,'0','510112','0,1,26,322,2727',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2728,322,'青白江区',3,'0','510113','0,1,26,322,2728',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2729,322,'新都区',3,'0','510114','0,1,26,322,2729',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2730,322,'温江区',3,'0','510115','0,1,26,322,2730',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2733,322,'都江堰市',3,'0','510181','0,1,26,322,2733',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2734,322,'彭州市',3,'0','510182','0,1,26,322,2734',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2735,322,'邛崃市',3,'0','510183','0,1,26,322,2735',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2736,322,'崇州市',3,'0','510184','0,1,26,322,2736',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2737,322,'金堂县',3,'0','510121','0,1,26,322,2737',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2738,322,'双流县',3,'0','510122','0,1,26,322,2738',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2739,322,'郫县',3,'0','510124','0,1,26,322,2739',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2740,322,'大邑县',3,'0','510129','0,1,26,322,2740',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2741,322,'蒲江县',3,'0','510131','0,1,26,322,2741',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2742,322,'新津县',3,'0','510132','0,1,26,322,2742',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2753,323,'涪城区',3,'0','510703','0,1,26,323,2753',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2754,323,'游仙区',3,'0','510704','0,1,26,323,2754',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2755,323,'江油市',3,'0','510781','0,1,26,323,2755',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2756,323,'盐亭县',3,'0','510723','0,1,26,323,2756',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2757,323,'三台县',3,'0','510722','0,1,26,323,2757',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2758,323,'平武县',3,'0','510727','0,1,26,323,2758',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2759,323,'安县',3,'0','510724','0,1,26,323,2759',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2760,323,'梓潼县',3,'0','510725','0,1,26,323,2760',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2761,323,'北川县',3,'0','510726','0,1,26,323,2761',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2762,324,'马尔康县',3,'0','513229','0,1,26,324,2762',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2763,324,'汶川县',3,'0','513221','0,1,26,324,2763',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2764,324,'理县',3,'0','513222','0,1,26,324,2764',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2765,324,'茂县',3,'0','513223','0,1,26,324,2765',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2766,324,'松潘县',3,'0','513224','0,1,26,324,2766',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2767,324,'九寨沟县',3,'0','513225','0,1,26,324,2767',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2768,324,'金川县',3,'0','513226','0,1,26,324,2768',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2769,324,'小金县',3,'0','513227','0,1,26,324,2769',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2770,324,'黑水县',3,'0','513228','0,1,26,324,2770',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2771,324,'壤塘县',3,'0','513230','0,1,26,324,2771',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2772,324,'阿坝县',3,'0','513231','0,1,26,324,2772',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2773,324,'若尔盖县',3,'0','513232','0,1,26,324,2773',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2774,324,'红原县',3,'0','513233','0,1,26,324,2774',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2775,325,'巴州区',3,'0','511902','0,1,26,325,2775',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2776,325,'通江县',3,'0','511921','0,1,26,325,2776',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2777,325,'南江县',3,'0','511922','0,1,26,325,2777',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2778,325,'平昌县',3,'0','511923','0,1,26,325,2778',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2779,326,'通川区',3,'0','511702','0,1,26,326,2779',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2780,326,'万源市',3,'0','511781','0,1,26,326,2780',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2781,326,'达县',3,'0','511721','0,1,26,326,2781',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2782,326,'宣汉县',3,'0','511722','0,1,26,326,2782',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2783,326,'开江县',3,'0','511723','0,1,26,326,2783',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2784,326,'大竹县',3,'0','511724','0,1,26,326,2784',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2785,326,'渠县',3,'0','511725','0,1,26,326,2785',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2786,327,'旌阳区',3,'0','510603','0,1,26,327,2786',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2787,327,'广汉市',3,'0','510681','0,1,26,327,2787',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2788,327,'什邡市',3,'0','510682','0,1,26,327,2788',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2789,327,'绵竹市',3,'0','510683','0,1,26,327,2789',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2790,327,'罗江县',3,'0','510626','0,1,26,327,2790',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2791,327,'中江县',3,'0','510623','0,1,26,327,2791',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2792,328,'康定县',3,'0','513321','0,1,26,328,2792',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2793,328,'丹巴县',3,'0','513323','0,1,26,328,2793',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2794,328,'泸定县',3,'0','513322','0,1,26,328,2794',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2795,328,'炉霍县',3,'0','513327','0,1,26,328,2795',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2796,328,'九龙县',3,'0','513324','0,1,26,328,2796',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2797,328,'甘孜县',3,'0','513328','0,1,26,328,2797',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2798,328,'雅江县',3,'0','513325','0,1,26,328,2798',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2799,328,'新龙县',3,'0','513329','0,1,26,328,2799',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2800,328,'道孚县',3,'0','513326','0,1,26,328,2800',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2801,328,'白玉县',3,'0','513331','0,1,26,328,2801',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2802,328,'理塘县',3,'0','513334','0,1,26,328,2802',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2803,328,'德格县',3,'0','513330','0,1,26,328,2803',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2804,328,'乡城县',3,'0','513336','0,1,26,328,2804',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2805,328,'石渠县',3,'0','513332','0,1,26,328,2805',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2806,328,'稻城县',3,'0','513337','0,1,26,328,2806',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2807,328,'色达县',3,'0','513333','0,1,26,328,2807',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2808,328,'巴塘县',3,'0','513335','0,1,26,328,2808',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2809,328,'得荣县',3,'0','513338','0,1,26,328,2809',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2810,329,'广安区',3,'0','511602','0,1,26,329,2810',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2811,329,'华蓥市',3,'0','511681','0,1,26,329,2811',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2812,329,'岳池县',3,'0','511621','0,1,26,329,2812',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2813,329,'武胜县',3,'0','511622','0,1,26,329,2813',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2814,329,'邻水县',3,'0','511623','0,1,26,329,2814',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2815,330,'利州区',3,'0','510802','0,1,26,330,2815',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2816,330,'元坝区',3,'0','510811','0,1,26,330,2816',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2817,330,'朝天区',3,'0','510812','0,1,26,330,2817',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2818,330,'旺苍县',3,'0','510821','0,1,26,330,2818',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2819,330,'青川县',3,'0','510822','0,1,26,330,2819',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2820,330,'剑阁县',3,'0','510823','0,1,26,330,2820',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2821,330,'苍溪县',3,'0','510824','0,1,26,330,2821',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2822,331,'峨眉山市',3,'0','511181','0,1,26,331,2822',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2823,331,'市中区',3,'0','511102','0,1,26,331,2823',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2824,331,'犍为县',3,'0','511123','0,1,26,331,2824',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2825,331,'井研县',3,'0','511124','0,1,26,331,2825',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2826,331,'夹江县',3,'0','511126','0,1,26,331,2826',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2827,331,'沐川县',3,'0','511129','0,1,26,331,2827',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2828,331,'峨边',3,'0','511132','0,1,26,331,2828',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2829,331,'马边',3,'0','511133','0,1,26,331,2829',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2830,332,'西昌市',3,'0','513401','0,1,26,332,2830',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2831,332,'盐源县',3,'0','513423','0,1,26,332,2831',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2832,332,'德昌县',3,'0','513424','0,1,26,332,2832',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2833,332,'会理县',3,'0','513425','0,1,26,332,2833',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2834,332,'会东县',3,'0','513426','0,1,26,332,2834',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2835,332,'宁南县',3,'0','513427','0,1,26,332,2835',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2836,332,'普格县',3,'0','513428','0,1,26,332,2836',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2837,332,'布拖县',3,'0','513429','0,1,26,332,2837',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2838,332,'金阳县',3,'0','513430','0,1,26,332,2838',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2839,332,'昭觉县',3,'0','513431','0,1,26,332,2839',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2840,332,'喜德县',3,'0','513432','0,1,26,332,2840',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2841,332,'冕宁县',3,'0','513433','0,1,26,332,2841',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2842,332,'越西县',3,'0','513434','0,1,26,332,2842',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2843,332,'甘洛县',3,'0','513435','0,1,26,332,2843',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2844,332,'美姑县',3,'0','513436','0,1,26,332,2844',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2845,332,'雷波县',3,'0','513437','0,1,26,332,2845',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2846,332,'木里',3,'0','513422','0,1,26,332,2846',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2847,333,'东坡区',3,'0','511402','0,1,26,333,2847',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2848,333,'仁寿县',3,'0','511421','0,1,26,333,2848',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2849,333,'彭山县',3,'0','511422','0,1,26,333,2849',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2850,333,'洪雅县',3,'0','511423','0,1,26,333,2850',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2851,333,'丹棱县',3,'0','511424','0,1,26,333,2851',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2852,333,'青神县',3,'0','511425','0,1,26,333,2852',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2853,334,'阆中市',3,'0','511381','0,1,26,334,2853',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2854,334,'南部县',3,'0','511321','0,1,26,334,2854',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2855,334,'营山县',3,'0','511322','0,1,26,334,2855',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2856,334,'蓬安县',3,'0','511323','0,1,26,334,2856',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2857,334,'仪陇县',3,'0','511324','0,1,26,334,2857',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2858,334,'顺庆区',3,'0','511302','0,1,26,334,2858',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2859,334,'高坪区',3,'0','511303','0,1,26,334,2859',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2860,334,'嘉陵区',3,'0','511304','0,1,26,334,2860',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2861,334,'西充县',3,'0','511325','0,1,26,334,2861',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2862,335,'市中区',3,'0','511002','0,1,26,335,2862',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2863,335,'东兴区',3,'0','511011','0,1,26,335,2863',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2864,335,'威远县',3,'0','511024','0,1,26,335,2864',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2865,335,'资中县',3,'0','511025','0,1,26,335,2865',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2866,335,'隆昌县',3,'0','511028','0,1,26,335,2866',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2867,336,'东  区',3,'0','510402','0,1,26,336,2867',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2868,336,'西  区',3,'0','510403','0,1,26,336,2868',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2869,336,'仁和区',3,'0','510411','0,1,26,336,2869',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2870,336,'米易县',3,'0','510421','0,1,26,336,2870',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2871,336,'盐边县',3,'0','510422','0,1,26,336,2871',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2872,337,'船山区',3,'0','510903','0,1,26,337,2872',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2873,337,'安居区',3,'0','510904','0,1,26,337,2873',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2874,337,'蓬溪县',3,'0','510921','0,1,26,337,2874',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2875,337,'射洪县',3,'0','510922','0,1,26,337,2875',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2876,337,'大英县',3,'0','510923','0,1,26,337,2876',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2877,338,'雨城区',3,'0','511802','0,1,26,338,2877',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2878,338,'名山县',3,'0','511821','0,1,26,338,2878',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2879,338,'荥经县',3,'0','511822','0,1,26,338,2879',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2880,338,'汉源县',3,'0','511823','0,1,26,338,2880',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2881,338,'石棉县',3,'0','511824','0,1,26,338,2881',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2882,338,'天全县',3,'0','511825','0,1,26,338,2882',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2883,338,'芦山县',3,'0','511826','0,1,26,338,2883',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2884,338,'宝兴县',3,'0','511827','0,1,26,338,2884',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2885,339,'翠屏区',3,'0','511502','0,1,26,339,2885',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2886,339,'宜宾县',3,'0','511521','0,1,26,339,2886',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2887,339,'南溪县',3,'0','511522','0,1,26,339,2887',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2888,339,'江安县',3,'0','511523','0,1,26,339,2888',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2889,339,'长宁县',3,'0','511524','0,1,26,339,2889',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2890,339,'高县',3,'0','511525','0,1,26,339,2890',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2891,339,'珙县',3,'0','511526','0,1,26,339,2891',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2892,339,'筠连县',3,'0','511527','0,1,26,339,2892',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2893,339,'兴文县',3,'0','511528','0,1,26,339,2893',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2894,339,'屏山县',3,'0','511529','0,1,26,339,2894',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2895,340,'雁江区',3,'0','512002','0,1,26,340,2895',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2896,340,'简阳市',3,'0','512081','0,1,26,340,2896',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2897,340,'安岳县',3,'0','512021','0,1,26,340,2897',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2898,340,'乐至县',3,'0','512022','0,1,26,340,2898',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2899,341,'大安区',3,'0','510304','0,1,26,341,2899',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2900,341,'自流井区',3,'0','510302','0,1,26,341,2900',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2901,341,'贡井区',3,'0','510303','0,1,26,341,2901',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2902,341,'沿滩区',3,'0','510311','0,1,26,341,2902',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2903,341,'荣县',3,'0','510321','0,1,26,341,2903',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2904,341,'富顺县',3,'0','510322','0,1,26,341,2904',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2905,342,'江阳区',3,'0','510502','0,1,26,342,2905',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2906,342,'纳溪区',3,'0','510503','0,1,26,342,2906',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2907,342,'龙马潭区',3,'0','510504','0,1,26,342,2907',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2908,342,'泸县',3,'0','510521','0,1,26,342,2908',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2909,342,'合江县',3,'0','510522','0,1,26,342,2909',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2910,342,'叙永县',3,'0','510524','0,1,26,342,2910',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2911,342,'古蔺县',3,'0','510525','0,1,26,342,2911',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2912,343,'和平区',3,'0','120101','0,1,27,343,2912',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2913,343,'河西区',3,'0','120103','0,1,27,343,2913',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2914,343,'南开区',3,'0','120104','0,1,27,343,2914',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2915,343,'河北区',3,'0','120105','0,1,27,343,2915',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2916,343,'河东区',3,'0','120102','0,1,27,343,2916',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2917,343,'红桥区',3,'0','120106','0,1,27,343,2917',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2918,343,'东丽区',3,'0','120110','0,1,27,343,2918',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2919,343,'津南区',3,'0','120112','0,1,27,343,2919',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2920,343,'西青区',3,'0','120111','0,1,27,343,2920',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2921,343,'北辰区',3,'0','120113','0,1,27,343,2921',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2922,343,'塘沽区',3,'0','120107','0,1,27,343,2922',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2923,343,'汉沽区',3,'0','120108','0,1,27,343,2923',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2924,343,'大港区',3,'0','120109','0,1,27,343,2924',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2925,343,'武清区',3,'0','120114','0,1,27,343,2925',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2926,343,'宝坻区',3,'0','120115','0,1,27,343,2926',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2928,343,'宁河县',3,'0','120221','0,1,27,343,2928',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2929,343,'静海县',3,'0','120223','0,1,27,343,2929',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2930,343,'蓟县',3,'0','120225','0,1,27,343,2930',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2931,344,'城关区',3,'0','540102','0,1,28,344,2931',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2932,344,'林周县',3,'0','540121','0,1,28,344,2932',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2933,344,'当雄县',3,'0','540122','0,1,28,344,2933',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2934,344,'尼木县',3,'0','540123','0,1,28,344,2934',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2935,344,'曲水县',3,'0','540124','0,1,28,344,2935',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2936,344,'堆龙德庆县',3,'0','540125','0,1,28,344,2936',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2937,344,'达孜县',3,'0','540126','0,1,28,344,2937',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2938,344,'墨竹工卡县',3,'0','540127','0,1,28,344,2938',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2939,345,'噶尔县',3,'0','542523','0,1,28,345,2939',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2940,345,'普兰县',3,'0','542521','0,1,28,345,2940',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2941,345,'札达县',3,'0','542522','0,1,28,345,2941',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2942,345,'日土县',3,'0','542524','0,1,28,345,2942',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2943,345,'革吉县',3,'0','542525','0,1,28,345,2943',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2944,345,'改则县',3,'0','542526','0,1,28,345,2944',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2945,345,'措勤县',3,'0','542527','0,1,28,345,2945',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2946,346,'昌都县',3,'0','542121','0,1,28,346,2946',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2947,346,'江达县',3,'0','542122','0,1,28,346,2947',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2948,346,'贡觉县',3,'0','542123','0,1,28,346,2948',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2949,346,'类乌齐县',3,'0','542124','0,1,28,346,2949',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2950,346,'丁青县',3,'0','542125','0,1,28,346,2950',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2951,346,'察雅县',3,'0','542126','0,1,28,346,2951',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2952,346,'八宿县',3,'0','542127','0,1,28,346,2952',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2953,346,'左贡县',3,'0','542128','0,1,28,346,2953',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2954,346,'芒康县',3,'0','542129','0,1,28,346,2954',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2955,346,'洛隆县',3,'0','542132','0,1,28,346,2955',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2956,346,'边坝县',3,'0','542133','0,1,28,346,2956',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2957,347,'林芝县',3,'0','542621','0,1,28,347,2957',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2958,347,'工布江达县',3,'0','542622','0,1,28,347,2958',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2959,347,'米林县',3,'0','542623','0,1,28,347,2959',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2960,347,'墨脱县',3,'0','542624','0,1,28,347,2960',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2961,347,'波密县',3,'0','542625','0,1,28,347,2961',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2962,347,'察隅县',3,'0','542626','0,1,28,347,2962',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2963,347,'朗县',3,'0','542627','0,1,28,347,2963',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2964,348,'那曲县',3,'0','542421','0,1,28,348,2964',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2965,348,'嘉黎县',3,'0','542422','0,1,28,348,2965',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2966,348,'比如县',3,'0','542423','0,1,28,348,2966',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2967,348,'聂荣县',3,'0','542424','0,1,28,348,2967',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2968,348,'安多县',3,'0','542425','0,1,28,348,2968',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2969,348,'申扎县',3,'0','542426','0,1,28,348,2969',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2970,348,'索县',3,'0','542427','0,1,28,348,2970',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2971,348,'班戈县',3,'0','542428','0,1,28,348,2971',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2972,348,'巴青县',3,'0','542429','0,1,28,348,2972',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2973,348,'尼玛县',3,'0','542430','0,1,28,348,2973',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2974,349,'日喀则市',3,'0','542301','0,1,28,349,2974',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2975,349,'南木林县',3,'0','542322','0,1,28,349,2975',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2976,349,'江孜县',3,'0','542323','0,1,28,349,2976',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2977,349,'定日县',3,'0','542324','0,1,28,349,2977',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2978,349,'萨迦县',3,'0','542325','0,1,28,349,2978',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2979,349,'拉孜县',3,'0','542326','0,1,28,349,2979',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2980,349,'昂仁县',3,'0','542327','0,1,28,349,2980',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2981,349,'谢通门县',3,'0','542328','0,1,28,349,2981',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2982,349,'白朗县',3,'0','542329','0,1,28,349,2982',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2983,349,'仁布县',3,'0','542330','0,1,28,349,2983',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2984,349,'康马县',3,'0','542331','0,1,28,349,2984',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2985,349,'定结县',3,'0','542332','0,1,28,349,2985',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2986,349,'仲巴县',3,'0','542333','0,1,28,349,2986',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2987,349,'亚东县',3,'0','542334','0,1,28,349,2987',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2988,349,'吉隆县',3,'0','542335','0,1,28,349,2988',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2989,349,'聂拉木县',3,'0','542336','0,1,28,349,2989',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2990,349,'萨嘎县',3,'0','542337','0,1,28,349,2990',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2991,349,'岗巴县',3,'0','542338','0,1,28,349,2991',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2992,350,'乃东县',3,'0','542221','0,1,28,350,2992',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2993,350,'扎囊县',3,'0','542222','0,1,28,350,2993',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2994,350,'贡嘎县',3,'0','542223','0,1,28,350,2994',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2995,350,'桑日县',3,'0','542224','0,1,28,350,2995',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2996,350,'琼结县',3,'0','542225','0,1,28,350,2996',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2997,350,'曲松县',3,'0','542226','0,1,28,350,2997',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2998,350,'措美县',3,'0','542227','0,1,28,350,2998',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(2999,350,'洛扎县',3,'0','542228','0,1,28,350,2999',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3000,350,'加查县',3,'0','542229','0,1,28,350,3000',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3001,350,'隆子县',3,'0','542231','0,1,28,350,3001',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3002,350,'错那县',3,'0','542232','0,1,28,350,3002',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3003,350,'浪卡子县',3,'0','542233','0,1,28,350,3003',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3004,351,'天山区',3,'0','650102','0,1,29,351,3004',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3005,351,'沙依巴克区',3,'0','650103','0,1,29,351,3005',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3006,351,'新市区',3,'0','650104','0,1,29,351,3006',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3007,351,'水磨沟区',3,'0','650105','0,1,29,351,3007',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3008,351,'头屯河区',3,'0','650106','0,1,29,351,3008',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3009,351,'达坂城区',3,'0','650107','0,1,29,351,3009',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3010,351,'东山区',3,'0','650108','0,1,29,351,3010',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3011,351,'乌鲁木齐县',3,'0','650121','0,1,29,351,3011',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3012,352,'阿克苏市',3,'0','652901','0,1,29,352,3012',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3013,352,'温宿县',3,'0','652922','0,1,29,352,3013',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3014,352,'库车县',3,'0','652923','0,1,29,352,3014',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3015,352,'沙雅县',3,'0','652924','0,1,29,352,3015',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3016,352,'新和县',3,'0','652925','0,1,29,352,3016',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3017,352,'拜城县',3,'0','652926','0,1,29,352,3017',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3018,352,'乌什县',3,'0','652927','0,1,29,352,3018',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3019,352,'阿瓦提县',3,'0','652928','0,1,29,352,3019',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3020,352,'柯坪县',3,'0','652929','0,1,29,352,3020',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3022,354,'库尔勒市',3,'0','652801','0,1,29,354,3022',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3023,354,'轮台县',3,'0','652822','0,1,29,354,3023',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3024,354,'尉犁县',3,'0','652823','0,1,29,354,3024',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3025,354,'若羌县',3,'0','652824','0,1,29,354,3025',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3026,354,'且末县',3,'0','652825','0,1,29,354,3026',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3027,354,'焉耆',3,'0','652826','0,1,29,354,3027',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3028,354,'和静县',3,'0','652827','0,1,29,354,3028',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3029,354,'和硕县',3,'0','652828','0,1,29,354,3029',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3030,354,'博湖县',3,'0','652829','0,1,29,354,3030',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3031,355,'博乐市',3,'0','652701','0,1,29,355,3031',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3032,355,'精河县',3,'0','652722','0,1,29,355,3032',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3033,355,'温泉县',3,'0','652723','0,1,29,355,3033',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3034,356,'呼图壁县',3,'0','652323','0,1,29,356,3034',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3035,356,'米泉市',3,'0','652303','0,1,29,356,3035',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3036,356,'昌吉市',3,'0','652301','0,1,29,356,3036',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3037,356,'阜康市',3,'0','652302','0,1,29,356,3037',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3038,356,'玛纳斯县',3,'0','652324','0,1,29,356,3038',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3039,356,'奇台县',3,'0','652325','0,1,29,356,3039',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3040,356,'吉木萨尔县',3,'0','652327','0,1,29,356,3040',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3041,356,'木垒',3,'0','652328','0,1,29,356,3041',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3042,357,'哈密市',3,'0','652201','0,1,29,357,3042',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3043,357,'伊吾县',3,'0','652223','0,1,29,357,3043',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3044,357,'巴里坤',3,'0','652222','0,1,29,357,3044',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3045,358,'和田市',3,'0','653201','0,1,29,358,3045',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3046,358,'和田县',3,'0','653221','0,1,29,358,3046',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3047,358,'墨玉县',3,'0','653222','0,1,29,358,3047',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3048,358,'皮山县',3,'0','653223','0,1,29,358,3048',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3049,358,'洛浦县',3,'0','653224','0,1,29,358,3049',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3050,358,'策勒县',3,'0','653225','0,1,29,358,3050',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3051,358,'于田县',3,'0','653226','0,1,29,358,3051',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3052,358,'民丰县',3,'0','653227','0,1,29,358,3052',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3053,359,'喀什市',3,'0','653101','0,1,29,359,3053',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3054,359,'疏附县',3,'0','653121','0,1,29,359,3054',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3055,359,'疏勒县',3,'0','653122','0,1,29,359,3055',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3056,359,'英吉沙县',3,'0','653123','0,1,29,359,3056',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3057,359,'泽普县',3,'0','653124','0,1,29,359,3057',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3058,359,'莎车县',3,'0','653125','0,1,29,359,3058',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3059,359,'叶城县',3,'0','653126','0,1,29,359,3059',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3060,359,'麦盖提县',3,'0','653127','0,1,29,359,3060',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3061,359,'岳普湖县',3,'0','653128','0,1,29,359,3061',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3062,359,'伽师县',3,'0','653129','0,1,29,359,3062',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3063,359,'巴楚县',3,'0','653130','0,1,29,359,3063',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3064,359,'塔什库尔干',3,'0','653131','0,1,29,359,3064',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3066,361,'阿图什市',3,'0','653001','0,1,29,361,3066',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3067,361,'阿克陶县',3,'0','653022','0,1,29,361,3067',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3068,361,'阿合奇县',3,'0','653023','0,1,29,361,3068',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3069,361,'乌恰县',3,'0','653024','0,1,29,361,3069',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3072,364,'吐鲁番市',3,'0','652101','0,1,29,364,3072',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3073,364,'鄯善县',3,'0','652122','0,1,29,364,3073',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3074,364,'托克逊县',3,'0','652123','0,1,29,364,3074',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3075,365,'五家渠市',3,'0994','659004','0,1,29,365,3075',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3078,366,'伊宁市',3,'0','654002','0,1,29,366,3078',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3080,366,'奎屯市',3,'0','654003','0,1,29,366,3080',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3084,366,'伊宁县',3,'0','654021','0,1,29,366,3084',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3086,366,'霍城县',3,'0','654023','0,1,29,366,3086',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3088,366,'巩留县',3,'0','654024','0,1,29,366,3088',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3092,366,'新源县',3,'0','654025','0,1,29,366,3092',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3096,366,'昭苏县',3,'0','654026','0,1,29,366,3096',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3097,366,'特克斯县',3,'0','654027','0,1,29,366,3097',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3098,366,'尼勒克县',3,'0','654028','0,1,29,366,3098',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3099,366,'察布查尔',3,'0','654022','0,1,29,366,3099',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3100,367,'盘龙区',3,'0','530103','0,1,30,367,3100',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3101,367,'五华区',3,'0','530102','0,1,30,367,3101',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3102,367,'官渡区',3,'0','530111','0,1,30,367,3102',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3103,367,'西山区',3,'0','530112','0,1,30,367,3103',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3104,367,'东川区',3,'0','530113','0,1,30,367,3104',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3105,367,'安宁市',3,'0','530181','0,1,30,367,3105',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3106,367,'呈贡县',3,'0','530121','0,1,30,367,3106',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3107,367,'晋宁县',3,'0','530122','0,1,30,367,3107',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3108,367,'富民县',3,'0','530124','0,1,30,367,3108',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3109,367,'宜良县',3,'0','530125','0,1,30,367,3109',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3110,367,'嵩明县',3,'0','530127','0,1,30,367,3110',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3111,367,'石林县',3,'0','530126','0,1,30,367,3111',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3112,367,'禄劝',3,'0','530128','0,1,30,367,3112',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3113,367,'寻甸',3,'0','530129','0,1,30,367,3113',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3114,368,'兰坪',3,'0','533325','0,1,30,368,3114',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3115,368,'泸水县',3,'0','533321','0,1,30,368,3115',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3116,368,'福贡县',3,'0','533323','0,1,30,368,3116',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3117,368,'贡山',3,'0','533324','0,1,30,368,3117',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3118,369,'普洱',3,'0','530821','0,1,30,369,3118',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3119,369,'翠云区',3,'0','530802','0,1,30,369,3119',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3120,369,'墨江',3,'0','530822','0,1,30,369,3120',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3121,369,'景东',3,'0','530823','0,1,30,369,3121',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3122,369,'景谷',3,'0','530824','0,1,30,369,3122',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3123,369,'镇沅',3,'0','530825','0,1,30,369,3123',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3124,369,'江城',3,'0','530826','0,1,30,369,3124',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3125,369,'孟连',3,'0','530827','0,1,30,369,3125',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3126,369,'澜沧',3,'0','530828','0,1,30,369,3126',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3127,369,'西盟',3,'0','530829','0,1,30,369,3127',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3128,370,'古城区',3,'0','530702','0,1,30,370,3128',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3129,370,'宁蒗',3,'0','530724','0,1,30,370,3129',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3130,370,'玉龙',3,'0','530721','0,1,30,370,3130',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3131,370,'永胜县',3,'0','530722','0,1,30,370,3131',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3132,370,'华坪县',3,'0','530723','0,1,30,370,3132',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3133,371,'隆阳区',3,'0','530502','0,1,30,371,3133',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3134,371,'施甸县',3,'0','530521','0,1,30,371,3134',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3135,371,'腾冲县',3,'0','530522','0,1,30,371,3135',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3136,371,'龙陵县',3,'0','530523','0,1,30,371,3136',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3137,371,'昌宁县',3,'0','530524','0,1,30,371,3137',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3138,372,'楚雄市',3,'0','532301','0,1,30,372,3138',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3139,372,'双柏县',3,'0','532322','0,1,30,372,3139',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3140,372,'牟定县',3,'0','532323','0,1,30,372,3140',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3141,372,'南华县',3,'0','532324','0,1,30,372,3141',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3142,372,'姚安县',3,'0','532325','0,1,30,372,3142',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3143,372,'大姚县',3,'0','532326','0,1,30,372,3143',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3144,372,'永仁县',3,'0','532327','0,1,30,372,3144',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3145,372,'元谋县',3,'0','532328','0,1,30,372,3145',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3146,372,'武定县',3,'0','532329','0,1,30,372,3146',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3147,372,'禄丰县',3,'0','532331','0,1,30,372,3147',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3148,373,'大理市',3,'0','532901','0,1,30,373,3148',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3149,373,'祥云县',3,'0','532923','0,1,30,373,3149',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3150,373,'宾川县',3,'0','532924','0,1,30,373,3150',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3151,373,'弥渡县',3,'0','532925','0,1,30,373,3151',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3152,373,'永平县',3,'0','532928','0,1,30,373,3152',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3153,373,'云龙县',3,'0','532929','0,1,30,373,3153',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3154,373,'洱源县',3,'0','532930','0,1,30,373,3154',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3155,373,'剑川县',3,'0','532931','0,1,30,373,3155',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3156,373,'鹤庆县',3,'0','532932','0,1,30,373,3156',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3157,373,'漾濞',3,'0','532922','0,1,30,373,3157',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3158,373,'南涧',3,'0','532926','0,1,30,373,3158',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3159,373,'巍山',3,'0','532927','0,1,30,373,3159',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3160,374,'潞西市',3,'0','533103','0,1,30,374,3160',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3161,374,'瑞丽市',3,'0','533102','0,1,30,374,3161',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3162,374,'梁河县',3,'0','533122','0,1,30,374,3162',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3163,374,'盈江县',3,'0','533123','0,1,30,374,3163',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3164,374,'陇川县',3,'0','533124','0,1,30,374,3164',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3165,375,'香格里拉县',3,'0','533421','0,1,30,375,3165',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3166,375,'德钦县',3,'0','533422','0,1,30,375,3166',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3167,375,'维西',3,'0','533423','0,1,30,375,3167',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3168,376,'泸西县',3,'0','532527','0,1,30,376,3168',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3169,376,'蒙自县',3,'0','532522','0,1,30,376,3169',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3170,376,'个旧市',3,'0','532501','0,1,30,376,3170',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3171,376,'开远市',3,'0','532502','0,1,30,376,3171',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3172,376,'绿春县',3,'0','532531','0,1,30,376,3172',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3173,376,'建水县',3,'0','532524','0,1,30,376,3173',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3174,376,'石屏县',3,'0','532525','0,1,30,376,3174',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3175,376,'弥勒县',3,'0','532526','0,1,30,376,3175',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3176,376,'元阳县',3,'0','532528','0,1,30,376,3176',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3177,376,'红河县',3,'0','532529','0,1,30,376,3177',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3178,376,'金平',3,'0','532530','0,1,30,376,3178',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3179,376,'河口',3,'0','532532','0,1,30,376,3179',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3180,376,'屏边',3,'0','532523','0,1,30,376,3180',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3181,377,'临翔区',3,'0','530902','0,1,30,377,3181',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3182,377,'凤庆县',3,'0','530921','0,1,30,377,3182',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3183,377,'云县',3,'0','530922','0,1,30,377,3183',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3184,377,'永德县',3,'0','530923','0,1,30,377,3184',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3185,377,'镇康县',3,'0','530924','0,1,30,377,3185',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3186,377,'双江',3,'0','530925','0,1,30,377,3186',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3187,377,'耿马',3,'0','530926','0,1,30,377,3187',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3188,377,'沧源',3,'0','530927','0,1,30,377,3188',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3189,378,'麒麟区',3,'0','530302','0,1,30,378,3189',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3190,378,'宣威市',3,'0','530381','0,1,30,378,3190',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3191,378,'马龙县',3,'0','530321','0,1,30,378,3191',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3192,378,'陆良县',3,'0','530322','0,1,30,378,3192',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3193,378,'师宗县',3,'0','530323','0,1,30,378,3193',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3194,378,'罗平县',3,'0','530324','0,1,30,378,3194',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3195,378,'富源县',3,'0','530325','0,1,30,378,3195',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3196,378,'会泽县',3,'0','530326','0,1,30,378,3196',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3197,378,'沾益县',3,'0','530328','0,1,30,378,3197',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3198,379,'文山县',3,'0','532621','0,1,30,379,3198',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3199,379,'砚山县',3,'0','532622','0,1,30,379,3199',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3200,379,'西畴县',3,'0','532623','0,1,30,379,3200',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3201,379,'麻栗坡县',3,'0','532624','0,1,30,379,3201',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3202,379,'马关县',3,'0','532625','0,1,30,379,3202',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3203,379,'丘北县',3,'0','532626','0,1,30,379,3203',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3204,379,'广南县',3,'0','532627','0,1,30,379,3204',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3205,379,'富宁县',3,'0','532628','0,1,30,379,3205',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3206,380,'景洪市',3,'0','532801','0,1,30,380,3206',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3207,380,'勐海县',3,'0','532822','0,1,30,380,3207',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3208,380,'勐腊县',3,'0','532823','0,1,30,380,3208',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3209,381,'红塔区',3,'0','530402','0,1,30,381,3209',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3210,381,'江川县',3,'0','530421','0,1,30,381,3210',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3211,381,'澄江县',3,'0','530422','0,1,30,381,3211',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3212,381,'通海县',3,'0','530423','0,1,30,381,3212',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3213,381,'华宁县',3,'0','530424','0,1,30,381,3213',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3214,381,'易门县',3,'0','530425','0,1,30,381,3214',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3215,381,'峨山',3,'0','530426','0,1,30,381,3215',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3216,381,'新平',3,'0','530427','0,1,30,381,3216',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3217,381,'元江',3,'0','530428','0,1,30,381,3217',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3218,382,'昭阳区',3,'0','530602','0,1,30,382,3218',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3219,382,'鲁甸县',3,'0','530621','0,1,30,382,3219',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3220,382,'巧家县',3,'0','530622','0,1,30,382,3220',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3221,382,'盐津县',3,'0','530623','0,1,30,382,3221',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3222,382,'大关县',3,'0','530624','0,1,30,382,3222',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3223,382,'永善县',3,'0','530625','0,1,30,382,3223',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3224,382,'绥江县',3,'0','530626','0,1,30,382,3224',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3225,382,'镇雄县',3,'0','530627','0,1,30,382,3225',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3226,382,'彝良县',3,'0','530628','0,1,30,382,3226',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3227,382,'威信县',3,'0','530629','0,1,30,382,3227',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3228,382,'水富县',3,'0','530630','0,1,30,382,3228',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3229,383,'西湖区',3,'0','330106','0,1,31,383,3229',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3230,383,'上城区',3,'0','330102','0,1,31,383,3230',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3231,383,'下城区',3,'0','330103','0,1,31,383,3231',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3232,383,'拱墅区',3,'0','330105','0,1,31,383,3232',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3233,383,'滨江区',3,'0','330108','0,1,31,383,3233',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3234,383,'江干区',3,'0','330104','0,1,31,383,3234',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3235,383,'萧山区',3,'0','330109','0,1,31,383,3235',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3236,383,'余杭区',3,'0','330110','0,1,31,383,3236',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3238,383,'建德市',3,'0','330182','0,1,31,383,3238',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3239,383,'富阳市',3,'0','330183','0,1,31,383,3239',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3240,383,'临安市',3,'0','330185','0,1,31,383,3240',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3241,383,'桐庐县',3,'0','330122','0,1,31,383,3241',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3242,383,'淳安县',3,'0','330127','0,1,31,383,3242',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3243,384,'吴兴区',3,'0','330502','0,1,31,384,3243',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3244,384,'南浔区',3,'0','330503','0,1,31,384,3244',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3245,384,'德清县',3,'0','330521','0,1,31,384,3245',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3246,384,'长兴县',3,'0','330522','0,1,31,384,3246',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3247,384,'安吉县',3,'0','330523','0,1,31,384,3247',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3248,385,'南湖区',3,'0','330402','0,1,31,385,3248',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3249,385,'秀洲区',3,'0','330411','0,1,31,385,3249',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3250,385,'海宁市',3,'0','330481','0,1,31,385,3250',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3251,385,'嘉善县',3,'0','330421','0,1,31,385,3251',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3252,385,'平湖市',3,'0','330482','0,1,31,385,3252',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3253,385,'桐乡市',3,'0','330483','0,1,31,385,3253',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3254,385,'海盐县',3,'0','330424','0,1,31,385,3254',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3255,386,'婺城区',3,'0','330702','0,1,31,386,3255',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3256,386,'金东区',3,'0','330703','0,1,31,386,3256',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3257,386,'兰溪市',3,'0','330781','0,1,31,386,3257',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3258,386,'市区',3,'0','330701','0,1,31,386,3258',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3265,386,'东阳市',3,'0','330783','0,1,31,386,3265',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3266,386,'永康市',3,'0','330784','0,1,31,386,3266',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3267,386,'武义县',3,'0','330723','0,1,31,386,3267',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3268,386,'浦江县',3,'0','330726','0,1,31,386,3268',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3269,386,'磐安县',3,'0','330727','0,1,31,386,3269',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3270,387,'莲都区',3,'0','331102','0,1,31,387,3270',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3271,387,'龙泉市',3,'0','331181','0,1,31,387,3271',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3272,387,'青田县',3,'0','331121','0,1,31,387,3272',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3273,387,'缙云县',3,'0','331122','0,1,31,387,3273',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3274,387,'遂昌县',3,'0','331123','0,1,31,387,3274',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3275,387,'松阳县',3,'0','331124','0,1,31,387,3275',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3276,387,'云和县',3,'0','331125','0,1,31,387,3276',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3277,387,'庆元县',3,'0','331126','0,1,31,387,3277',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3278,387,'景宁',3,'0','331127','0,1,31,387,3278',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3279,388,'海曙区',3,'0','330203','0,1,31,388,3279',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3280,388,'江东区',3,'0','330204','0,1,31,388,3280',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3281,388,'江北区',3,'0','330205','0,1,31,388,3281',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3282,388,'镇海区',3,'0','330211','0,1,31,388,3282',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3283,388,'北仑区',3,'0','330206','0,1,31,388,3283',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3284,388,'鄞州区',3,'0','330212','0,1,31,388,3284',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3285,388,'余姚市',3,'0','330281','0,1,31,388,3285',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3286,388,'慈溪市',3,'0','330282','0,1,31,388,3286',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3287,388,'奉化市',3,'0','330283','0,1,31,388,3287',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3288,388,'象山县',3,'0','330225','0,1,31,388,3288',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3289,388,'宁海县',3,'0','330226','0,1,31,388,3289',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3290,389,'越城区',3,'0','330602','0,1,31,389,3290',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3291,389,'上虞市',3,'0','330682','0,1,31,389,3291',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3292,389,'嵊州市',3,'0','330683','0,1,31,389,3292',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3293,389,'绍兴县',3,'0','330621','0,1,31,389,3293',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3294,389,'新昌县',3,'0','330624','0,1,31,389,3294',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3295,389,'诸暨市',3,'0','330681','0,1,31,389,3295',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3296,390,'椒江区',3,'0','331002','0,1,31,390,3296',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3297,390,'黄岩区',3,'0','331003','0,1,31,390,3297',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3298,390,'路桥区',3,'0','331004','0,1,31,390,3298',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3299,390,'温岭市',3,'0','331081','0,1,31,390,3299',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3300,390,'临海市',3,'0','331082','0,1,31,390,3300',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3301,390,'玉环县',3,'0','331021','0,1,31,390,3301',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3302,390,'三门县',3,'0','331022','0,1,31,390,3302',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3303,390,'天台县',3,'0','331023','0,1,31,390,3303',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3304,390,'仙居县',3,'0','331024','0,1,31,390,3304',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3305,391,'鹿城区',3,'0','330302','0,1,31,391,3305',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3306,391,'龙湾区',3,'0','330303','0,1,31,391,3306',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3307,391,'瓯海区',3,'0','330304','0,1,31,391,3307',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3308,391,'瑞安市',3,'0','330381','0,1,31,391,3308',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3309,391,'乐清市',3,'0','330382','0,1,31,391,3309',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3310,391,'洞头县',3,'0','330322','0,1,31,391,3310',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3311,391,'永嘉县',3,'0','330324','0,1,31,391,3311',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3312,391,'平阳县',3,'0','330326','0,1,31,391,3312',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3313,391,'苍南县',3,'0','330327','0,1,31,391,3313',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3314,391,'文成县',3,'0','330328','0,1,31,391,3314',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3315,391,'泰顺县',3,'0','330329','0,1,31,391,3315',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3316,392,'定海区',3,'0','330902','0,1,31,392,3316',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3317,392,'普陀区',3,'0','330903','0,1,31,392,3317',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3318,392,'岱山县',3,'0','330921','0,1,31,392,3318',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3319,392,'嵊泗县',3,'0','330922','0,1,31,392,3319',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3320,393,'衢州市',3,'0','330801','0,1,31,393,3320',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3321,393,'江山市',3,'0','330881','0,1,31,393,3321',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3322,393,'常山县',3,'0','330822','0,1,31,393,3322',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3323,393,'开化县',3,'0','330824','0,1,31,393,3323',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3324,393,'龙游县',3,'0','330825','0,1,31,393,3324',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3325,394,'合川区',3,'0','500382','0,1,32,394,3325',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3326,394,'江津区',3,'0','500381','0,1,32,394,3326',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3327,394,'南川区',3,'0','500384','0,1,32,394,3327',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3328,394,'永川区',3,'0','500383','0,1,32,394,3328',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3329,394,'南岸区',3,'0','500108','0,1,32,394,3329',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3330,394,'渝北区',3,'0','500112','0,1,32,394,3330',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3331,394,'万盛区',3,'0','500110','0,1,32,394,3331',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3332,394,'大渡口区',3,'0','500104','0,1,32,394,3332',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3333,394,'万州区',3,'0','500101','0,1,32,394,3333',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3334,394,'北碚区',3,'0','500109','0,1,32,394,3334',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3335,394,'沙坪坝区',3,'0','500106','0,1,32,394,3335',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3336,394,'巴南区',3,'0','500113','0,1,32,394,3336',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3337,394,'涪陵区',3,'0','500102','0,1,32,394,3337',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3338,394,'江北区',3,'0','500105','0,1,32,394,3338',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3339,394,'九龙坡区',3,'0','500107','0,1,32,394,3339',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3340,394,'渝中区',3,'0','500103','0,1,32,394,3340',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3341,394,'黔江开发区',3,'0','500114','0,1,32,394,3341',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3342,394,'长寿区',3,'0','500115','0,1,32,394,3342',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3343,394,'双桥区',3,'0','500111','0,1,32,394,3343',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3344,394,'綦江县',3,'0','500222','0,1,32,394,3344',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3345,394,'潼南县',3,'0','500223','0,1,32,394,3345',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3346,394,'铜梁县',3,'0','500224','0,1,32,394,3346',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3347,394,'大足县',3,'0','500225','0,1,32,394,3347',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3348,394,'荣昌县',3,'0','500226','0,1,32,394,3348',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3349,394,'璧山县',3,'0','500227','0,1,32,394,3349',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3350,394,'垫江县',3,'0','500231','0,1,32,394,3350',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3351,394,'武隆县',3,'0','500232','0,1,32,394,3351',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3352,394,'丰都县',3,'0','500230','0,1,32,394,3352',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3353,394,'城口县',3,'0','500229','0,1,32,394,3353',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3354,394,'梁平县',3,'0','500228','0,1,32,394,3354',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3355,394,'开县',3,'0','500234','0,1,32,394,3355',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3356,394,'巫溪县',3,'0','500238','0,1,32,394,3356',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3357,394,'巫山县',3,'0','500237','0,1,32,394,3357',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3358,394,'奉节县',3,'0','500236','0,1,32,394,3358',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3359,394,'云阳县',3,'0','500235','0,1,32,394,3359',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3360,394,'忠县',3,'0','500233','0,1,32,394,3360',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3361,394,'石柱',3,'0','500240','0,1,32,394,3361',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3362,394,'彭水',3,'0','500243','0,1,32,394,3362',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3363,394,'酉阳',3,'0','500242','0,1,32,394,3363',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3364,394,'秀山',3,'0','500241','0,1,32,394,3364',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3365,395,'沙田区',3,'0','0','0,1,33,395,3365',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3366,395,'东区',3,'0','0','0,1,33,395,3366',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3367,395,'观塘区',3,'0','0','0,1,33,395,3367',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3368,395,'黄大仙区',3,'0','0','0,1,33,395,3368',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3369,395,'九龙城区',3,'0','0','0,1,33,395,3369',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3370,395,'屯门区',3,'0','0','0,1,33,395,3370',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3371,395,'葵青区',3,'0','0','0,1,33,395,3371',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3372,395,'元朗区',3,'0','0','0,1,33,395,3372',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3373,395,'深水埗区',3,'0','0','0,1,33,395,3373',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3374,395,'西贡区',3,'0','0','0,1,33,395,3374',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3375,395,'大埔区',3,'0','0','0,1,33,395,3375',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3376,395,'湾仔区',3,'0','0','0,1,33,395,3376',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3377,395,'油尖旺区',3,'0','0','0,1,33,395,3377',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3378,395,'北区',3,'0','0','0,1,33,395,3378',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3379,395,'南区',3,'0','0','0,1,33,395,3379',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3380,395,'荃湾区',3,'0','0','0,1,33,395,3380',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3381,395,'中西区',3,'0','0','0,1,33,395,3381',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3382,395,'离岛区',3,'0','0','0,1,33,395,3382',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3383,396,'澳门',3,'0','0','0,1,34,396,3383',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3384,397,'台北',3,'0','0','0,1,35,397,3384',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3385,397,'高雄',3,'0','0','0,1,35,397,3385',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3386,397,'基隆',3,'0','0','0,1,35,397,3386',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3387,397,'台中',3,'0','0','0,1,35,397,3387',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3388,397,'台南',3,'0','0','0,1,35,397,3388',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3389,397,'新竹',3,'0','0','0,1,35,397,3389',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3390,397,'嘉义',3,'0','0','0,1,35,397,3390',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3391,397,'宜兰县',3,'0','0','0,1,35,397,3391',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3392,397,'桃园县',3,'0','0','0,1,35,397,3392',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3393,397,'苗栗县',3,'0','0','0,1,35,397,3393',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3394,397,'彰化县',3,'0','0','0,1,35,397,3394',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3395,397,'南投县',3,'0','0','0,1,35,397,3395',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3396,397,'云林县',3,'0','0','0,1,35,397,3396',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3397,397,'屏东县',3,'0','0','0,1,35,397,3397',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3398,397,'台东县',3,'0','0','0,1,35,397,3398',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3399,397,'花莲县',3,'0','0','0,1,35,397,3399',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3400,397,'澎湖县',3,'0','0','0,1,35,397,3400',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3401,3,'合肥',2,'0551','340100','0,1,3,3401',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3402,3401,'庐阳区',3,'0','340103','0,1,3,3401,3402',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3403,3401,'瑶海区',3,'0','340102','0,1,3,3401,3403',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3404,3401,'蜀山区',3,'0','340104','0,1,3,3401,3404',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3405,3401,'包河区',3,'0','340111','0,1,3,3401,3405',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3406,3401,'长丰县',3,'0','340121','0,1,3,3401,3406',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3407,3401,'肥东县',3,'0','340122','0,1,3,3401,3407',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3408,3401,'肥西县',3,'0','340123','0,1,3,3401,3408',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3410,360,'独山子区',3,'0','650202','0,1,29,360,3410',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3411,360,'克拉玛依区',3,'0','650203','0,1,29,360,3411',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3412,360,'白碱滩区',3,'0','650204','0,1,29,360,3412',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3413,360,'乌尔禾区',3,'0','650205','0,1,29,360,3413',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3414,29,'塔城地区',2,'0901','654200','0,1,29,3414',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3415,3414,'塔城市',3,'0','654201','0,1,29,3414,3415',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3416,3414,'乌苏市',3,'0','654202','0,1,29,3414,3416',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3417,3414,'额敏县',3,'0','654221','0,1,29,3414,3417',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3418,3414,'沙湾县',3,'0','654223','0,1,29,3414,3418',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3419,3414,'托里县',3,'0','654224','0,1,29,3414,3419',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3420,3414,'裕民县',3,'0','654225','0,1,29,3414,3420',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3421,3414,'和布克赛尔',3,'0','654226','0,1,29,3414,3421',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3422,29,'阿勒泰地区',2,'0906','654300','0,1,29,3422',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3423,3422,'阿勒泰市',3,'0','654301','0,1,29,3422,3423',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3424,3422,'布尔津县',3,'0','654321','0,1,29,3422,3424',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3425,3422,'富蕴县',3,'0','654322','0,1,29,3422,3425',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3426,3422,'福海县',3,'0','654323','0,1,29,3422,3426',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3427,3422,'哈巴河县',3,'0','654324','0,1,29,3422,3427',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3428,3422,'青河县',3,'0','654325','0,1,29,3422,3428',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3429,3422,'吉木乃县',3,'0','654326','0,1,29,3422,3429',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3430,365,'石河子市',3,'0993','659001','0,1,29,365,3430',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3431,365,'阿拉尔市',3,'0997','659002','0,1,29,365,3431',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3432,365,'图木舒克市',3,'0998','659003','0,1,29,365,3432',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3433,94,'鼎湖区',3,'0','441203','0,1,6,94,3433',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3434,155,'济源市',3,'0','410881','0,1,11,155,3434',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3436,172,'麻山区',3,'0','230307','0,1,12,172,3436',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3437,173,'永红区',3,'0','230802','0,1,12,173,3437',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3438,2721,'城桥镇',4,'0','201913','0,1,25,321,2721,3438',1,94,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3439,2721,'堡镇',4,'0','201913','0,1,25,321,2721,3439',1,59,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3440,2721,'新河镇',4,'0','201913','0,1,25,321,2721,3440',1,80,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3441,2721,'庙镇',4,'0','201913','0,1,25,321,2721,3441',1,56,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3442,2721,'竖新镇',4,'0','201913','0,1,25,321,2721,3442',1,97,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3443,2721,'向化镇',4,'0','201913','0,1,25,321,2721,3443',1,85,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3444,2721,'三星镇',4,'0','201913','0,1,25,321,2721,3444',1,91,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3445,2721,'中兴镇',4,'0','201913','0,1,25,321,2721,3445',1,88,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3446,2721,'陈家镇',4,'0','201913','0,1,25,321,2721,3446',1,68,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3447,2721,'绿华镇',4,'0','201913','0,1,25,321,2721,3447',1,100,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3448,2721,'港沿镇',4,'0','201913','0,1,25,321,2721,3448',1,83,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3449,2721,'建设镇',4,'0','201913','0,1,25,321,2721,3449',1,77,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3450,2721,'新海镇',4,'0','201913','0,1,25,321,2721,3450',1,62,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3451,2721,'东平镇',4,'0','201913','0,1,25,321,2721,3451',1,65,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3452,2721,'长兴镇',4,'0','201913','0,1,25,321,2721,3452',1,71,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3453,3442,'仙桥村',5,'0','201913','0,1,25,321,2721,3442,3453',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3454,3442,'惠民村',5,'0','201913','0,1,25,321,2721,3442,3454',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3455,3442,'新征村',5,NULL,'201913','0,1,25,321,2721,3442,3455',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3456,3442,'堡西村',5,NULL,'201913','0,1,25,321,2721,3442,3456',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3457,3442,'油桥村',5,NULL,'201913','0,1,25,321,2721,3442,3457',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3458,3442,'明强村',5,NULL,'201913','0,1,25,321,2721,3442,3458',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3459,3442,'东兴村',5,NULL,'201913','0,1,25,321,2721,3442,3459',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3460,2721,'港西镇',4,'0','201913','0,1,25,321,2721,3460',1,74,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3461,2721,'新村乡',4,'0','201913','0,1,25,321,2721,3461',1,53,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3462,2721,'横沙乡',4,'0','201913','0,1,25,321,2721,3462',1,50,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3471,138,'测试',3,'1','1','0,1,10,138,3471',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3501,3438,'江山村',5,'','011111','0,1,25,321,2721,3438,3501',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3502,3438,'江山kk村',5,'','201913','0,1,25,321,2721,3438,3502',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3503,2718,'青浦区X镇(预留)',4,'0','310118','0,1,25,321,2718,3503',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3504,3503,'莲湖村',5,'0','310118','0,1,25,321,2718,3503,3504',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3505,3503,'张马村',5,'','','0,1,25,321,2718,3503,3505',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3506,2718,'金泽镇',4,'310118','310118','0,1,25,321,2718,3506',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3507,2715,'石湖荡镇',4,'0','0','0,1,25,321,2715,3507',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3508,2715,'九亭镇',4,'0','0','0,1,25,321,2715,3508',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3509,2715,'叶榭镇',4,'','','0,1,25,321,2715,3509',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3510,2715,'新桥镇',4,'','','0,1,25,321,2715,3510',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3511,2715,'泗泾镇',4,'','','0,1,25,321,2715,3511',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3512,2715,'佘山镇',4,'','','0,1,25,321,2715,3512',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3513,2715,'车墩镇',4,'','','0,1,25,321,2715,3513',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3514,2715,'洞泾镇',4,'','','0,1,25,321,2715,3514',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3515,2715,'小昆山镇',4,'','','0,1,25,321,2715,3515',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3516,2715,'泖港镇',4,'','','0,1,25,321,2715,3516',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3517,2715,'新浜镇',4,'','','0,1,25,321,2715,3517',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3518,2715,'九里亭街道',4,'','','0,1,25,321,2715,3518',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3519,2715,'广富林街道',4,'','','0,1,25,321,2715,3519',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3520,2715,'岳阳街道',4,'','','0,1,25,321,2715,3520',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3521,2715,'中山街道',4,'','','0,1,25,321,2715,3521',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3522,2715,'永丰街道',4,'','','0,1,25,321,2715,3522',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3523,2715,'方松街道',4,'','','0,1,25,321,2715,3523',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3534,3507,'新源村',5,'','','0,1,25,321,2715,3507,3534',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3535,3507,'新姚村',5,'','','0,1,25,321,2715,3507,3535',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3536,3507,'泖新村',5,'','','0,1,25,321,2715,3507,3536',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3537,3507,'洙桥村',5,'','','0,1,25,321,2715,3507,3537',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3538,3507,'东夏村',5,'','','0,1,25,321,2715,3507,3538',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3539,3507,'东港村',5,'','','0,1,25,321,2715,3507,3539',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3540,3507,'金汇村',5,'','','0,1,25,321,2715,3507,3540',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3541,3507,'金胜村',5,'','','0,1,25,321,2715,3507,3541',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3542,3507,'张庄村',5,'','','0,1,25,321,2715,3507,3542',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3543,3507,'新中村',5,'','','0,1,25,321,2715,3507,3543',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3555,3517,'鲁星村',5,'','','0,1,25,321,2715,3517,3555',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3556,3517,'南杨村',5,'','','0,1,25,321,2715,3517,3556',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3557,3517,'陈堵村',5,'','','0,1,25,321,2715,3517,3557',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3558,3517,'赵王村',5,'','','0,1,25,321,2715,3517,3558',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3559,3517,'林建村',5,'','','0,1,25,321,2715,3517,3559',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3560,3517,'许家草村',5,'','','0,1,25,321,2715,3517,3560',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3562,3517,'新浜村',5,'','','0,1,25,321,2715,3517,3562',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3563,3517,'黄家埭村',5,'','','0,1,25,321,2715,3517,3563',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3564,3517,'文华村',5,'','','0,1,25,321,2715,3517,3564',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3565,3517,'胡家埭村',5,'','','0,1,25,321,2715,3517,3565',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3566,3517,'香塘村',5,'','','0,1,25,321,2715,3517,3566',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3571,3509,'同建村',5,'','','0,1,25,321,2715,3509,3571',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3572,3509,'金家村',5,'','','0,1,25,321,2715,3509,3572',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3573,3509,'东石村',5,'','','0,1,25,321,2715,3509,3573',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3574,3509,'兴达村',5,'','','0,1,25,321,2715,3509,3574',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3575,3509,'东勤村',5,'','','0,1,25,321,2715,3509,3575',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3576,3509,'堰泾村',5,'','','0,1,25,321,2715,3509,3576',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3577,3509,'团结村',5,'','','0,1,25,321,2715,3509,3577',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3578,3509,'四村村',5,'','','0,1,25,321,2715,3509,3578',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3579,3509,'井凌桥村',5,'','','0,1,25,321,2715,3509,3579',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3580,3509,'大庙村',5,'','','0,1,25,321,2715,3509,3580',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3581,3509,'马桥村',5,'','','0,1,25,321,2715,3509,3581',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3582,3509,'八字桥村',5,'','','0,1,25,321,2715,3509,3582',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3583,3509,'徐姚村',5,'','','0,1,25,321,2715,3509,3583',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3585,3516,'焦家村',5,'','','0,1,25,321,2715,3516,3585',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3586,3516,'新龚村',5,'','','0,1,25,321,2715,3516,3586',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3587,3516,'腰泾村',5,'','','0,1,25,321,2715,3516,3587',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3588,3516,'胡光村',5,'','','0,1,25,321,2715,3516,3588',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3589,3516,'黄桥村',5,'','','0,1,25,321,2715,3516,3589',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3590,3516,'范家村',5,'','','0,1,25,321,2715,3516,3590',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3591,3516,'泖港村',5,'','','0,1,25,321,2715,3516,3591',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3592,3516,'新建村',5,'','','0,1,25,321,2715,3516,3592',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3593,3516,'徐厍村',5,'','','0,1,25,321,2715,3516,3593',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3594,3516,'南三村',5,'','','0,1,25,321,2715,3516,3594',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3595,3516,'兴旺村',5,'','','0,1,25,321,2715,3516,3595',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3596,3516,'田黄村',5,'','','0,1,25,321,2715,3516,3596',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3597,3516,'曙光村',5,'','','0,1,25,321,2715,3516,3597',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3598,3516,'曹家浜村',5,'','','0,1,25,321,2715,3516,3598',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3599,3516,'朱定村',5,'','','0,1,25,321,2715,3516,3599',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3600,3516,'茹塘村',5,'','','0,1,25,321,2715,3516,3600',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3601,3513,'高桥村',5,'','','0,1,25,321,2715,3513,3601',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3602,3513,'新余村',5,'','','0,1,25,321,2715,3513,3602',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3603,3513,'联建村',5,'','','0,1,25,321,2715,3513,3603',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3604,3513,'得胜村',5,'','','0,1,25,321,2715,3513,3604',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3605,3513,'联庄村',5,'','','0,1,25,321,2715,3513,3605',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3606,3513,'汇桥村',5,'','','0,1,25,321,2715,3513,3606',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3607,3513,'联民村',5,'','','0,1,25,321,2715,3513,3607',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3608,3513,'南门村',5,'','','0,1,25,321,2715,3513,3608',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3609,3513,'米市渡村',5,'','','0,1,25,321,2715,3513,3609',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3610,3513,'永福村',5,'','','0,1,25,321,2715,3513,3610',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3611,3513,'长溇村',5,'','','0,1,25,321,2715,3513,3611',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3612,3513,'洋泾村',5,'','','0,1,25,321,2715,3513,3612',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3613,3513,'香山村',5,'','','0,1,25,321,2715,3513,3613',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3614,3513,'打铁桥村',5,'','','0,1,25,321,2715,3513,3614',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3615,3513,'华阳村',5,'','','0,1,25,321,2715,3513,3615',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3616,3513,'东门村',5,'','','0,1,25,321,2715,3513,3616',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3617,3515,'周家浜村',5,'','','0,1,25,321,2715,3515,3617',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3618,3515,'汤村村',5,'','','0,1,25,321,2715,3515,3618',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3619,3515,'永丰村',5,'','','0,1,25,321,2715,3515,3619',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3620,3515,'荡湾村',5,'','','0,1,25,321,2715,3515,3620',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3621,3515,'泾德村',5,'','','0,1,25,321,2715,3515,3621',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3622,3515,'港丰村',5,'','','0,1,25,321,2715,3515,3622',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3623,3515,'大港村',5,'','','0,1,25,321,2715,3515,3623',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3624,3515,'陆家埭村',5,'','','0,1,25,321,2715,3515,3624',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3625,3512,'江秋村',5,'','','0,1,25,321,2715,3512,3625',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3626,3512,'张朴村',5,'','','0,1,25,321,2715,3512,3626',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3628,3512,'高家村',5,'','','0,1,25,321,2715,3512,3628',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3629,3512,'北干山村',5,'','','0,1,25,321,2715,3512,3629',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3630,3512,'陈坊村',5,'','','0,1,25,321,2715,3512,3630',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3631,3512,'陆其浜村',5,'','','0,1,25,321,2715,3512,3631',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3632,3512,'卫家埭村',5,'','','0,1,25,321,2715,3512,3632',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3633,3512,'新镇村',5,'','','0,1,25,321,2715,3512,3633',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3634,3512,'横山村',5,'','','0,1,25,321,2715,3512,3634',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3635,3512,'刘家山村',5,'','','0,1,25,321,2715,3512,3635',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3636,3512,'新宅村',5,'','','0,1,25,321,2715,3512,3636',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3640,3518,'五洲居委会',5,'','','0,1,25,321,2715,3512,3640',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3644,2707,'陆家嘴街道',4,'','','0,1,25,321,2707,3644',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3645,2707,'塘桥街道',4,'','','0,1,25,321,2707,3645',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3646,2707,'花木街道',4,'','','0,1,25,321,2707,3646',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3647,2707,'南汇新城镇',4,'','','0,1,25,321,2707,3647',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3648,2707,'张江镇',4,'','','0,1,25,321,2707,3648',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3649,2707,'康桥镇',4,'','','0,1,25,321,2707,3649',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3650,2707,'书院镇',4,'','','0,1,25,321,2707,3650',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3651,2707,'航头镇',4,'','','0,1,25,321,2707,3651',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3652,2707,'周浦镇',4,'','','0,1,25,321,2707,3652',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3653,2707,'北蔡镇',4,'','','0,1,25,321,2707,3653',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3654,2707,'三林镇',4,'','','0,1,25,321,2707,3654',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3655,2707,'宣桥镇',4,'','','0,1,25,321,2707,3655',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3656,2707,'祝桥镇',4,'','','0,1,25,321,2707,3656',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3657,2707,'泥城镇',4,'','','0,1,25,321,2707,3657',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3658,3653,'华夏西路1号',5,'','','0,1,25,321,2707,3653,3658',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3659,3651,'航鹤路1号',5,'','','0,1,25,321,2707,3651,3659',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3660,3650,'新府1号',5,'','','0,1,25,321,2707,3650,3660',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3661,3649,'康桥路1号',5,'','','0,1,25,321,2707,3649,3661',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3662,3654,'海阳路1号',5,'','','0,1,25,321,2707,3654,3662',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3663,3648,'金科路1号',5,'','','0,1,25,321,2707,3648,3663',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3664,3646,'龙阳路1号',5,'','','0,1,25,321,2707,3646,3664',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36'),
(3665,3644,'外滩1号',5,'','','0,1,25,321,2707,3644,3665',1,0,'','2021-03-20 17:34:36','2021-03-20 17:34:36');

/*Table structure for table `tb_users` */

DROP TABLE IF EXISTS `tb_users`;

CREATE TABLE `tb_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) DEFAULT '' COMMENT '账号',
  `pass` varchar(128) DEFAULT '' COMMENT '密码',
  `real_name` varchar(30) DEFAULT '' COMMENT '姓名',
  `phone` char(11) DEFAULT '' COMMENT '手机',
  `avatar` varchar(256) DEFAULT '' COMMENT '头像',
  `fr_province_city_id` int(11) DEFAULT 1 COMMENT '隶属城市ID',
  `fr_auth_organization_post` int(11) DEFAULT 0 COMMENT '隶属部门、岗位ID',
  `status` tinyint(4) DEFAULT 1 COMMENT '状态',
  `remark` varchar(128) DEFAULT '' COMMENT '备注',
  `last_login_time` datetime DEFAULT current_timestamp(),
  `last_login_ip` char(30) DEFAULT '' COMMENT '最近一次登录ip',
  `login_times` int(11) DEFAULT 0 COMMENT '累计登录次数',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tb_users` */

insert  into `tb_users`(`id`,`user_name`,`pass`,`real_name`,`phone`,`avatar`,`fr_province_city_id`,`fr_auth_organization_post`,`status`,`remark`,`last_login_time`,`last_login_ip`,`login_times`,`created_at`,`updated_at`) values 
(1,'admin','ff1e2a0591fde5214b52942be87be566','管理员','15804037929','/public/storage/uploaded/2021_03/d023d70fff24d7bb237d27cc7c00c11f.png',0,0,1,'管理员账号','2021-03-16 13:17:48','127.0.0.1',108,'2021-03-19 00:07:15','2021-03-22 00:09:41'),
(3,'boshi','188bda0c10088d7c2e6d7c00592679e7','博士','15804037929','/public/storage/uploaded/2022_06/351b9dece2fb1021a4402b9e40a0ffce.jpg0',321,0,1,'更新资料9527','2020-12-01 14:07:44','127.0.0.1',1,'2020-12-01 14:07:44','2022-06-04 15:46:19');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
